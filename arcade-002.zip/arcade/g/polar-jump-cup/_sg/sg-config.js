window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": false,
 "debug": false,
 "hubConfig": "../../config.json",
 "platform": "arcade",
 "title": "Polar Jump Cup",
 "names": {
  "title": "POLAR JUMP CUP"
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.hubConfig="../../config.json";c.title="Polar Jump Cup";})(window.SG_CONFIG);
