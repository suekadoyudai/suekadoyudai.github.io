window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": true,
 "debug": true,
 "platform": "null",
 "title": "SNOWTRACE",
 "names": {
  "title": null
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.title="Polar Jump Cup";})(window.SG_CONFIG);
