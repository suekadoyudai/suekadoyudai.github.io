/*! SuedoGaming Arcade host bridge: Telegram Mini App / LINE MINI App / web. No tracking. */
(function () {
  'use strict';
  var A = window.__ARCADE = { tg: false, line: false, depth: (document.currentScript && document.currentScript.getAttribute('data-depth')) || '' };
  function ss(k) { try { return window.sessionStorage.getItem(k); } catch (e) { return null; } }
  var hq = (location.hash || '') + (location.search || '');
  A.tg = /tgWebApp(Data|Version|Platform)/.test(hq) || !!window.TelegramWebviewProxy || !!ss('__telegram__initParams');
  A.line = /Line\//.test(navigator.userAgent) || /liff\.state|liff\.referrer/.test(hq);
  if (A.tg) {
    var s = document.createElement('script');
    s.src = 'https://telegram.org/js/telegram-web-app.js';
    s.onload = function () {
      try {
        var w = window.Telegram.WebApp; w.ready(); w.expand();
        if (w.disableVerticalSwipes) w.disableVerticalSwipes();
        if (A.depth && w.BackButton) { w.BackButton.show(); w.BackButton.onClick(function () { location.href = A.depth + 'index.html'; }); }
        if (!A.depth && w.BackButton) w.BackButton.hide();
        var sp = w.initDataUnsafe && w.initDataUnsafe.start_param;
        if (!A.depth && sp && window.__arcadeOpen) window.__arcadeOpen(String(sp));
      } catch (e) {}
    };
    document.head.appendChild(s);
  }
})();
