/*! SG backend + host runtime: SuedoGaming Arcade (Telegram Mini App / LINE MINI App / plain web).
 * One file, two uses:
 *   - inside a game (_sg/sg-backend.js, after sg-core.js): registers the SG backend;
 *   - inside the hub (_a/bridge.js, no window.SG): exposes window.ArcadeHost / window.ArcadePay only.
 * Everything monetary is CONFIG-DRIVEN from the hub's config.json and OFF while ids are empty:
 *   { "liffId": "", "telegramBot": "SuedoGamingArcadeBot",
 *     "ads": { "minInterstitialGapSec": 90, "order": ["adsgram", "monetag"],
 *              "adsgram": { "rewardedBlockId": "", "interstitialBlockId": "" },
 *              "monetag": { "zoneId": "" },                      // STUB, see MONETAG below
 *              "lyads":   { "rewardedTagId": "", "interstitialTagId": "" } },   // STUB (LINE)
 *     "stars": { "endpoint": "", "skus": { "remove-ads": { "grants": ["noads"] } } } }
 * Every ad failure = "no ad". canReward() is false unless a provider is really ready.
 * Saves: localStorage is primary; in Telegram they are mirrored to CloudStorage (values <= 4096 chars)
 * and restored from it on a new device.
 */
(function () {
  'use strict';
  var W = window;
  if (W.ArcadeHost && W.ArcadeHost.__v) return;
  var CFG = W.SG_CONFIG || {};
  var SG = W.SG && W.SG.__setBackend ? W.SG : null;
  var cur = document.currentScript;
  function log(ev, d) { try { if (SG) SG.__log(ev, d); else (W.__ARCADE_LOG = W.__ARCADE_LOG || []).push([ev, d]); } catch (e) {} }

  // ---------- small utils ----------
  var LS = (function () {
    var mem = {}, has = false;
    try { W.localStorage.setItem('__sg_t', '1'); W.localStorage.removeItem('__sg_t'); has = true; } catch (e) {}
    return {
      get: function (k) { try { return has ? W.localStorage.getItem(k) : (k in mem ? mem[k] : null); } catch (e) { return null; } },
      set: function (k, v) { try { if (has) W.localStorage.setItem(k, v); else mem[k] = v; } catch (e) { mem[k] = v; } },
      del: function (k) { try { if (has) W.localStorage.removeItem(k); else delete mem[k]; } catch (e) { delete mem[k]; } }
    };
  })();
  function ss(k, v) { try { if (v === undefined) return W.sessionStorage.getItem(k); W.sessionStorage.setItem(k, v); } catch (e) { return null; } }
  function jget(k, d) { try { var v = JSON.parse(LS.get(k)); return v == null ? d : v; } catch (e) { return d; } }
  function timeout(p, ms, v) { return Promise.race([p, new Promise(function (r) { setTimeout(function () { r(v); }, ms); })]); }
  var scripts = {};
  function loadScript(src, attrs) {
    if (scripts[src]) return scripts[src];
    scripts[src] = timeout(new Promise(function (res) {
      var s = document.createElement('script'); s.src = src; s.async = true;
      for (var a in (attrs || {})) s.setAttribute(a, attrs[a]);
      s.onload = function () { res(true); }; s.onerror = function () { res(false); };
      (document.head || document.documentElement).appendChild(s);
    }), 10000, false);
    return scripts[src];
  }

  // ---------- host detection ----------
  var q = (location.search || '') + '&' + (location.hash || '');
  var forced = (/[?&]arcade_host=(telegram|line|web)/.exec(q) || [])[1];
  if (forced) ss('arcade_host', forced);
  forced = forced || ss('arcade_host');
  var host = forced || ((/tgWebApp(Data|Version|Platform)/.test(q) || W.TelegramWebviewProxy || ss('__telegram__initParams') ||
    (W.Telegram && W.Telegram.WebApp && W.Telegram.WebApp.initData)) ? 'telegram'
    : (/Line\//.test(navigator.userAgent) || /liff\.state|liff\.referrer/.test(q)) ? 'line' : 'web');
  var depth = (cur && cur.getAttribute('data-depth')) || (SG ? '../../' : '');
  var isHub = !SG;
  var slug = (/\/g\/([a-z0-9-]+)\//.exec(location.pathname) || [])[1] || '';

  // ---------- config (fetched once per session) ----------
  var cfgUrl = CFG.hubConfig || (cur && cur.getAttribute('data-config')) || (depth + 'config.json');
  var cfgP = (function () {
    var c = ss('arcade_cfg');
    if (c) { try { return Promise.resolve(JSON.parse(c)); } catch (e) {} }
    if (!W.fetch) return Promise.resolve({});
    return timeout(fetch(cfgUrl, { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : {}; }), 4000, {})
      .catch(function () { return {}; })
      .then(function (j) { j = j && typeof j === 'object' ? j : {}; ss('arcade_cfg', JSON.stringify(j)); return j; });
  })();
  var conf = {};
  function g(o, path) { return path.split('.').reduce(function (a, k) { return a && a[k] != null ? a[k] : undefined; }, o); }

  // ---------- entitlements ----------
  var ENT_KEY = 'arcade_ent';
  function ents() { var e = jget(ENT_KEY, {}); return e && typeof e === 'object' ? e : {}; }
  function hasEnt(name) {
    var v = ents()[name];
    return v === true || (typeof v === 'number' && v > Date.now());
  }
  function setEnts(obj) {
    var e = ents(); for (var k in obj) e[k] = obj[k];
    var raw = JSON.stringify(e); LS.set(ENT_KEY, raw); cloudSet(ENT_KEY, raw); return e;
  }
  function noAds() { return hasEnt('noads') || hasEnt('supporter'); }

  // ---------- Telegram ----------
  var TG = null;
  function tg() { return W.Telegram && W.Telegram.WebApp; }
  function initTelegram() {
    var p = tg() ? Promise.resolve(true) : loadScript('https://telegram.org/js/telegram-web-app.js');
    return p.then(function () {
      var w = tg(); if (!w) return null;
      TG = w;
      try { w.ready(); } catch (e) {}
      try { w.expand(); } catch (e) {}
      try { if (w.disableVerticalSwipes) w.disableVerticalSwipes(); } catch (e) {}
      try {
        if (w.BackButton) {
          if (isHub) w.BackButton.hide();
          else { w.BackButton.show(); w.BackButton.onClick(function () { location.href = depth + 'index.html'; }); }
        }
      } catch (e) {}
      try {
        if (SG && w.onEvent) {
          w.onEvent('activated', function () { SG.__platformPause(false); });
          w.onEvent('deactivated', function () { SG.__platformPause(true); });
        }
      } catch (e) {}
      return w;
    });
  }
  function startParam() { var w = tg(); return (w && w.initDataUnsafe && w.initDataUnsafe.start_param) || ''; }

  // CloudStorage mirror (keys: [A-Za-z0-9_-]{1,128}, values <= 4096 chars)
  function ckey(k) {
    var s = String(k).replace(/[^A-Za-z0-9_-]/g, '_');
    if (s !== String(k)) { var h = 0; for (var i = 0; i < k.length; i++) h = (h * 31 + k.charCodeAt(i)) | 0; s = s.slice(0, 100) + '_' + (h >>> 0).toString(36); }
    return s.slice(0, 128);
  }
  function cloud() { return TG && TG.CloudStorage && TG.isVersionAtLeast && TG.isVersionAtLeast('6.9') ? TG.CloudStorage : (TG && TG.CloudStorage) || null; }
  var cloudTimers = {};
  function cloudSet(k, v) {
    var cs = cloud(); if (!cs || v == null || String(v).length > 4096) return;
    clearTimeout(cloudTimers[k]);
    cloudTimers[k] = setTimeout(function () { try { cs.setItem(ckey(k), String(v), function () {}); } catch (e) {} }, 400);
  }
  function cloudDel(k) { var cs = cloud(); if (cs) try { cs.removeItem(ckey(k), function () {}); } catch (e) {} }
  function cloudGet(keys) {
    var cs = cloud(); if (!cs || !keys.length) return Promise.resolve({});
    var ck = keys.map(ckey);
    return timeout(new Promise(function (res) {
      try { cs.getItems(ck, function (err, vals) { if (err || !vals) return res({}); var o = {}; keys.forEach(function (k, i) { if (vals[ck[i]]) o[k] = vals[ck[i]]; }); res(o); }); }
      catch (e) { res({}); }
    }), 2000, {});
  }

  // ---------- LINE ----------
  var LIFF = null;
  function initLine() {
    var id = conf.liffId; if (!id) return Promise.resolve(null);
    var p = W.liff ? Promise.resolve(true) : loadScript('https://static.line-scdn.net/liff/edge/2/sdk.js'); // edge/2 = latest 2.x (>= 2.32)
    return p.then(function () {
      if (!W.liff) return null;
      return timeout(Promise.resolve(W.liff.init({ liffId: id })).then(function () { LIFF = W.liff; return LIFF; }), 8000, null);
    }).catch(function (e) { log('liff_error', String(e && e.message || e)); return null; });
  }

  // ---------- ad providers: {id, hosts, ready(), rewarded(ctl), interstitial(ctl)} -> Promise<bool> ----------
  var PROVIDERS = {
    // AdsGram (https://docs.adsgram.ai): Adsgram.init({blockId}).show() -> resolves {done:true} when watched / closed;
    // rejects on skip or error. Interstitial "done" = shown.
    adsgram: (function () {
      var ctrls = {}, ok = false;
      function c(kind) {
        var id = g(conf, 'ads.adsgram.' + kind + 'BlockId'); if (!id || !W.Adsgram) return null;
        if (!ctrls[kind]) { try { ctrls[kind] = W.Adsgram.init({ blockId: String(id), debug: !!g(conf, 'ads.adsgram.debug') }); } catch (e) { return null; } }
        return ctrls[kind];
      }
      function show(kind, ctl) {
        var x = c(kind); if (!x) return Promise.resolve(false);
        ctl.pause();
        return timeout(Promise.resolve().then(function () { return x.show(); }).then(function (r) { return !!(r && r.done !== false); }, function () { return false; }), 120000, false)
          .then(function (v) { ctl.resume(); return v; });
      }
      return {
        hosts: ['telegram'],
        configured: function () { return !!(g(conf, 'ads.adsgram.rewardedBlockId') || g(conf, 'ads.adsgram.interstitialBlockId')); },
        load: function () { return (W.Adsgram ? Promise.resolve(true) : loadScript(g(conf, 'ads.adsgram.sdk') || 'https://sad.adsgram.ai/js/sad.min.js')).then(function () { ok = !!W.Adsgram; return ok; }); },
        can: function (kind) { return ok && !!g(conf, 'ads.adsgram.' + kind + 'BlockId'); },
        rewarded: function (ctl) { return show('rewarded', ctl); },
        interstitial: function (ctl) { return show('interstitial', ctl); }
      };
    })(),
    // MONETAG — STUB (second network slot). Enable only after the zone is approved and this code is tested:
    // config.ads.monetag = {zoneId:"1234567", enabled:true}. Monetag SDK: <script src="//libtl.com/sdk.js" data-zone=ID
    // data-sdk="show_ID">, then window['show_'+ID]() -> Promise (rewarded interstitial). Unverified tonight.
    monetag: (function () {
      var ok = false;
      function fn() { var z = g(conf, 'ads.monetag.zoneId'); return z && W['show_' + z]; }
      function show(ctl) {
        var f = fn(); if (!f) return Promise.resolve(false);
        ctl.pause();
        return timeout(Promise.resolve().then(function () { return f(); }).then(function () { return true; }, function () { return false; }), 120000, false)
          .then(function (v) { ctl.resume(); return v; });
      }
      return {
        hosts: ['telegram'],
        configured: function () { return !!(g(conf, 'ads.monetag.zoneId') && g(conf, 'ads.monetag.enabled')); },
        load: function () { var z = String(g(conf, 'ads.monetag.zoneId')); return (fn() ? Promise.resolve(true) : loadScript('https://libtl.com/sdk.js', { 'data-zone': z, 'data-sdk': 'show_' + z })).then(function () { ok = !!fn(); return ok; }); },
        can: function () { return ok; },
        rewarded: show,
        interstitial: show
      };
    })(),
    // LY Ads Network (LINE MINI App; the only ad network allowed there since 2026-10-14) — STUB.
    // Tag ids and SDK are issued after the partner contract + site review. Until then ready=false.
    lyads: {
      hosts: ['line'],
      configured: function () { return !!(g(conf, 'ads.lyads.rewardedTagId') || g(conf, 'ads.lyads.interstitialTagId')); },
      load: function () { return Promise.resolve(false); },
      can: function () { return false; },
      rewarded: function () { return Promise.resolve(false); },
      interstitial: function () { return Promise.resolve(false); }
    }
  };
  var active = [];
  function pick(kind) { for (var i = 0; i < active.length; i++) if (active[i].can(kind)) return active[i]; return null; }
  function initAds() {
    var order = g(conf, 'ads.order') || ['adsgram', 'monetag', 'lyads'];
    var cand = order.map(function (id) { return PROVIDERS[id]; }).filter(function (p) { return p && p.hosts.indexOf(host) >= 0 && p.configured(); });
    // lazy: SDKs are loaded after the game booted, never in <head>
    return Promise.all(cand.map(function (p) { return p.load().catch(function () { return false; }); }))
      .then(function () { active = cand.filter(function (p) { return p.can('rewarded') || p.can('interstitial'); }); log('arcade_ads', active.length); });
  }
  var GAP_KEY = 'arcade_last_inter';
  function interstitial(ctl) {
    if (noAds()) return Promise.resolve(false);
    var gap = (Number(g(conf, 'ads.minInterstitialGapSec')) || 90) * 1000;
    var last = Number(LS.get(GAP_KEY)) || 0;
    if (Date.now() - last < gap) return Promise.resolve(false);
    var p = pick('interstitial'); if (!p) return Promise.resolve(false);
    return p.interstitial(ctl).catch(function () { return false; }).then(function (v) { if (v) LS.set(GAP_KEY, String(Date.now())); return v; });
  }
  function rewarded(ctl) { var p = pick('rewarded'); if (!p) return Promise.resolve(false); return p.rewarded(ctl).catch(function () { return false; }); }

  // ---------- purchases ----------
  function payAvailable() { return host === 'telegram' && !!TG && !!g(conf, 'stars.endpoint') && !!TG.openInvoice; }
  function api(path, body) {
    var ep = String(g(conf, 'stars.endpoint')).replace(/\/+$/, '');
    return timeout(fetch(ep + path, body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {})
      .then(function (r) { return r.ok ? r.json() : null; }), 15000, null).catch(function () { return null; });
  }
  function refreshEntitlements() {
    if (!payAvailable() || !TG.initData) return Promise.resolve(ents());
    return api('/entitlements?initData=' + encodeURIComponent(TG.initData)).then(function (r) {
      if (r && r.entitlements && typeof r.entitlements === 'object') setEnts(r.entitlements);
      return ents();
    });
  }
  function buy(sku) {
    return ready.then(function () {
      if (host === 'line') return { ok: false, reason: 'line_iap_not_available' }; // LINE IAP: verified MINI App + IAP review first (stub)
      if (!payAvailable()) return { ok: false, reason: 'unsupported' };
      return api('/invoice', { sku: String(sku), initData: TG.initData || '' }).then(function (r) {
        if (!r || !r.link) return { ok: false, reason: 'no_invoice' };
        return new Promise(function (res) {
          var done = false, fin = function (st) { if (!done) { done = true; res(st); } };
          try { TG.openInvoice(r.link, function (status) { fin(status); }); } catch (e) { fin('failed'); }
        }).then(function (status) {
          if (status !== 'paid') return { ok: false, status: status };
          var grants = r.grants || g(conf, 'stars.skus.' + sku + '.grants') || [];
          var o = {}; grants.forEach(function (n) { o[n] = r.until && n === 'supporter' ? r.until : true; }); setEnts(o);
          return refreshEntitlements().then(function () { return { ok: true, status: status, entitlements: ents() }; });
        });
      });
    }).catch(function () { return { ok: false, reason: 'error' }; });
  }

  // ---------- boot ----------
  var ready = cfgP.then(function (c) {
    conf = c || {};
    if (host === 'telegram') return initTelegram().catch(function () { return null; });
    if (host === 'line') return initLine();
    return null;
  }).then(function () {
    if (slug) { var r = jget('arcade_recent', []); r = [slug].concat(r.filter(function (s) { return s !== slug; })).slice(0, 12); LS.set('arcade_recent', JSON.stringify(r)); }
    if (TG) {
      if (LS.get(ENT_KEY) == null) cloudGet([ENT_KEY]).then(function (c) { if (c[ENT_KEY]) LS.set(ENT_KEY, c[ENT_KEY]); });
      refreshEntitlements();
    }
    return { host: host, config: conf };
  });

  var H = W.ArcadeHost = {
    __v: 1, get host() { return host; }, get config() { return conf; }, ready: ready, startParam: startParam,
    tg: function () { return TG; }, liff: function () { return LIFF; },
    entitlements: ents, has: hasEnt, noAds: noAds, payAvailable: payAvailable, refreshEntitlements: refreshEntitlements,
    openLink: function (url) {
      try { if (TG && /^https:\/\/t\.me\//.test(url) && TG.openTelegramLink) return TG.openTelegramLink(url); if (TG && TG.openLink) return TG.openLink(url); } catch (e) {}
      try { if (LIFF && LIFF.openWindow) return LIFF.openWindow({ url: url, external: false }); } catch (e) {}
      W.open(url, '_blank');
    }
  };
  W.ArcadePay = { buy: buy, available: function () { return ready.then(payAvailable); }, has: hasEnt };

  if (!SG) return;
  // one shared deadline for init() and storageLoad() (they run one after the other in sg-core)
  var gameReady = timeout(ready, 2500, null);
  // ---------- SG backend ----------
  SG.purchase = buy; // extension: SG.purchase(sku) -> Promise<{ok, status?, reason?}>
  SG.entitlement = hasEnt;
  SG.__setBackend({
    name: 'arcade',
    init: function () {
      // features are only true when a provider really loaded; initAds is bounded by timeouts.
      // host init (LIFF / Telegram SDK) is capped: a slow or hanging SDK never delays the game's boot by more than ~2.5 s
      return gameReady.then(function () { return host === 'web' ? null : timeout(initAds(), 6000, null); }).then(function () {
        var r = { features: { rewarded: !!pick('rewarded'), interstitial: !!pick('interstitial') && !noAds() } };
        var lang = TG && TG.initDataUnsafe && TG.initDataUnsafe.user && TG.initDataUnsafe.user.language_code;
        if (!lang && LIFF && LIFF.getLanguage) try { lang = LIFF.getLanguage(); } catch (e) {}
        if (lang) r.lang = lang;
        return r;
      });
    },
    canReward: function () { return !!pick('rewarded'); },
    interstitial: function (placement, ctl) { return interstitial(ctl); },
    rewarded: function (name, ctl) { return rewarded(ctl); },
    storageLoad: function (keys) { return gameReady.then(function () { return loadKeys(keys); }); },
    storageSet: function (k, v) { LS.set(k, v); cloudSet(k, v); },
    storageRemove: function (k) { LS.del(k); cloudDel(k); }
  });
  function loadKeys(keys) {
      var o = {}, miss = [];
      keys.forEach(function (k) { o[k] = LS.get(k); if (o[k] == null) miss.push(k); });
      if (!miss.length || !cloud()) return o;
      return cloudGet(miss).then(function (c) { for (var k in c) { o[k] = c[k]; LS.set(k, c[k]); } return o; });
  }
})();
