window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": true,
 "debug": true,
 "platform": "null",
 "title": "Lighthouse Leap",
 "names": {
  "title": null
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.title="Critter Sling Clash";})(window.SG_CONFIG);
