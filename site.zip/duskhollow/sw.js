/* 宵闇の館 Duskhollow Manor service worker: caches the whole game so it runs offline */
const CACHE = 'lom-2.0.0';
const ASSETS = ['./', './index.html', './manifest.webmanifest', './privacy.html',
  './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png', './icons/favicon-32.png', './icons/apple-touch-icon.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('lom-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) {
    // fonts: cache what we can, fall back to system fonts offline
    e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request).then((r) => { if (r.ok || r.type === 'opaque') { const c = r.clone(); caches.open(CACHE).then((x) => x.put(e.request, c)); } return r; }).catch(() => new Response('', { status: 504 }))));
    return;
  }
  if (e.request.mode === 'navigate') {
    // Launching the game: always ask the server for a newer version (cheap when nothing changed),
    // but never show or keep an error page, and never keep the player waiting more than 3 seconds.
    e.respondWith((async () => {
      const cached = await caches.match('./index.html');
      const fresh = fetch(e.request, { cache: 'no-cache' }).then((r) => {
        if (!r || !r.ok) throw new Error('status ' + (r && r.status));
        const c = r.clone(); caches.open(CACHE).then((x) => x.put('./index.html', c));
        return r;
      });
      if (!cached) return fresh.catch(() => new Response('<p style="font:16px sans-serif;padding:2em">Offline. Please connect to the internet once to finish installing.</p>', { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } }));
      fresh.catch(() => {});
      const late = new Promise((res) => setTimeout(() => res(null), 3000));
      try { return (await Promise.race([fresh, late])) || cached; } catch (err) { return cached; }
    })());
    return;
  }
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request).then((r) => { if (r.ok) { const c = r.clone(); caches.open(CACHE).then((x) => x.put(e.request, c)); } return r; })));
});
