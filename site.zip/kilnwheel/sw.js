// Kiln and Wheel Studio offline cache (cache-first for the game's own files). Cache names are prefixed per game:
// the origin is shared with other games, so only this game's old caches are removed.
var CACHE = 'kilnwheel-1.0.0';
var FILES = ["./","./_sg/sg-backend.js","./_sg/sg-config.js","./_sg/sg-core.js","./audio/best.ogg","./audio/click.ogg","./audio/coin.ogg","./audio/crack.ogg","./audio/day.ogg","./audio/flawless.ogg","./audio/good.ogg","./audio/kiln.ogg","./audio/lump.ogg","./audio/music.ogg","./audio/over.ogg","./audio/perfect.ogg","./audio/splash.ogg","./audio/start.ogg","./audio/tick.ogg","./audio/warn.ogg","./audio/wheel.ogg","./icons/apple-touch-icon.png","./icons/icon-192.png","./icons/icon-512-maskable.png","./icons/icon-512.png","./index.html","./manifest.webmanifest","./privacy.html"];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(FILES); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k.indexOf('kilnwheel-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(function (hit) {
    if (hit) return hit;
    return fetch(req).then(function (res) {
      if (res && res.ok && res.type === 'basic') { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
      return res;
    }).catch(function () { return caches.match('./index.html'); });
  }));
});
