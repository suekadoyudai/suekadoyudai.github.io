/*! SG backend: GX.games — ad-free platform. No SDK, no ads; localStorage saves. */
(function () {
  'use strict';
  var LS = (function () {
    var mem = {};
    function ok() { try { var k = '__sg_t'; localStorage.setItem(k, '1'); localStorage.removeItem(k); return true; } catch (e) { return false; } }
    var has = ok();
    return {
      get: function (k) { try { return has ? localStorage.getItem(k) : (k in mem ? mem[k] : null); } catch (e) { return null; } },
      set: function (k, v) { try { if (has) localStorage.setItem(k, v); else mem[k] = v; } catch (e) { mem[k] = v; } },
      del: function (k) { try { if (has) localStorage.removeItem(k); else delete mem[k]; } catch (e) { delete mem[k]; } }
    };
  })();
  window.SG.__setBackend({
    name: 'gx',
    init: function () { return { features: { interstitial: false, rewarded: false } }; },
    storageLoad: function (keys) { var o = {}; keys.forEach(function (k) { o[k] = LS.get(k); }); return o; },
    storageSet: function (k, v) { LS.set(k, v); },
    storageRemove: function (k) { LS.del(k); }
  });
})();
