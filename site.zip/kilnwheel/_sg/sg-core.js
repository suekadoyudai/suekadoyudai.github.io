/*! SG (SuedoGaming) platform shim — core. Platform-neutral.
 * Games call ONLY window.SG.*; per-platform behaviour lives in a backend
 * (sg-backend.js) that calls SG.__setBackend({...}).
 *
 * Load order inside <head> (build.py writes this block):
 *   [platform head snippet]  sg-config.js  sg-core.js  sg-backend.js
 *
 * Game wiring contract (enforced at canonicalization):
 *   - Boot the engine/assets only after `await SG.init()`.
 *   - Report SG.loading(pct) while loading, SG.ready() at first playable frame.
 *   - SG.gameplayStart()/SG.gameplayStop() around active play.
 *   - Pause + mute ONLY inside SG.onPause(cb); resume inside SG.onResume(cb).
 *   - Master volume = SG.audioEnabled ? userVolume : 0 (listen SG.onAudioChange).
 *   - SG.interstitial(placement) ONLY from a click/tap/key handler at a natural break.
 *   - Rewarded UI visible only when SG.canReward(); grant only if {rewarded:true}.
 *   - All persistence via SG.storage (await SG.storage.load([...keys]) once at boot).
 *   - SG.score(n) with the final integer score at game over (leaderboards where the platform has them).
 */
(function () {
  'use strict';
  if (window.SG && window.SG.__core) return;

  var CFG = window.SG_CONFIG || {};
  var LOG = (window.__SG_LOG = window.__SG_LOG || []);
  function log(ev, data) {
    try {
      LOG.push({ t: Date.now(), ev: ev, data: data === undefined ? null : data });
      if (LOG.length > 500) LOG.shift();
      if (CFG.debug && window.console) console.log('[SG]', ev, data === undefined ? '' : data);
    } catch (e) {}
  }

  var backend = null;
  var initPromise = null;
  var pauseReasons = {};
  var pauseCbs = [], resumeCbs = [], audioCbs = [];
  var paused = false;
  var audioEnabled = true;
  var lastGesture = 0;
  var GESTURE_WINDOW_MS = 1500;
  var lastInterstitial = 0;
  var features = { interstitial: false, rewarded: false };
  var cache = {};
  var lang = 'en';

  function safe(fn, args) {
    try { return fn && fn.apply(null, args || []); } catch (e) { log('error', String(e && e.message || e)); }
  }

  function recomputePause() {
    var any = false;
    for (var k in pauseReasons) if (pauseReasons[k]) { any = true; break; }
    if (any && !paused) { paused = true; log('pause', Object.keys(pauseReasons).filter(function (k) { return pauseReasons[k]; })); pauseCbs.forEach(function (cb) { safe(cb); }); }
    else if (!any && paused) { paused = false; log('resume'); resumeCbs.forEach(function (cb) { safe(cb); }); }
  }
  function setPause(reason, on) { pauseReasons[reason] = !!on; recomputePause(); }

  // --- gesture tracking (interstitials must follow a user action) ---
  ['pointerdown', 'mousedown', 'touchstart', 'keydown'].forEach(function (t) {
    window.addEventListener(t, function () { lastGesture = Date.now(); }, true);
  });

  // --- visibility / focus ---
  document.addEventListener('visibilitychange', function () { setPause('visibility', document.hidden); });
  if (CFG.pauseOnBlur) {
    window.addEventListener('blur', function () { setPause('blur', true); });
    window.addEventListener('focus', function () { setPause('blur', false); });
  }

  function normLang(l) {
    l = String(l || '').toLowerCase();
    var m = l.match(/^[a-z]{2}/);
    return m ? m[0] : 'en';
  }

  var SG = {
    __core: true,
    version: '1.0.0',
    get platform() { return CFG.platform || 'null'; },
    get config() { return CFG; },
    get lang() { return lang; },
    get paused() { return paused; },
    get audioEnabled() { return audioEnabled; },

    __setBackend: function (b) { backend = b; log('backend', b && b.name); },
    // called by backends
    __platformPause: function (on) { setPause('platform', on); },
    __pauseReason: function (reason, on) { setPause('b_' + reason, on); },
    __setAudio: function (on) {
      on = !!on;
      if (on === audioEnabled) return;
      audioEnabled = on; log('audio', on);
      audioCbs.forEach(function (cb) { safe(cb, [on]); });
    },
    __log: log,

    init: function () {
      if (initPromise) return initPromise;
      log('init');
      var b = backend || { name: 'none' };
      initPromise = Promise.resolve()
        .then(function () { return b.init ? b.init(SG) : {}; })
        .catch(function (e) { log('init_error', String(e && e.message || e)); return {}; })
        .then(function (r) {
          r = r || {};
          features = {
            interstitial: !!(r.features && r.features.interstitial),
            rewarded: !!(r.features && r.features.rewarded)
          };
          if (r.audioEnabled === false) SG.__setAudio(false);
          lang = normLang(r.lang || CFG.forceLang || (navigator.language || 'en'));
          var info = { platform: SG.platform, lang: lang, audioEnabled: audioEnabled, features: features };
          log('init_done', info);
          return info;
        });
      return initPromise;
    },

    loading: function (pct) {
      pct = Math.max(0, Math.min(100, Math.round(Number(pct) || 0)));
      log('loading', pct);
      if (backend && backend.loading) safe(backend.loading, [pct]);
    },
    ready: function () {
      if (SG.__ready) return; SG.__ready = true;
      log('ready');
      if (backend && backend.ready) safe(backend.ready);
    },
    gameplayStart: function () { log('gameplayStart'); if (backend && backend.gameplayStart) safe(backend.gameplayStart); },
    gameplayStop: function () { log('gameplayStop'); if (backend && backend.gameplayStop) safe(backend.gameplayStop); },
    // integer score for platform leaderboards (Snapchat) / score APIs; call at game over / level end
    score: function (value, opts) {
      var v = Math.round(Number(value) || 0);
      log('score', v);
      if (backend && backend.score) safe(backend.score, [v, opts || {}]);
    },
    happy: function (type) { log('happy', type); if (backend && backend.happy) safe(backend.happy, [type]); },
    sad: function (type) { log('sad', type); if (backend && backend.sad) safe(backend.sad, [type]); },

    interstitial: function (placement) {
      placement = placement || 'next';
      var now = Date.now();
      if (!features.interstitial || !backend || !backend.interstitial) { log('interstitial_skip', { placement: placement, reason: 'unsupported' }); return Promise.resolve({ shown: false, reason: 'unsupported' }); }
      if (now - lastGesture > GESTURE_WINDOW_MS) { log('interstitial_skip', { placement: placement, reason: 'no_gesture' }); return Promise.resolve({ shown: false, reason: 'no_gesture' }); }
      var minGap = (CFG.minInterstitialGapSec || 0) * 1000;
      if (minGap && now - lastInterstitial < minGap) { log('interstitial_skip', { placement: placement, reason: 'cooldown' }); return Promise.resolve({ shown: false, reason: 'cooldown' }); }
      log('interstitial_request', placement);
      return Promise.resolve()
        .then(function () { return backend.interstitial(placement, { pause: function () { setPause('ad', true); }, resume: function () { setPause('ad', false); } }); })
        .catch(function (e) { log('interstitial_error', String(e && e.message || e)); return false; })
        .then(function (shown) {
          setPause('ad', false);
          if (shown) lastInterstitial = Date.now();
          log('interstitial_done', { placement: placement, shown: !!shown });
          return { shown: !!shown };
        });
    },

    canReward: function () { return !!(features.rewarded && backend && backend.rewarded && (!backend.canReward || backend.canReward())); },

    rewarded: function (name) {
      name = name || 'reward';
      if (!SG.canReward()) { log('rewarded_skip', name); return Promise.resolve({ rewarded: false, reason: 'unsupported' }); }
      log('rewarded_request', name);
      return Promise.resolve()
        .then(function () { return backend.rewarded(name, { pause: function () { setPause('ad', true); }, resume: function () { setPause('ad', false); } }); })
        .catch(function (e) { log('rewarded_error', String(e && e.message || e)); return false; })
        .then(function (ok) {
          setPause('ad', false);
          log('rewarded_done', { name: name, rewarded: !!ok });
          return { rewarded: !!ok };
        });
    },

    onPause: function (cb) { if (typeof cb === 'function') pauseCbs.push(cb); },
    onResume: function (cb) { if (typeof cb === 'function') resumeCbs.push(cb); },
    onAudioChange: function (cb) { if (typeof cb === 'function') audioCbs.push(cb); },

    storage: {
      load: function (keys) {
        keys = (keys || []).map(String);
        var b = backend;
        return Promise.resolve()
          .then(function () { return b && b.storageLoad ? b.storageLoad(keys) : {}; })
          .catch(function (e) { log('storage_error', String(e && e.message || e)); return {}; })
          .then(function (obj) {
            obj = obj || {};
            keys.forEach(function (k) {
              var raw = obj[k];
              if (raw === undefined || raw === null) { cache[k] = null; return; }
              try { cache[k] = JSON.parse(raw); } catch (e) { cache[k] = raw; }
            });
            log('storage_load', keys);
            return SG.storage.snapshot();
          });
      },
      get: function (k) { return Object.prototype.hasOwnProperty.call(cache, k) ? cache[k] : null; },
      set: function (k, v) {
        cache[k] = v;
        var raw = JSON.stringify(v === undefined ? null : v);
        if (backend && backend.storageSet) {
          return Promise.resolve().then(function () { return backend.storageSet(String(k), raw); })
            .catch(function (e) { log('storage_error', String(e && e.message || e)); });
        }
        return Promise.resolve();
      },
      remove: function (k) {
        delete cache[k];
        if (backend && backend.storageRemove) return Promise.resolve().then(function () { return backend.storageRemove(String(k)); }).catch(function () {});
        return Promise.resolve();
      },
      snapshot: function () { var o = {}; for (var k in cache) o[k] = cache[k]; return o; }
    },

    // helper for games: display name lookup from per-platform naming map
    name: function (key, fallback) {
      var n = CFG.names || {};
      return Object.prototype.hasOwnProperty.call(n, key) ? n[key] : (fallback === undefined ? key : fallback);
    }
  };

  window.SG = SG;
})();
