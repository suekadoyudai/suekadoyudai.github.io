window.SG_CONFIG = {
 "pauseOnBlur": false,
 "platform": "meta",
 "title": "Kiln and Wheel Studio",
 "names": {
  "title": "KILN AND WHEEL STUDIO"
 },
 "ids": {},
 "brand": "SuedoGaming"
};
