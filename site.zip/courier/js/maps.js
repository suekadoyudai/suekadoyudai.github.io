'use strict';
// World maps. Large outdoor maps are composed with a small builder; interiors and dungeons are drawn in ASCII.
(function () {
  const LEG = {
    '.': 'grass', ',': 'flowers', '"': 'tallgrass', ':': 'dirt', '=': 'cobble', '_': 'plaza', 's': 'sand', '~': 'water', 'w': 'deepwater',
    '^': 'rockwall', 'C': 'cliff', 'i': 'cliftop', 'T': 'tree', 'F': 'forest', 'b': 'bush', 'o': 'rock', 'f': 'fence', 'B': 'bridge', 'H': 'hbridge',
    '+': 'floor', '-': 'stonefloor', 'm': 'metalfloor', '#': 'wall', 'W': 'iwall', 'O': 'iwindow', 'K': 'walltop', 'L': 'lamp', 'x': 'crate', 'r': 'barrel',
    'S': 'stairs', 'p': 'pot', 'n': 'counter', 'q': 'table', 'h': 'chair', 'y': 'bedtop', 'Y': 'bedbot', 'l': 'shelf', 'd': 'desk', 'D': 'doormat',
    '%': 'rubble', 'u': 'puddle', 'e': 'ember', 'v': 'void', 'g': 'gearfloor', 'k': 'cloud', 'E': 'cloudedge', 'V': 'skyvoid', 'G': 'goldfloor', 'P': 'pillar',
    'z': 'seafloor', 'R': 'coral', 'Z': 'seaweed', 'A': 'brass', 'j': 'pipe', 't': 'grate', 'c': 'crystal', 'M': 'mushroom', '*': 'letters', 'X': 'stump',
    'Q': 'lava', 'I': 'ice', 'U': 'carpet', 'J': 'rug', '@': 'lensbench', '&': 'well', 'N': 'sign', '$': 'stall', 'a': 'statueplinth', '0': 'mailbox',
  };
  G.LEG = LEG;
  class B {
    constructor(w, h, fill = '.') { this.w = w; this.h = h; this.g = Array.from({ length: h }, () => Array(w).fill(fill)); this.stamps = []; }
    set(x, y, c) { if (x >= 0 && y >= 0 && x < this.w && y < this.h) this.g[y][x] = c; return this; }
    get(x, y) { return (x >= 0 && y >= 0 && x < this.w && y < this.h) ? this.g[y][x] : null; }
    rect(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, c); return this; }
    frame(x, y, w, h, c) { for (let i = 0; i < w; i++) { this.set(x + i, y, c); this.set(x + i, y + h - 1, c); } for (let j = 0; j < h; j++) { this.set(x, y + j, c); this.set(x + w - 1, y + j, c); } return this; }
    pts(list, c) { for (const [x, y] of list) this.set(x, y, c); return this; }
    path(pts, c, wd = 2) {
      for (let k = 0; k + 1 < pts.length; k++) {
        let [x0, y0] = pts[k]; const [x1, y1] = pts[k + 1];
        while (x0 !== x1 || y0 !== y1) { this.rect(x0, y0, wd, wd, c); if (x0 !== x1) x0 += Math.sign(x1 - x0); else y0 += Math.sign(y1 - y0); }
        this.rect(x1, y1, wd, wd, c);
      }
      return this;
    }
    scatter(c, n, x, y, w, h, on = ['.'], seed = 1) { const r = G.rng(seed); let tries = 0; while (n > 0 && tries++ < n * 40) { const X = x + Math.floor(r() * w), Y = y + Math.floor(r() * h); if (on.includes(this.get(X, Y))) { this.set(X, Y, c); n--; } } return this; }
    ascii(rows, ox = 0, oy = 0) { rows.forEach((row, j) => { if (!ox && !oy && row.length !== this.w) throw new Error('row ' + j + ' len ' + row.length + ' != ' + this.w); for (let i = 0; i < row.length; i++) if (row[i] !== ' ') this.set(ox + i, oy + j, row[i]); }); return this; }
    stamp(s) { this.stamps.push(s); return this; }
    house(x, y, w, h, o = {}) { this.rect(x, y, w, h, o.ground || '.'); this.stamps.push(Object.assign({ type: 'house', x, y, w, h }, o)); return this; }
    rows() { return this.g.map(r => r.join('')); }
  }
  G.MapBuilder = B;
  const M = G.MAPS = {};
  const map = (id, def) => { M[id] = def; def.id = id; };
  const fromAscii = rows => { const b = new B(rows[0].length, rows.length); b.ascii(rows); return b; };

  // ======================= 1206 =======================
  map('haru_home', {
    name: 'リオの家', era: '1206', theme: 'house', music: 'town', indoor: 1,
    grid: ['KKKKKKKKKKKK', 'KWWOWWWWOWWK', 'Kl+++++d++yK', 'K+++++++++YK', 'K++qq++++++K', 'K++h+++JJ++K', 'Kp+++++JJ++K', 'K++++++++++K', 'KKKKKDDKKKKK'],
    warps: [{ x: 5, y: 8, w: 2, to: 'hasune', tx: 5, ty: 8, dir: 'down' }],
    npcs: [{ id: 'mom', ch: 'mom', x: 3, y: 6, dir: 'right', talk: 'mom' }],
    objects: [{ type: 'chest', id: 'home1', x: 1, y: 7, item: 'salve', n: 2 }],
  });

  (function () {
    const b = new B(40, 30, '.');
    b.rect(0, 0, 40, 1, 'F'); b.rect(0, 0, 1, 23, 'F'); b.rect(39, 0, 1, 23, 'F');
    for (let x = 2; x < 38; x += 3) b.set(x, 1, 'T');
    b.pts([[1, 4], [1, 7], [1, 12], [1, 16], [38, 4], [38, 15], [38, 18]], 'T');
    // streets
    b.rect(1, 9, 39, 2, '=');
    b.rect(14, 11, 14, 9, '='); b.rect(19, 19, 2, 2, '=');
    b.rect(1, 20, 38, 2, '=');
    b.rect(5, 8, 1, 1, '='); b.rect(14, 8, 1, 1, '='); b.rect(25, 8, 1, 1, '='); b.rect(33, 8, 1, 1, '=');
    b.rect(5, 19, 1, 1, '='); b.rect(33, 18, 1, 2, '='); b.rect(12, 18, 1, 2, '=');
    // shore
    b.rect(1, 22, 38, 1, 's'); b.rect(0, 23, 40, 7, '~'); b.rect(0, 22, 1, 1, 's'); b.rect(39, 22, 1, 1, 's');
    b.rect(7, 22, 2, 6, 'B'); b.rect(30, 22, 2, 5, 'B');
    // buildings
    b.house(3, 3, 5, 5, { roof: 'red', door: 2 });
    b.house(11, 2, 8, 6, { roof: 'teal', door: 3, sign: 'post', chimney: 1 });
    b.house(23, 3, 6, 5, { roof: 'brown', door: 2, sign: 'lens', chimney: 1 });
    b.house(31, 3, 5, 5, { roof: 'slate', door: 2 });
    b.house(3, 14, 6, 5, { roof: 'teal', door: 2, sign: 'inn' });
    b.house(10, 14, 4, 4, { roof: 'red', door: 2 });
    b.house(30, 13, 7, 5, { roof: 'stone', door: 3, sign: 'museum', wall: 'stone' });
    b.stamp({ type: 'stall', x: 15, y: 12, w: 3, awning: '#c9473d' }); b.rect(15, 12, 3, 2, '=');
    b.stamp({ type: 'stall', x: 23, y: 12, w: 3, awning: '#3765b0' });
    b.stamp({ type: 'fountain', x: 19, y: 15 });
    // decoration
    b.pts([[9, 8], [21, 8], [29, 8], [37, 8], [13, 11], [28, 11], [13, 19], [28, 19], [2, 19], [37, 19]], 'L');
    b.scatter(',', 18, 1, 2, 38, 6, ['.'], 3); b.scatter('b', 6, 1, 2, 38, 6, ['.'], 5);
    b.pts([[9, 3], [9, 4], [20, 3], [21, 3], [29, 4], [37, 6]], 'b');
    b.scatter(',', 8, 1, 12, 38, 7, ['.'], 9);
    b.pts([[10, 21], [11, 21], [27, 21], [36, 21], [6, 21]], 'x'); b.pts([[12, 21], [28, 21], [35, 21]], 'r');
    b.pts([[15, 18], [24, 18]], 'p'); b.set(9, 13, 'N');
    b.stamp({ type: 'boat', x: 11, y: 24 }); b.stamp({ type: 'boat', x: 24, y: 25 });
    b.stamp({ type: 'garland', x0: 14, x1: 27, y: 11 }); b.stamp({ type: 'garland', x0: 1, x1: 38, y: 9 });
    map('hasune', {
      name: '港町ハスネ', era: '1206', theme: 'hasune', music: 'town', grid: b.rows(), stamps: b.stamps,
      warps: [
        { x: 5, y: 7, to: 'haru_home', tx: 5, ty: 7, dir: 'up' },
        { x: 14, y: 7, to: 'post_office', tx: 6, ty: 8, dir: 'up' },
        { x: 25, y: 7, to: 'mio_shop', tx: 5, ty: 7, dir: 'up' },
        { x: 39, y: 9, h: 2, to: 'cape', tx: 1, ty: 12, dir: 'right' },
      ],
      npcs: [
        { id: 'innkeep', ch: 'woman2', x: 5, y: 19, dir: 'down', talk: 'inn_hasune' },
        { id: 'shop_h1', ch: 'merchant', x: 16, y: 12, dir: 'down', talk: 'shop_hasune', still: 1 },
        { id: 'shop_h2', ch: 'man2', x: 24, y: 12, dir: 'down', talk: 'shop_hasune', still: 1 },
        { id: 'curator', ch: 'curator', x: 34, y: 18, dir: 'down', talk: 'curator' },
        { id: 'fisher1', ch: 'fisher', x: 8, y: 26, dir: 'down', talk: 'fisher1' },
        { id: 'kid1', ch: 'kid', x: 21, y: 17, dir: 'left', talk: 'kid1', wander: 2 },
        { id: 'girl1', ch: 'girl', x: 17, y: 16, dir: 'right', talk: 'girl1', wander: 2 },
        { id: 'oldw1', ch: 'oldwoman', x: 26, y: 15, dir: 'left', talk: 'oldw1' },
        { id: 'man1', ch: 'man', x: 30, y: 10, dir: 'left', talk: 'man1', wander: 3 },
        { id: 'woman1', ch: 'woman', x: 9, y: 10, dir: 'right', talk: 'woman1', wander: 3 },
        { id: 'sailor', ch: 'man2', x: 31, y: 24, dir: 'down', talk: 'sailor' },
        { id: 'elder1', ch: 'elder', x: 36, y: 10, dir: 'left', talk: 'elder1' },
      ],
      objects: [
        { type: 'door', x: 33, y: 7, text: '鍵がかかっている。' },
        { type: 'door', x: 33, y: 17, text: '「本日、灯り祭りのため休館」と書いてある。' },
        { type: 'door', x: 12, y: 17, text: '留守のようだ。' },
        { type: 'sign', x: 9, y: 13, text: '港町ハスネ　灯り祭り　—　今夜、灯台に新しい灯がともります' },
        { type: 'chest', id: 'has1', x: 1, y: 21, item: 'salve', n: 1 },
      ],
    });
  })();

  map('post_office', {
    name: 'ハスネ郵便局', era: '1206', theme: 'house', music: 'town', indoor: 1,
    grid: ['KKKKKKKKKKKKKK', 'KWOWWllllWWOWK', 'K+++++++++++*K', 'K+nnnnnnn+++*K', 'K++++++++++++K', 'K+++++++q+++xK', 'K+r+++++h+++xK', 'K++++++++++++K', 'K*+++++++++*+K', 'KKKKKKDDKKKKKK'],
    warps: [{ x: 6, y: 9, w: 2, to: 'hasune', tx: 14, ty: 8, dir: 'down' }],
    npcs: [
      { id: 'gen', ch: 'gen', x: 5, y: 2, dir: 'down', talk: 'gen' },
      { id: 'clerk', ch: 'woman2', x: 8, y: 2, dir: 'down', talk: 'clerk' },
      { id: 'postman', ch: 'man', x: 10, y: 6, dir: 'left', talk: 'postman' },
      { id: 'racer', ch: 'man2', x: 3, y: 5, dir: 'right', talk: 'race' },
    ],
    objects: [{ type: 'chest', id: 'po1', x: 1, y: 7, item: 'dew', n: 1 }],
  });
  map('mio_shop', {
    name: 'レンズ工房', era: '1206', theme: 'house', music: 'town', indoor: 1,
    grid: ['KKKKKKKKKKKK', 'KWOWWllWWOWK', 'K@+@+++++++K', 'K++++++++d+K', 'K++qq++++++K', 'K++++++++++K', 'Kx++++++++pK', 'Kxr+++++++pK', 'KKKKKDDKKKKK'],
    warps: [{ x: 5, y: 8, w: 2, to: 'hasune', tx: 25, ty: 8, dir: 'down' }],
    npcs: [{ id: 'mio', ch: 'mio', x: 6, y: 3, dir: 'up', talk: 'mio_shop' }, { id: 'miodad', ch: 'keeper', x: 9, y: 5, dir: 'left', talk: 'miodad' }],
    objects: [{ type: 'chest', id: 'mio1', x: 10, y: 4, item: 't_brass', n: 1 }],
  });

  (function () {
    const b = new B(44, 26, '.');
    b.rect(0, 0, 44, 2, 'F'); b.rect(0, 0, 2, 9, 'F');
    // sea on the south and east, cliffs above it
    b.rect(0, 21, 44, 5, '~'); b.rect(40, 0, 4, 26, '~');
    b.rect(2, 20, 38, 1, 'i'); b.rect(39, 2, 1, 19, 'i');
    b.rect(34, 15, 6, 6, '~'); b.rect(33, 14, 7, 1, 'i'); b.rect(33, 15, 1, 6, 'i');
    b.rect(0, 15, 2, 6, 'F');
    // the road from town to the lighthouse
    b.path([[0, 12], [6, 12], [6, 16], [14, 16], [14, 11], [22, 11], [22, 7], [30, 7], [30, 5], [35, 5]], ':', 2);
    b.path([[28, 9], [28, 12], [30, 12]], ':', 2);
    // clusters of trees, tall grass, rocks
    b.pts([[3, 3], [6, 2], [9, 3], [12, 2], [4, 6], [8, 7], [11, 5], [17, 3], [20, 2], [16, 6], [25, 2], [2, 9], [10, 9], [3, 18], [20, 18], [24, 16], [27, 18], [17, 14], [9, 18]], 'T');
    b.scatter('"', 40, 2, 2, 36, 18, ['.'], 11); b.scatter(',', 26, 2, 2, 36, 18, ['.'], 12);
    b.scatter('o', 8, 2, 2, 36, 18, ['.', '"'], 13); b.scatter('b', 10, 2, 2, 36, 18, ['.', '"'], 14);
    b.rect(34, 3, 5, 4, '='); b.rect(29, 11, 4, 3, '.');
    b.stamp({ type: 'lighthouse', x: 35, y: 1 });
    b.stamp({ type: 'fencerow', x0: 30, x1: 32, y: 14 });
    map('cape', {
      name: '灯台岬', era: '1206', theme: 'hasune', music: 'field', grid: b.rows(), stamps: b.stamps,
      warps: [{ x: 0, y: 12, h: 2, to: 'hasune', tx: 38, ty: 9, dir: 'left' }, { x: 36, y: 5, to: 'lighthouse', tx: 5, ty: 7, dir: 'up' }],
      objects: [
        { type: 'post', x: 31, y: 12, era: '1206' },
        { type: 'chest', id: 'cape1', x: 3, y: 16, item: 'salve', n: 2 },
        { type: 'chest', id: 'cape2', x: 26, y: 3, item: 'h_leather', n: 1 },
        { type: 'sign', x: 13, y: 12, text: '← ハスネ　　灯台岬 →' },
      ],
      encounters: [
        { x: 9, y: 13, foes: [['inkblob', 0, -2], ['inkblob', 3, -1]] },
        { x: 13, y: 7, foes: [['envbat', -1, -2], ['envbat', 2, -2]] },
        { x: 18, y: 14, foes: [['inkblob', -2, -2], ['envbat', 1, -3], ['inkblob', 3, -1]] },
        { x: 25, y: 9, foes: [['stampcrab', 0, -2]] },
        { x: 30, y: 4, foes: [['envbat', -2, 0], ['stampcrab', 1, -1]], cond: 'p>=2' },
      ],
    });
  })();
  map('lighthouse', {
    name: '灯台の上', era: '1206', theme: 'hasune', music: null, indoor: 1, tint: 'night',
    grid: ['vvvvvvvvvvvv', 'vKKKKKKKKKKv', 'vKWOWWWWOWKv', 'vK--------Kv', 'vK--------Kv', 'vK--------Kv', 'vK--------Kv', 'vK--------Kv', 'vKKKKSSKKKKv', 'vvvvvvvvvvvv'],
    stamps: [{ type: 'biglens', x: 5, y: 3 }],
    warps: [{ x: 5, y: 8, w: 2, to: 'cape', tx: 36, ty: 6, dir: 'down' }],
  });

  // ======================= 806 =======================
  (function () {
    const b = new B(44, 26, '.');
    b.rect(0, 0, 44, 2, 'F'); b.rect(0, 0, 2, 9, 'F');
    b.rect(0, 21, 44, 5, '~'); b.rect(40, 0, 4, 26, '~');
    b.rect(2, 20, 38, 1, 'i'); b.rect(39, 2, 1, 19, 'i');
    b.rect(34, 15, 6, 6, '~'); b.rect(33, 14, 7, 1, 'i'); b.rect(33, 15, 1, 6, 'i');
    b.rect(0, 15, 2, 6, 'F');
    b.path([[0, 12], [6, 12], [6, 16], [14, 16], [14, 11], [22, 11], [22, 7], [30, 7], [30, 5], [35, 5]], ':', 2);
    b.path([[28, 9], [28, 12], [30, 12]], ':', 2);
    b.pts([[3, 3], [6, 2], [9, 3], [12, 2], [4, 6], [8, 7], [11, 5], [17, 3], [20, 2], [16, 6], [25, 2], [2, 9], [10, 9], [3, 18], [20, 18], [24, 16], [27, 18], [17, 14], [9, 18], [21, 15], [12, 19]], 'T');
    b.scatter('"', 46, 2, 2, 36, 18, ['.'], 21); b.scatter('o', 10, 2, 2, 36, 18, ['.', '"'], 23);
    b.rect(33, 3, 6, 4, ':');
    b.stamp({ type: 'beacon', x: 35, y: 1 });
    b.stamp({ type: 'tent', x: 24, y: 9 }); b.stamp({ type: 'tent', x: 19, y: 8 });
    b.pts([[22, 9]], 'x'); b.pts([[27, 8]], 'r');
    map('cape806', {
      name: 'のろし岬', era: '806', theme: 'varn', music: 'varn', grid: b.rows(), stamps: b.stamps,
      warps: [{ x: 0, y: 12, h: 2, to: 'varn', tx: 34, ty: 14, dir: 'left' }],
      npcs: [
        { id: 'dan', ch: 'soldier', x: 31, y: 6, dir: 'down', talk: 'dan' },
        { id: 'soldier2', ch: 'soldier', x: 23, y: 12, dir: 'left', talk: 'soldier2' },
      ],
      objects: [
        { type: 'post', x: 31, y: 12, era: '806' },
        { type: 'campfire', x: 22, y: 12 },
        { type: 'chest', id: 'c806a', x: 3, y: 16, item: 'hisalve', n: 1 },
        { type: 'chest', id: 'c806b', x: 26, y: 3, item: 'dew', n: 1 },
      ],
      encounters: [
        { x: 9, y: 13, foes: [['emberwolf', 0, -2], ['emberwolf', 3, -1]], cond: 'p>=5' },
        { x: 17, y: 9, foes: [['lanternshroom', -1, -2], ['inkred', 2, -2]], cond: 'p>=5' },
      ],
    });
  })();
  (function () {
    const b = new B(36, 28, '.');
    b.rect(0, 0, 36, 1, 'F'); b.rect(0, 0, 1, 28, 'F'); b.rect(35, 0, 1, 28, 'F'); b.rect(0, 27, 36, 1, 'F');
    b.rect(16, 0, 3, 1, ':');
    // river
    b.rect(1, 20, 34, 2, '~'); b.rect(10, 20, 2, 2, 'B'); b.rect(26, 20, 2, 2, 'B');
    b.path([[17, 0], [17, 6], [10, 6], [10, 14], [34, 14]], ':', 2);
    b.path([[17, 6], [26, 6], [26, 14]], ':', 2);
    b.path([[10, 14], [10, 23], [26, 23], [26, 14]], ':', 2);
    b.house(3, 2, 5, 4, { roof: 'thatch', door: 2, wall: 'wood' });
    b.house(21, 2, 9, 6, { roof: 'slate', door: 4, wall: 'stone', sign: 'church', bell: 1 });
    b.house(3, 9, 6, 5, { roof: 'thatch', door: 2, wall: 'wood', sign: 'inn' });
    b.house(13, 9, 5, 4, { roof: 'thatch', door: 2, wall: 'wood' });
    b.house(29, 8, 5, 5, { roof: 'thatch', door: 2, wall: 'stone' });
    b.house(3, 15, 5, 4, { roof: 'thatch', door: 2, wall: 'wood' });
    b.stamp({ type: 'stall', x: 18, y: 15, w: 3, awning: '#8a6a30' });
    b.rect(13, 16, 1, 2, ':');
    b.rect(2, 23, 7, 3, 'f'); b.rect(3, 24, 5, 1, '"'); b.rect(28, 23, 6, 3, 'f'); b.rect(29, 24, 4, 1, '"');
    b.set(14, 18, '&');
    b.pts([[2, 7], [33, 4], [12, 3], [33, 18], [19, 25], [14, 25], [2, 19], [31, 1]], 'T');
    b.scatter(',', 14, 1, 1, 34, 26, ['.'], 31); b.scatter('"', 20, 1, 1, 34, 26, ['.'], 32);
    map('varn', {
      name: 'ヴァルン村', era: '806', theme: 'varn', music: 'varn', grid: b.rows(), stamps: b.stamps,
      warps: [{ x: 35, y: 14, h: 2, to: 'cape806', tx: 1, ty: 12, dir: 'right' }, { x: 16, y: 0, w: 3, to: 'emberforest', tx: 21, ty: 28, dir: 'up', cond: 'p>=5', fail: 'forest_locked' }],
      npcs: [
        { id: 'elderv', ch: 'elder', x: 15, y: 13, dir: 'down', talk: 'elderv' },
        { id: 'innv', ch: 'woman', x: 5, y: 14, dir: 'down', talk: 'inn_varn' },
        { id: 'shopv', ch: 'merchant', x: 19, y: 15, dir: 'down', talk: 'shop_varn', still: 1 },
        { id: 'martha', ch: 'oldwoman', x: 31, y: 13, dir: 'down', talk: 'martha' },
        { id: 'toma', ch: 'toma', x: 25, y: 9, dir: 'down', talk: 'toma' },
        { id: 'monk', ch: 'monk', x: 22, y: 9, dir: 'down', talk: 'monk' },
        { id: 'farmer', ch: 'man', x: 25, y: 25, dir: 'left', talk: 'farmer', wander: 2 },
        { id: 'vkid', ch: 'kid', x: 12, y: 17, dir: 'right', talk: 'vkid', wander: 3 },
        { id: 'vsold', ch: 'soldier', x: 17, y: 2, dir: 'down', talk: 'vsold' },
      ],
      objects: [
        { type: 'door', x: 5, y: 5, text: '扉は閉まっている。' }, { type: 'door', x: 15, y: 12, text: '村長の家だ。' }, { type: 'door', x: 31, y: 12, text: 'ヘレナの家だ。' },
        { type: 'door', x: 25, y: 7, text: '修道院の扉。祈りの声が聞こえる。' }, { type: 'door', x: 5, y: 18, text: '鍛冶屋の家だ。' },
        { type: 'chest', id: 'v1', x: 1, y: 25, item: 'revive', n: 1 },
        { type: 'save', x: 9, y: 16 },
      ],
    });
  })();
  (function () {
    const b = new B(44, 30, 'F');
    // a winding forest trail
    b.path([[20, 29], [20, 24], [10, 24], [10, 16], [18, 16], [18, 10], [8, 10], [8, 4], [20, 4], [20, 2]], '.', 4);
    b.path([[18, 16], [32, 16], [32, 8], [24, 8]], '.', 4);
    b.path([[32, 16], [32, 24], [26, 24]], '.', 3);
    b.path([[20, 28], [20, 25], [11, 25], [11, 17], [19, 17], [19, 11], [9, 11], [9, 5], [21, 5], [21, 1]], ':', 2);
    b.rect(26, 20, 6, 3, '~'); b.rect(28, 20, 2, 3, 'B');
    b.scatter('T', 26, 1, 1, 42, 28, ['.'], 41); b.scatter('"', 30, 1, 1, 42, 28, ['.'], 42); b.scatter('M', 6, 1, 1, 42, 28, ['.'], 43); b.scatter('X', 5, 1, 1, 42, 28, ['.'], 44);
    b.rect(19, 0, 4, 1, '^'); b.rect(17, 0, 2, 2, '^'); b.rect(23, 0, 2, 2, '^');
    b.stamp({ type: 'cave', x: 20, y: 0 });
    map('emberforest', {
      name: '燠火の森', era: '806', theme: 'varn', music: 'field', grid: b.rows(), stamps: b.stamps, particles: 'leaves',
      warps: [{ x: 20, y: 29, w: 4, to: 'varn', tx: 17, ty: 1, dir: 'down' }, { x: 21, y: 1, w: 1, to: 'embercave', tx: 18, ty: 28, dir: 'up' }],
      objects: [
        { type: 'chest', id: 'f1', x: 33, y: 9, item: 'hisalve', n: 1 }, { type: 'chest', id: 'f2', x: 27, y: 25, item: 'b_chain', n: 1 },
        { type: 'chest', id: 'f3', x: 9, y: 4, item: 'dew', n: 2 }, { type: 'save', x: 23, y: 4 },
      ],
      encounters: [
        { x: 13, y: 24, foes: [['emberwolf', -2, -1], ['emberwolf', 2, 0]] },
        { x: 11, y: 18, foes: [['lanternshroom', 0, -3], ['inkred', 3, -2]] },
        { x: 14, y: 11, foes: [['emberwolf', -2, -1], ['lanternshroom', 1, -2], ['emberwolf', 3, 0]] },
        { x: 26, y: 17, foes: [['inkred', -2, -1], ['inkred', 1, -2], ['inkred', 3, 0]] },
        { x: 30, y: 9, foes: [['ashsoldier', 0, -1]] },
        { x: 12, y: 5, foes: [['ashsoldier', -1, 0], ['emberwolf', 2, 1]] },
      ],
    });
  })();
  map('embercave', {
    name: '燠火の洞窟', era: '806', theme: 'cave', music: 'ember', particles: 'embers', tint: 'cave',
    grid: [
      '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^----------^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^------------^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^--e----------e-^^^^^^^^^^^^',
      '^^^^^^^^^^^^^--------------^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^------------^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^^^^--^^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^^^^--^^^^^^^^^^^^^^^^^^^',
      '^^^^-------^^^^^^^^--^^^^^^^^^-------^^^',
      '^^^---e-----^^^^^^^--^^^^^^^^---------^^',
      '^^^---------QQQQQQQ--QQQQQQQ---------^^^',
      '^^^---------QQQQQQQ--QQQQQQQ---------^^^',
      '^^^^-------^^QQQQQ----QQQQQ^^-------^^^^',
      '^^^^^--^^^^^^QQQQ------QQQQ^^^^^^--^^^^^',
      '^^^^^--^^^^^^^QQ--------QQ^^^^^^^--^^^^^',
      '^^^^^--^^^^^^^^----------^^^^^^^^--^^^^^',
      '^^^^^-----------------------------^^^^^^',
      '^^^^^---QQQQQQQ--------QQQQQQQ----^^^^^^',
      '^^^^^^^^QQQQQQQ--------QQQQQQQ^^^^^^^^^^',
      '^^^^^^^^^QQQQQ----------QQQQQ^^^^^^^^^^^',
      '^^^^^^^^^^^^^^----------^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^---e------^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^----------^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^QQQ--QQQQ^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^QQQ--QQQQ^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^------^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^------^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^^----^^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^^----^^^^^^^^^^^^^^^^^^^',
      '^^^^^^^^^^^^^^^^^^SS^^^^^^^^^^^^^^^^^^^^',
    ],
    warps: [{ x: 18, y: 29, w: 2, to: 'emberforest', tx: 21, ty: 2, dir: 'down' }],
    objects: [
      { type: 'chest', id: 'ec1', x: 4, y: 9, item: 'w_ash', n: 1 }, { type: 'chest', id: 'ec2', x: 36, y: 9, item: 'l_ash', n: 1 },
      { type: 'chest', id: 'ec3', x: 15, y: 21, item: 'hisalve', n: 2 }, { type: 'chest', id: 'ec4', x: 6, y: 16, item: 'b_ash', n: 1 },
      { type: 'switch', x: 8, y: 11, flag: 'ecA' }, { type: 'switch', x: 33, y: 11, flag: 'ecB' },
      { type: 'gate', x: 19, y: 7, w: 2, flags: ['ecA', 'ecB'], theme: 'cave' },
      { type: 'save', x: 23, y: 15 },
    ],
    encounters: [
      { x: 20, y: 25, foes: [['inkred', -1, -2], ['inkred', 1, 0]] },
      { x: 19, y: 20, foes: [['ashsoldier', -2, -1], ['lanternshroom', 2, -1]] },
      { x: 11, y: 16, foes: [['emberwolf', -2, -1], ['emberwolf', 1, -1]] },
      { x: 28, y: 16, foes: [['ashsoldier', -1, -1], ['ashsoldier', 2, -1]] },
      { x: 7, y: 10, foes: [['lanternshroom', -2, -1], ['inkred', 1, -1], ['lanternshroom', 2, 1]] },
      { x: 32, y: 10, foes: [['emberwolf', -2, -1], ['ashsoldier', 1, -1]] },
      { x: 20, y: 3, boss: 'ashgram', foes: [['ashgram', 0, 0], ['ashclaw', -4, 1], ['ashclaw', 4, 1]], party: [[-2, 5], [0, 6], [2, 5]], cond: '!bossGram' },
    ],
  });

  // ======================= Dead Letter Office =======================
  map('office', {
    name: '宛先不明局', era: '—', theme: 'hub', music: 'hub', indoor: 1, particles: 'letters',
    grid: [
      'vvvvvvvvvvvvvvvvvvvvvvvv',
      'vKKKKKKKKKKKKKKKKKKKKKKv',
      'vKWWlllWWWWOOWWWWlllWWKv',
      'vK*++++++++++++++++++*Kv',
      'vK*+++++++JJJJ+++++++*Kv',
      'vK++++++++JJJJ++++++++Kv',
      'vK+++*++++++++++++*+++Kv',
      'vK++++++++++++++++++++Kv',
      'vK+++++++++dd+++++++++Kv',
      'vK++++++++++++++++++++Kv',
      'vK*+++++++++++++++++**Kv',
      'vK++++++++++++++++++++Kv',
      'vK++++*+++++++++++*+++Kv',
      'vK++++++++++++++++++++Kv',
      'vK*++++++++++++++++++*Kv',
      'vK++++++++++++++++++++Kv',
      'vKKKKKKKKKKKKKKKKKKKKKKv',
      'vvvvvvvvvvvvvvvvvvvvvvvv',
    ],
    npcs: [{ id: 'haco', ch: 'haco', x: 11, y: 7, dir: 'down', talk: 'haco' }],
    objects: [
      { type: 'post', x: 4, y: 4, era: 'go1206', label: '1206' }, { type: 'post', x: 19, y: 4, era: 'go806', label: '806' },
      { type: 'post', x: 4, y: 9, era: 'go2406', label: '2406' }, { type: 'post', x: 19, y: 9, era: 'go800', label: '前800' },
      { type: 'post', x: 11, y: 13, era: 'gofinal', label: '海鳴り' },
      { type: 'save', x: 14, y: 6 },
      { type: 'pile', x: 21, y: 14, script: 'nushi' },
    ],
  });

  // ======================= 2406 =======================
  (function () {
    const b = new B(40, 30, '.');
    b.rect(0, 0, 40, 1, '%'); b.rect(0, 0, 1, 23, '%'); b.rect(39, 0, 1, 23, '%');
    b.rect(1, 9, 38, 2, '='); b.rect(14, 11, 14, 9, '='); b.rect(19, 19, 2, 2, '='); b.rect(1, 20, 38, 2, '=');
    b.rect(5, 8, 1, 1, '='); b.rect(14, 8, 1, 1, '='); b.rect(25, 8, 1, 1, '='); b.rect(33, 8, 1, 1, '=');
    b.rect(1, 22, 38, 1, 's'); b.rect(0, 23, 40, 7, '~'); b.rect(7, 22, 2, 3, 'B');
    b.house(3, 3, 5, 5, { roof: 'ruin', door: 2, wall: 'ruin' });
    b.house(11, 2, 8, 6, { roof: 'ruin', door: 3, wall: 'ruin', sign: 'post' });
    b.house(23, 3, 6, 5, { roof: 'ruin', door: 2, wall: 'ruin' });
    b.house(30, 0, 8, 8, { roof: 'tower', door: 3, wall: 'metal', tall: 1 });
    b.house(3, 14, 6, 5, { roof: 'ruin', door: 2, wall: 'ruin', sign: 'inn' });
    b.house(30, 13, 7, 5, { roof: 'ruin', door: 3, wall: 'ruin' });
    b.stamp({ type: 'fountain', x: 19, y: 15, dry: 1 });
    b.scatter('%', 22, 1, 1, 38, 21, ['.', '='], 51); b.scatter('u', 12, 1, 9, 38, 13, ['='], 52); b.scatter('T', 8, 1, 1, 38, 21, ['.'], 53);
    b.rect(18, 21, 4, 1, '='); b.set(36, 21, 'S'); b.set(37, 21, 'S');
    b.pts([[5, 8], [14, 8], [25, 8], [33, 18], [33, 19], [18, 19], [17, 19], [19, 19], [21, 19], [20, 18]], '=');
    for (const p of [[33, 8], [33, 9], [33, 10], [34, 9], [32, 9]]) b.set(p[0], p[1], '=');
    map('frozen', {
      name: '止まったハスネ', era: '2406', theme: 'future', music: 'frozen', grid: b.rows(), stamps: b.stamps, particles: 'frozenrain', tint: 'frozen',
      warps: [{ x: 36, y: 21, w: 2, to: 'undercanal', tx: 2, ty: 2, dir: 'down' }, { x: 33, y: 7, to: 'tower', tx: 11, ty: 32, dir: 'up', cond: 'p>=10', fail: 'tower_locked' }],
      npcs: [
        { id: 'sou', ch: 'futurekid', x: 22, y: 17, dir: 'left', statue: 1, talk: 'sou' },
        { id: 'nagi', ch: 'futurewoman', x: 9, y: 11, dir: 'right', statue: 1, talk: 'nagi' },
        { id: 'st1', ch: 'futureman', x: 16, y: 10, dir: 'right', statue: 1, talk: 'statue' },
        { id: 'st2', ch: 'futurewoman', x: 26, y: 12, dir: 'down', statue: 1, talk: 'statue' },
        { id: 'st3', ch: 'futureman', x: 29, y: 20, dir: 'left', statue: 1, talk: 'statue' },
        { id: 'st4', ch: 'oldwoman', x: 12, y: 21, dir: 'up', statue: 1, talk: 'statue_old' },
        { id: 'vend', ch: 'haco', x: 5, y: 19, dir: 'down', talk: 'vend', tint: '#57c4e6' },
        { id: 'pipnpc', ch: 'pip', x: 20, y: 12, dir: 'down', talk: 'pipnpc', cond: 'p<10' },
      ],
      objects: [
        { type: 'post', x: 18, y: 18, era: '2406' }, { type: 'save', x: 21, y: 18 },
        { type: 'chest', id: 'fz1', x: 2, y: 2, item: 'fullsalve', n: 1 }, { type: 'chest', id: 'fz2', x: 37, y: 18, item: 'h_fiber', n: 1 },
        { type: 'door', x: 5, y: 7, text: '崩れていて入れない。' }, { type: 'door', x: 14, y: 7, text: '郵便局……だった建物だ。中は瓦礫で埋まっている。' },
        { type: 'door', x: 25, y: 7, text: '割れたレンズの看板が落ちている。' }, { type: 'door', x: 33, y: 17, text: '博物館。扉は動かない。' },
      ],
      encounters: [
        { x: 10, y: 16, foes: [['gearbug', -1, -2], ['gearbug', 2, -1]], cond: 'p>=9' },
        { x: 30, y: 10, foes: [['stopdoll', 0, -1], ['watcheye', 3, -2]], cond: 'p>=9' },
      ],
    });
  })();
  map('undercanal', {
    name: '地下水道', era: '2406', theme: 'future', music: 'canal', tint: 'dark',
    grid: [
      '########################################',
      '#mmmm#######################jjj########',
      '#mmmm#mmmmmmmmmmmm####mmmmmmmmmmmmmm####',
      '#mmmmmmmmmmmmmmmmm####mmmmmmmmmmmmmmm###',
      '#mmmm#mmmmmmmmmmmm####mmmmmmmmmmmmmmm###',
      '##mm####mm#####mm######mm######mm#######',
      '~~mm~~~~mm~~~~~mm~~~~~~mm~~~~~~mm~~~~~~~',
      '~~mm~~~~mm~~~~~mm~~~~~~mm~~~~~~mm~~~~~~~',
      '##mm####mm#####mm######mm######mm#######',
      '#mmmmmmmmmmm#mmmmmmmmmmmmmm#mmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmmmmmmm#mmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmmmmmmm#mmmmmmmmmm##',
      '####mm#######mmmm#####mmmm####mm########',
      '~~~~mm~~~~~~~~~~~~~~~~~~~~~~~~mm~~~~~~~~',
      '~~~~mm~~~~~~~~~~~~~~~~~~~~~~~~mm~~~~~~~~',
      '~~~~mm~~~~~~~~~~~~~~~~~~~~~~~~mm~~~~~~~~',
      '####mm##############mm##############mm##',
      '#mmmmmmmmmmmmmm##mmmmmmmmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmmmmm##mmmmmmmmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmmmmm##mmmmmmmmmmmmmmmmmmmmm##',
      '#####mm#########mm#######mm###mm########',
      '~~~~~mm~~~~~~~~~mm~~~~~~~mm~~~~~~~~~~~~~',
      '~~~~~mm~~~~~~~~~mm~~~~~~~mm~~~~~~~~~~~~~',
      '#####mm#########mm############mm########',
      '#mmmmmmmmmmm#mmmmmmmmm#mmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmm#mmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmm#mmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmm#mmmmmmmmmmmmmmm##',
      '#mmmmmmmmmmm#mmmmmmmmm#mmmmmmmmmmmmmmm##',
      '########################################',
    ],
    warps: [{ x: 1, y: 1, w: 2, to: 'frozen', tx: 36, ty: 20, dir: 'up' }],
    stamps: [{ type: 'ladder', x: 1, y: 1 }],
    objects: [
      { type: 'bridge', x: 13, y: 13, w: 17, h: 3, flag: 'ucA' },
      { type: 'bridge', x: 30, y: 21, w: 2, h: 2, flag: 'ucB' },
      { type: 'switch', x: 33, y: 3, flag: 'ucA' }, { type: 'switch', x: 2, y: 18, flag: 'ucB' },
      { type: 'chest', id: 'uc1', x: 37, y: 9, item: 'a_volt', n: 1 }, { type: 'chest', id: 'uc2', x: 2, y: 27, item: 'fullsalve', n: 1 },
      { type: 'chest', id: 'uc3', x: 10, y: 2, item: 'b_fiber', n: 1 }, { type: 'chest', id: 'uc4', x: 21, y: 27, item: 't_volt', n: 1 },
      { type: 'chest', id: 'uc5', x: 37, y: 26, item: 'k_card', n: 1, script: 'got_card' },
      { type: 'save', x: 14, y: 10 },
    ],
    encounters: [
      { x: 9, y: 3, foes: [['gearbug', 0, -1], ['gearbug', 3, 0]] },
      { x: 23, y: 10, foes: [['stopdoll', -2, -1], ['watcheye', 1, -1]] },
      { x: 6, y: 10, foes: [['watcheye', -1, 0], ['watcheye', 2, -1], ['gearbug', 0, 1]] },
      { x: 25, y: 18, foes: [['stopdoll', -1, -1], ['stopdoll', 2, 0]] },
      { x: 8, y: 18, foes: [['gearbug', -1, -1], ['stopdoll', 2, -1]] },
      { x: 17, y: 25, foes: [['inkgold', 0, 0]], chance: 0.5 },
      { x: 30, y: 25, foes: [['watcheye', -2, -1], ['gearbug', 1, -1], ['watcheye', 3, 0]] },
    ],
  });
  map('tower', {
    name: '時刻管制塔', era: '2406', theme: 'tower', music: 'dungeon', tint: 'dark',
    grid: [
      'vvvvvvvvvvvvvvvvvvvvvvvv',
      'v######################v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v##########mm##########v',
      'v#gggggggg#mm#gggggggg#v',
      'v#gggggggg#mm#gggggggg#v',
      'v#gggggggggmmggggggggg#v',
      'v#gggggggg#mm#gggggggg#v',
      'v####mm####mm####mm####v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmjjmmmmmmmmmmmmjjmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmm########mmmmmm#v',
      'v#mmmmmm#      #mmmmmm#v',
      'v#mmmmmm########mmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v####mm##########mm####v',
      'v#gggggggggggggggggggg#v',
      'v#gggggggggggggggggggg#v',
      'v#gggggggggggggggggggg#v',
      'v##########mm##########v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmjjmmmmmmmmmmmmjjmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v#mmmmmmmmmmmmmmmmmmmm#v',
      'v##########SS##########v',
    ],
    warps: [{ x: 11, y: 33, w: 2, to: 'frozen', tx: 33, ty: 8, dir: 'down' }],
    stamps: [{ type: 'bigclock', x: 9, y: 16 }],
    objects: [
      { type: 'chest', id: 'tw1', x: 2, y: 8, item: 'l_silver', n: 1 }, { type: 'chest', id: 'tw2', x: 21, y: 8, item: 'w_silver', n: 1 },
      { type: 'chest', id: 'tw3', x: 2, y: 21, item: 'bigdew', n: 1 }, { type: 'chest', id: 'tw4', x: 21, y: 21, item: 'c_badge', n: 1 },
      { type: 'save', x: 4, y: 13 },
    ],
    encounters: [
      { x: 8, y: 28, foes: [['gearbug', -1, -1], ['stopdoll', 2, -1]] },
      { x: 15, y: 27, foes: [['watcheye', 0, -1], ['watcheye', 3, 0]] },
      { x: 11, y: 22, foes: [['stopdoll', -2, 0], ['gearbug', 0, -1], ['stopdoll', 2, 0]] },
      { x: 18, y: 14, foes: [['watcheye', -1, 0], ['gearbug', 1, -1]] },
      { x: 6, y: 9, foes: [['stopdoll', 0, 0], ['watcheye', 2, -1]] },
      { x: 17, y: 9, foes: [['gearbug', 0, 0], ['gearbug', 2, 1]] },
      { x: 11, y: 4, boss: 'geargolem', foes: [['geargolem', 0, -1]], party: [[-3, 3], [0, 4], [3, 3]], cond: '!bossGolem' },
    ],
  });

  // ======================= 前800 =======================
  (function () {
    const b = new B(36, 28, 'V');
    // floating islands joined by cloud bridges
    const isl = (x, y, w, h) => { b.rect(x, y, w, h, '.'); b.rect(x, y + h, w, 1, 'E'); };
    isl(3, 3, 12, 9); isl(20, 2, 13, 10); isl(5, 16, 11, 8); isl(21, 16, 12, 8);
    b.rect(15, 6, 5, 2, 'k'); b.rect(9, 12, 2, 4, 'k'); b.rect(26, 12, 2, 4, 'k'); b.rect(16, 19, 5, 2, 'k');
    b.house(22, 3, 9, 6, { roof: 'gold', door: 4, wall: 'marble', sign: 'palace' });
    b.house(4, 4, 5, 4, { roof: 'white', door: 2, wall: 'marble' });
    b.house(6, 17, 5, 4, { roof: 'white', door: 2, wall: 'marble', sign: 'inn' });
    b.stamp({ type: 'stall', x: 11, y: 18, w: 3, awning: '#9ad8f0' });
    b.stamp({ type: 'bigear', x: 24, y: 17 });
    b.pts([[13, 4], [4, 10], [14, 10], [32, 10], [20, 9], [5, 22], [15, 22]], 'T');
    b.scatter(',', 16, 3, 3, 30, 20, ['.'], 61); b.rect(26, 9, 1, 3, 'G'); b.rect(26, 8, 1, 1, 'G');
    map('skyvillage', {
      name: '天の宮', era: '前800', theme: 'sky', music: 'sky', grid: b.rows(), stamps: b.stamps, particles: 'clouds',
      warps: [{ x: 32, y: 20, to: 'geargarden', tx: 2, ty: 28, dir: 'right', cond: 'p>=13', fail: 'garden_locked' }],
      npcs: [
        { id: 'amane', ch: 'amane', x: 26, y: 10, dir: 'down', talk: 'amane', cond: 'p<15' },
        { id: 'yura', ch: 'yura', x: 24, y: 11, dir: 'down', talk: 'yura' },
        { id: 'riku', ch: 'kid', x: 12, y: 8, dir: 'left', talk: 'riku', wander: 2, tint: '#f4f0e4' },
        { id: 'sky1', ch: 'skyman', x: 8, y: 9, dir: 'down', talk: 'sky1' },
        { id: 'sky2', ch: 'skywoman', x: 29, y: 10, dir: 'left', talk: 'sky2' },
        { id: 'skyinn', ch: 'skywoman', x: 8, y: 21, dir: 'down', talk: 'inn_sky' },
        { id: 'skyshop', ch: 'skyman', x: 12, y: 18, dir: 'down', talk: 'shop_sky', still: 1 },
        { id: 'sky3', ch: 'skyman', x: 30, y: 21, dir: 'left', talk: 'sky3' },
      ],
      objects: [
        { type: 'post', x: 17, y: 5, era: '800' }, { type: 'save', x: 14, y: 20 },
        { type: 'door', x: 6, y: 7, text: '天の民の家。風鈴の音がする。' }, { type: 'door', x: 8, y: 20, text: '宿屋だ。' },
        { type: 'door', x: 26, y: 8, text: '宮殿の扉。' },
        { type: 'chest', id: 'sk1', x: 3, y: 3, item: 'allsalve', n: 1 },
      ],
    });
  })();
  map('geargarden', {
    name: '歯車の庭', era: '前800', theme: 'sky', music: 'garden', particles: 'clouds',
    grid: [
      'VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVVGGGGGGVVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVGGGGGGGGVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVGGGGGGGGVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVVEEGGEEVVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVVVVggVVVVVVVVVVVVVVVVVV',
      'VVVVkkkkkkVVVVVVVVVVggVVVVVVVVVkkkkkkVVV',
      'VVVVkkkkkkVVVVVVVVVVggVVVVVVVVVkkkkkkVVV',
      'VVVVkkkkkkggggggggggggggggggggggkkkkkVVV',
      'VVVVkkkkkkggggggggggggggggggggggkkkkkVVV',
      'VVVVEEkkEEVVVVVVVVVVVVVVVVVVVVVEEkkEEVVV',
      'VVVVVVkkVVVVVVVVVVVVVVVVVVVVVVVVVkkVVVVV',
      'VVVVVVkkVVVVVVVGGGGGGGGGVVVVVVVVVkkVVVVV',
      'VVVVVVkkVVVVVVVGGGGGGGGGVVVVVVVVVkkVVVVV',
      'VVVkkkkkkkVVVVVGGGGGGGGGVVVVVVkkkkkkkVVV',
      'VVVkkkkkkkVVVVVEEEGGGEEEVVVVVVkkkkkkkVVV',
      'VVVkkkkkkkVVVVVVVVggVVVVVVVVVVkkkkkkkVVV',
      'VVVEEEkEEEVVVVVVVVggVVVVVVVVVVEEEkEEEVVV',
      'VVVVVVkVVVVVVVVVVVggVVVVVVVVVVVVVkVVVVVV',
      'VVVVVVkVVVVVkkkkkkggkkkkkkkVVVVVVkVVVVVV',
      'VVVVVVkVVVVVkkkkkkkkkkkkkkkVVVVVVkVVVVVV',
      'VVVVVVkkkkkkkkkkkkkkkkkkkkkkkkkkkkVVVVVV',
      'VVVVVVVVVVVVkkkkkkkkkkkkkkkVVVVVVVVVVVVV',
      'VVVVVVVVVVVVEEEEEEkkEEEEEEEVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVVkkVVVVVVVVVVVVVVVVVVVV',
      'VVVVVVVVVVVVVVVVVVkkVVVVVVVVVVVVVVVVVVVV',
      'VVVkkkkkkkkkkkkkkkkkVVVVVVVVVVVVVVVVVVVV',
      'VVkkkkkkkkkkkkkkkkkkVVVVVVVVVVVVVVVVVVVV',
      'VkkkkkkkkkkkkkkkkkkkVVVVVVVVVVVVVVVVVVVV',
      'VEEEEEEEEEEEEEEEEEEEVVVVVVVVVVVVVVVVVVVV',
    ],
    warps: [{ x: 0, y: 28, to: 'skyvillage', tx: 31, ty: 20, dir: 'left' }, { x: 20, y: 1, w: 2, to: 'shrine', tx: 9, ty: 17, dir: 'up' }],
    objects: [
      { type: 'bridge', x: 10, y: 8, w: 21, h: 2, flag: 'ggA', dir: 'h', cloud: 1 },
      { type: 'bridge', x: 20, y: 5, w: 2, h: 3, flag: 'ggB', cloud: 1 },
      { type: 'switch', x: 4, y: 15, flag: 'ggA' }, { type: 'switch', x: 36, y: 15, flag: 'ggB' },
      { type: 'chest', id: 'gg1', x: 5, y: 6, item: 'w_cloud', n: 1 }, { type: 'chest', id: 'gg2', x: 35, y: 6, item: 'a_sky', n: 1 },
      { type: 'chest', id: 'gg3', x: 16, y: 13, item: 'b_feather', n: 1 }, { type: 'chest', id: 'gg4', x: 23, y: 13, item: 't_sky', n: 1 },
      { type: 'chest', id: 'gg5', x: 2, y: 27, item: 'bigdew', n: 1 }, { type: 'save', x: 13, y: 21 },
    ],
    encounters: [
      { x: 10, y: 27, foes: [['cloudjelly', -1, -1], ['cloudjelly', 2, 0]] },
      { x: 15, y: 20, foes: [['pendbird', -2, -1], ['pendbird', 1, -2]] },
      { x: 24, y: 20, foes: [['springknight', 0, -1]] },
      { x: 6, y: 14, foes: [['cloudjelly', -1, 0], ['pendbird', 2, -1]] },
      { x: 33, y: 14, foes: [['springknight', -1, 0], ['cloudjelly', 2, 1]] },
      { x: 19, y: 12, foes: [['pendbird', -2, 0], ['springknight', 1, -1], ['pendbird', 3, 0]] },
    ],
  });
  map('shrine', {
    name: '天の祭壇', era: '前800', theme: 'sky', music: null, particles: 'clouds',
    grid: [
      'VVVVVVVVVVVVVVVVVVVV',
      'VVVVVVGGGGGGGGVVVVVV',
      'VVVVGGGGGGGGGGGGVVVV',
      'VVVGGGGGGGGGGGGGGVVV',
      'VVGGGGGGGGGGGGGGGGVV',
      'VVGGPGGGGGGGGGGPGGVV',
      'VVGGGGGGGGGGGGGGGGVV',
      'VVGGGGGGGGGGGGGGGGVV',
      'VVGGGGGGGGGGGGGGGGVV',
      'VVGGPGGGGGGGGGGPGGVV',
      'VVGGGGGGGGGGGGGGGGVV',
      'VVVGGGGGGGGGGGGGGVVV',
      'VVVVGGGGGGGGGGGGVVVV',
      'VVVVEEEEGGGGEEEEVVVV',
      'VVVVVVVVVGGVVVVVVVVV',
      'VVVVVVVVVGGVVVVVVVVV',
      'VVVVVVVVVGGVVVVVVVVV',
      'VVVVVVVVVGGVVVVVVVVV',
      'VVVVVVVVVGGVVVVVVVVV',
      'VVVVVVVVVEEVVVVVVVVV',
    ],
    warps: [{ x: 9, y: 18, w: 2, to: 'geargarden', tx: 20, ty: 2, dir: 'down' }],
    encounters: [{ x: 9, y: 5, boss: 'queenshadow', foes: [['queenshadow', 0, 0], ['pendulum', -4, 1], ['pendulum', 5, 1]], party: [[-2, 5], [1, 6], [4, 5]], cond: '!bossQueen' }],
    objects: [{ type: 'save', x: 10, y: 15 }],
  });

  // ======================= Final: the sea-floor clock =======================
  map('depths', {
    name: '海鳴りの大時計', era: '—', theme: 'deep', music: 'depths', particles: 'bubbles', tint: 'deep',
    grid: [
      'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAzzzzzzAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAzzzzzzzzAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAzzzzAAAAAAAAAAAAAAAAAA',
      'AAzzzzzzzzAAAAAAAAzzzzAAAAAAAAzzzzzzzzAA',
      'AAzzZzzRzzAAAAAAAAzzzzAAAAAAAAzzRzzZzzAA',
      'AAzzzzzzzzggggggggzzzzggggggggzzzzzzzzAA',
      'AAzzzzzzzzggggggggzzzzggggggggzzzzzzzzAA',
      'AAzzzRzzzzAAAAAAAAAAAAAAAAAAAAzzzzRzzzAA',
      'AAAAzzzAAAAAAAAAAAAAAAAAAAAAAAAAAzzzAAAA',
      'AAAAzzzAAAAAAAAAAAAAAAAAAAAAAAAAAzzzAAAA',
      'AAAAzzzzzzzzzzzzAAAAAAAAzzzzzzzzzzzzAAAA',
      'AAAAzzzzzZzzzzzzAAAAAAAAzzzzzzzZzzzzAAAA',
      'AAAAzzzzzzzzzzzzggggggggzzzzzzzzzzzzAAAA',
      'AAAAzzzzRzzzzzzzggggggggzzzzzzzRzzzzAAAA',
      'AAAAAAAAAAzzzAAAAAAAAAAAAAAzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzAAAAAAAAAAAAAAzzzAAAAAAAAAA',
      'AAzzzzzzzzzzzzzzzzzAAzzzzzzzzzzzzzzzzzAA',
      'AAzzZzzzzzzzzzzzzzzAAzzzzzzzzzzzzzzZzzAA',
      'AAzzzzzzzzRzzzzzzzzggzzzzzzzzRzzzzzzzzAA',
      'AAzzzzzzzzzzzzzzzzzggzzzzzzzzzzzzzzzzzAA',
      'AAAAAAAAAAAAAAAzzzzzzzzzzAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAzzzzzzzzzzAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAzzzzAAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAzzzzAAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAzzzzAAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAzzzzzzAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAzzzzzzAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
    ],
    warps: [{ x: 19, y: 1, w: 2, to: 'heart', tx: 11, ty: 17, dir: 'up' }],
    objects: [
      { type: 'post', x: 22, y: 26, era: 'final' }, { type: 'save', x: 17, y: 26 },
      { type: 'chest', id: 'dp1', x: 3, y: 5, item: 'w_time', n: 1 }, { type: 'chest', id: 'dp2', x: 36, y: 5, item: 't_dawn', n: 1 },
      { type: 'chest', id: 'dp3', x: 5, y: 13, item: 'l_earth', n: 1 }, { type: 'chest', id: 'dp4', x: 34, y: 13, item: 'a_future', n: 1 },
      { type: 'chest', id: 'dp5', x: 3, y: 19, item: 'b_time', n: 1 }, { type: 'chest', id: 'dp6', x: 36, y: 19, item: 'h_time', n: 1 },
      { type: 'chest', id: 'dp7', x: 17, y: 2, item: 'tomorrow', n: 2 }, { type: 'save', x: 21, y: 3 },
    ],
    encounters: [
      { x: 19, y: 22, foes: [['seawisp', -2, -1], ['seawisp', 2, -1]] },
      { x: 9, y: 18, foes: [['shard', -1, -1], ['seawisp', 2, -1]] },
      { x: 29, y: 18, foes: [['shard', 0, -1], ['shard', 3, 0]] },
      { x: 10, y: 12, foes: [['seawisp', -2, 0], ['shard', 1, -1], ['seawisp', 3, 0]] },
      { x: 29, y: 12, foes: [['shard', -1, 0], ['seawisp', 2, -1]] },
      { x: 6, y: 6, foes: [['shard', 0, 0], ['shard', 2, 1]] },
      { x: 34, y: 6, foes: [['seawisp', -1, 0], ['shard', 1, 1]] },
    ],
  });
  map('heart', {
    name: '大時計の心臓', era: '—', theme: 'deep', music: 'stillness', particles: 'bubbles', tint: 'deep',
    grid: [
      'AAAAAAAAAAAAAAAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAAAAAAA',
      'AAAAAAAzzzzzzzzzzAAAAAAA',
      'AAAAAzzzzzzzzzzzzzzAAAAA',
      'AAAAzzzzzzzzzzzzzzzzAAAA',
      'AAAzzzzzzzzzzzzzzzzzzAAA',
      'AAAzzzzzzzzzzzzzzzzzzAAA',
      'AAAzzzzzzzzzzzzzzzzzzAAA',
      'AAAzzzzzzzzzzzzzzzzzzAAA',
      'AAAzzzzzzzzzzzzzzzzzzAAA',
      'AAAAzzzzzzzzzzzzzzzzAAAA',
      'AAAAAzzzzzzzzzzzzzzAAAAA',
      'AAAAAAAzzzzzzzzzzAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAzzzzAAAAAAAAAA',
      'AAAAAAAAAAAAAAAAAAAAAAAA',
    ],
    stamps: [{ type: 'clockface', x: 6, y: 1 }],
    warps: [{ x: 10, y: 18, w: 4, to: 'depths', tx: 19, ty: 2, dir: 'down' }],
    triggers: [{ x: 10, y: 12, w: 4, h: 1, script: 'final_battle', cond: '!bossFinal' }],
  });
})();
