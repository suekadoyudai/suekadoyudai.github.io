'use strict';
// Story and dialogue for ときわたりの郵便屋 (original work, © SuedoGaming)
(function () {
  const F = G.field, D = G.DATA;
  const SC = G.SCRIPTS = {};
  // ---------------- script API ----------------
  const S = G.S = {
    say: (n, t, o) => G.say(n, t, o), nar: (t, o) => G.say(null, t, o), ask: (n, t, c, o) => G.ask(n, t, c, o),
    wait: n => G.wait(n), se: n => G.se(n), bgm: (n, o) => G.bgm(n, o),
    a: id => F.find(id),
    p: n => { if (n == null) return G.flags.p || 0; G.flags.p = n; },
    async walk(id, dirs, speed = 1) {
      const a = F.find(id); if (!a) return;
      a.scripted = true; a.speed = speed;
      const map = { u: 'up', d: 'down', l: 'left', r: 'right', w: 'wait' };
      for (const ch of dirs) a.path.push(map[ch]);
      await G.until(() => !a.path.length && !a.moving && !a.waitT);
    },
    walkAll: (pairs, speed) => Promise.all(pairs.map(([id, d]) => S.walk(id, d, speed))),
    face(id, dir) { const a = F.find(id); if (a) { a.dir = dir; } },
    place(id, x, y, dir) { const a = F.find(id); if (!a) return; a.scripted = true; a.tx = x; a.ty = y; a.x = x * 16; a.y = y * 16; a.moving = 0; a.path = []; if (dir) a.dir = dir; a.visible = true; },
    regroup(dir) { const L = F.leader(); for (const a of F.actors) if (a.party) a.scripted = false; F.placeParty(L.tx, L.ty, dir || L.dir); },
    spawn(id, ch, x, y, dir = 'down', extra = {}) { const a = F.makeActor(id, ch, x, y, dir); Object.assign(a, { npc: { talk: extra.talk || 'none' }, home: [x, y], wt: 9e9 }, extra); F.actors.push(a); return a; },
    remove(id) { F.actors = F.actors.filter(a => a.id !== id); },
    async emote(id, e, t = 50) { const a = F.find(id); if (!a) return; a.emote = e; G.se(e === '!' ? 'ok' : 'cursor'); await G.wait(t); a.emote = null; },
    async hop(id) { const a = F.find(id); if (!a) return; for (let i = 0; i <= 10; i++) { a.z = Math.sin(i / 10 * Math.PI) * 6; await G.wait(1); } a.z = 0; },
    fadeOut: (s = 0.05) => G.fadeTo(1, s), fadeIn: (s = 0.05) => G.fadeTo(0, s),
    async whiteout() { G.fade.color = '#ffffff'; await G.fadeTo(1, 0.03); },
    async give(item, n = 1, quiet) { G.addItem(item, n); if (!quiet) await G.say(null, `${D.ITEMS[item].name}${n > 1 ? ' ×' + n : ''} を手に入れた！`, { se: 'item' }); },
    async letters(keys) { for (const k of keys) G.party.letters[k] = 1; G.se('letter'); await G.notice(`宛先不明の手紙を ${keys.length}通 あずかった`, { icon: 'letter' }); },
    async join(id, lv) { G.addMember(id, lv, G.party.active.length < 3); F.syncParty(); const L = F.leader(); F.placeParty(L.tx, L.ty, L.dir); G.se('levelup'); await G.notice(`${G.memberName(id)}が仲間になった！`); if (!G.party.active.includes(id)) await G.say(null, `（メニューの「ならびかえ」で、戦う3人を選べます）`); },
    async warp(map, x, y, dir, opt) { await F.warp(map, x, y, dir, opt); },
    async pan(x, y, f) { await F.panCam(x * 16 + 8, y * 16 + 8, f); },
    unpan() { F.snapCam(); },
    async battle(o) {
      const foes = o.foes.map(([id, x, y, extra]) => Object.assign({ id, x: x * 16, y: y * 16 }, extra || {}));
      const party = o.party ? o.party.map(([x, y]) => ({ x: x * 16, y: y * 16 })) : null;
      const r = await G.battle.start(Object.assign({}, o, { foes, party }));
      if (r === 'lose') { await G.gameOver(); throw new Error('__gameover'); }
      return r;
    },
    shake: n => G.doShake(n), flash: (c, a) => G.doFlash(c, a),
  };
  G.runScript = async function (id, ctx) {
    const f = SC[id];
    G.cutscene++;
    try {
      if (G.flags.race && ctx && ctx.npc && await G.raceTalk(ctx)) { }
      else if (f) await f(ctx);
      else if (ctx && ctx.npc) await G.say(null, '……');
    } catch (e) { if (e.message !== '__gameover') console.error(e); }
    finally { G.cutscene = Math.max(0, G.cutscene - 1); G.consumeAll(); endScene(); }
  };
  function endScene() { if (G.cutscene === 0 && F.map && F.actors.some(a => a.party && a.scripted)) S.regroup(); }
  G.musicFor = def => def.music;
  G.onMapEnter = async function (id) {
    if (SC['enter_' + id]) { G.cutscene++; try { await SC['enter_' + id](); } catch (e) { if (e.message !== '__gameover') console.error(e); } finally { G.cutscene = Math.max(0, G.cutscene - 1); endScene(); } }
  };
  const p = () => G.flags.p || 0;
  const has = id => G.party.members[id] && G.party.active.includes(id);
  const party = id => !!G.party.members[id];
  // speaker helpers
  const HR = (t, o) => G.say('リオ', t, o), M = (t, o) => G.say('ノエ', t, o), SE = (t, o) => G.say('イオリ', t, o), PI = (t, o) => G.say('チック', t, o), HA = (t, o) => G.say('ポッコ', t, o);
  const N = (t, o) => G.say(null, t, o);

  // ---------------- new game ----------------
  G.newGame = async function (clear) {
    G.overlays.length = 0;
    G.flags = { p: 0 }; G.newParty();
    if (clear) { // new game+: keep levels, equipment and items (not key items or letters)
      G.party.gold = clear.gold || 0;
      for (const [k, n] of Object.entries(clear.items || {})) if (D.ITEMS[k] && D.ITEMS[k].kind !== 'key') G.party.items[k] = n;
      G.party.ng = (clear.ng || 0) + 1; G.party.carry = clear.members;
    }
    G.addMember('haru', 1);
    if (clear && clear.members && clear.members.haru) applyCarry('haru');
    G.mode = 'field';
    G.fade.color = '#000'; G.fade.a = 1;
    G.cutscene++;
    try {
      G.bgm('title', { restart: true });
      G.mode = 'story'; G.fade.a = 0;
      await storyCard(['リオへ。', '', 'この手紙が届くころ、', 'あなたはまだ、なにも知らない。', '', '千二百年あと、世界の時計は止まります。', '止めたのは、あの日の灯台。', '', 'お願い。灯を、ともさないで。']);
      G.fade.a = 1; G.mode = 'field';
      await F.warp('haru_home', 10, 4, 'down', { stayDark: true, nobanner: true });
      G.audio.stop(0.5);
      F.banner = null;
      await G.wait(30);
      await G.fadeTo(0, 0.02);
      G.bgm('town');
      F.banner = { text: '港町ハスネ', era: '1206', t: 0 };
      await G.say('母さん', 'リオ！ いつまで寝てるの。今日は灯り祭りでしょう。');
      await S.walk('haru', 'l');
      await HR('……起きてるって。変な夢、見てただけ。');
      await G.say('母さん', 'ゴロウ局長が呼んでたわよ。祭りの日でも、郵便は休みじゃないんだから。');
      await N('（郵便局は、町の北通りにある。）');
    } finally { G.cutscene--; endScene(); }
  };
  function applyCarry(id) { const c = G.party.carry && G.party.carry[id]; if (!c) return; const m = G.party.members[id]; m.lv = c.lv; m.exp = c.exp; m.eq = Object.assign({}, c.eq); const s = G.stats(id); m.hp = s.maxhp; m.mp = s.maxmp; }
  G.applyCarry = applyCarry;
  async function joinMember(id, lv) {
    await S.join(id, lv);
    if (G.party.carry && G.party.carry[id]) { applyCarry(id); }
  }
  // full-screen letter card
  function storyCard(lines, opt = {}) {
    return new Promise(res => {
      let t = 0;
      const o = {
        kind: 'card',
        update() { t++; if (t > 60 && (G.pressed('ok') || G.pressed('cancel'))) { G.consumeAll(); G.pop(o); res(); } },
        draw() {
          ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H);
          const a = Math.min(1, t / 60);
          ctx.globalAlpha = a;
          const pw = 420, ph = 360, px = (W - pw) / 2, py = (H - ph) / 2;
          ctx.fillStyle = '#efe6d2'; ctx.fillRect(px, py, pw, ph);
          ctx.fillStyle = '#d8ccb0'; for (let y = py + 46; y < py + ph - 10; y += 28) ctx.fillRect(px + 20, y, pw - 40, 1);
          lines.forEach((l, i) => { const k = Math.min(1, Math.max(0, (t - 30 - i * 14) / 30)); ctx.globalAlpha = a * k; G.text(l, px + 36, py + 24 + i * 28, '#2a2440', 'left', 16, null); });
          ctx.globalAlpha = a;
          if (opt.stamp !== false) { ctx.save(); ctx.translate(px + pw - 70, py + 60); ctx.rotate(-0.2); ctx.strokeStyle = '#c9473d'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 32, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, 26, 0, Math.PI * 2); ctx.stroke(); G.text(opt.year || '2406', 0, -14, '#c9473d', 'center', 13, null); G.text(opt.place || 'ハスネ', 0, 2, '#c9473d', 'center', 11, null); ctx.restore(); }
          ctx.globalAlpha = 1;
        },
      };
      G.push(o);
    });
  }
  G.storyCard = storyCard;

  // ---------------- 1206: Hasune ----------------
  SC.mom = async () => {
    if (G.party.letters.L7 && !G.party.delivered.L7) return deliver('L7', async () => {
      await HR('母さん。……これ、父さんから。');
      await G.say('母さん', 'え……？');
      await N('母は封を切り、ゆっくりと読んだ。読み終えても、しばらく顔を上げなかった。');
      await G.say('母さん', '……南の島で、生きてたのね。あの人。');
      await G.say('母さん', '「背がのびたか聞いておいてくれ」だって。……のびたわよ、ばか。');
      await HR('……うん。');
      await G.say('母さん', 'ありがとう、リオ。どこで見つけたかは、聞かないでおくね。配達人には、守秘義務があるんでしょう？');
    });
    if (p() === 0) return G.say('母さん', '局長さんが待ってるわよ。寄り道しないの。');
    if (p() <= 2) return G.say('母さん', 'ノエちゃんのレンズ、今夜ともるのね。父さんの船も、あの灯台を目印に帰ってきたのよ。');
    return G.say('母さん', 'リオ、ちゃんと食べてる？ ……なんだか急に大人びた顔になったわね。');
  };
  SC.gen = async () => {
    if (p() === 0) {
      await G.say('ゴロウ', 'おう、来たか。祭りの日まで働かせて悪いな。');
      await G.say('ゴロウ', 'まずはこれだ。お前宛てだよ、リオ。……妙な消印でな。');
      G.se('letter'); await S.give('k_letter', 1, true);
      await G.notice('「未来からの手紙」を受けとった', { icon: 'letter' });
      await HR('おれに？ ……消印、「二四〇六年 ハスネ」？');
      await G.say('ゴロウ', '機械の故障か、だれかのいたずらか。今朝、ポストの底に入ってた。');
      await storyCard(['リオへ。', '', '千二百年あと、世界の時計は止まります。', '止めたのは、あの日の灯台。', '', 'お願い。灯を、ともさないで。', '', '　　　　　　　　　　　　ノエ']);
      await HR('……ノエ？ これ、ノエの字だ。');
      await G.say('ゴロウ', 'ノエ嬢ちゃんのいたずらなら、ずいぶん手がこんでるな。');
      await G.say('ゴロウ', 'ちょうどいい。今日最後の配達は、ノエのレンズ工房だ。灯台のレンズの台座。重いぞ、落とすなよ。');
      S.p(1);
      return N('（レンズ工房は、北通りの東。茶色い屋根の家だ。）');
    }
    if (G.party.letters.L3 && !G.party.delivered.L3) return deliver('L3', async () => {
      await HR('局長。……灯台守のイサオさんから、局長宛ての手紙です。');
      await G.say('ゴロウ', 'イサオから？ あいつは、もう十年も前に……');
      await N('ゴロウ局長は黙って手紙を読んだ。');
      await G.say('ゴロウ', '……そうか。あの嵐の晩、灯が落ちたのは、あいつのせいだったか。');
      await G.say('ゴロウ', 'ばかやろう。知ってたよ。知ってて、何も言わなかった。言ったら、あいつがここにいられなくなると思ってな。');
      await G.say('ゴロウ', '……おれも、言えばよかったんだな。「もういい」って。');
      await G.say('ゴロウ', 'ありがとよ、リオ。お前は、いい配達人だ。');
    });
    if (p() <= 2) return G.say('ゴロウ', 'レンズ工房に台座は届けたか？ 祭りは日が沈んでからだ。');
    return G.say('ゴロウ', '灯台に灯がともってから、町じゅうの時計が一分ずつ狂ってやがる。……まあ、祭りだしな。');
  };
  SC.clerk = () => G.say('局員', p() <= 2 ? '灯り祭りの日は、みんな手紙を出すのよ。一年ぶんの「ありがとう」を書いてね。' : '今夜は、ポストに入りきらないくらい手紙が来たわ。');
  SC.postman = () => G.say('配達人', p() <= 2 ? 'お前の足の速さには、だれもかなわないよ、リオ。' : '岬のポストって、あの青い古いやつか？ 町ができる前からあるらしいぜ。');
  SC.mio_shop = async () => {
    if (p() === 1) {
      await M('リオ！ 待ってた！ それ、台座？ よかったぁ、間にあった。');
      await HR('ほら、届けたぞ。……それと、これ。お前が書いた？');
      await N('リオは、未来からの手紙を見せた。');
      await M('……わたしの字に、そっくり。でも、書いてないよ。');
      await M('二四〇六年……千二百年後？ 灯をともさないで、って……');
      await M('ううん、いたずらだよ、きっと。今夜の灯は、町のみんなが一年待ってたんだもん。');
      await M('ねえ、灯台まで一緒に来てくれる？ 最近、岬に変な生き物が出るんだって。インクのしみみたいなのが。');
      const r = await S.ask('ノエ', '日が沈んだら出発しよう。……いい？', ['行こう', 'ちょっと準備する']);
      if (r === 1) { await M('じゃあ、準備ができたら声をかけて。'); return; }
      await eveStart();
      return;
    }
    return M('灯台は町の東、岬の先だよ。');
  };
  async function eveStart() {
    await S.fadeOut(0.03);
    G.flags.eve = 1; S.p(2);
    S.remove('mio');
    await G.wait(30);
    await F.warp('hasune', 25, 8, 'down', { instant: true, nobanner: true, stayDark: true });
    await joinMember('mio', 2);
    S.place('mio', 26, 8, 'left'); F.find('haru').dir = 'right';
    await S.fadeIn(0.03);
    await N('日が沈み、町じゅうのちょうちんに灯がともった。');
    await M('きれい……。この灯り全部が、灯台の灯を待ってるんだよ。');
    await M('行こう、リオ！ 灯台は、東の岬の先！');
    S.regroup('right');
  }
  SC.miodad = () => G.say('レンズ職人', p() <= 2 ? 'ノエのレンズはな、星を読むために磨いたんだ。光を遠くまでまっすぐ届ける。……わしより腕がいい。' : 'あの子は、言いたいことを全部レンズにしまっちまう。お前さんには、ちゃんと言うといいんだがな。');
  SC.inn_hasune = async () => { if (p() < 2) return G.say('宿屋', '祭りの夜は満室なのよ。……あら、リオ。休んでいく？ 安くしとくわ。').then(() => G.inn('hasune', '宿屋')); return G.inn('hasune', '宿屋'); };
  SC.shop_hasune = () => G.shop('hasune');
  SC.curator = async () => {
    if (G.party.letters.L6 && !G.party.delivered.L6) return deliver('L6', async () => {
      await HR('館長さん。この手紙……とても古い手紙なんです。「未来のだれかへ」って。');
      await G.say('館長', 'どれどれ……天の子ケイ？ この文字は……！');
      await G.say('館長', '海の底から引き揚げられた石板と、同じ文字だ。わしらは、天の民の言葉を二十年かけて読み解いてきた。');
      await G.say('館長', '「わたしたちは、いなくならないから」……そうか。この子は、読まれるのを待っていたんだな。');
      await G.say('館長', '確かに受けとった。博物館のいちばんいい場所に飾らせてもらうよ。');
    });
    return G.say('館長', p() <= 2 ? '今日は祭りで休館だよ。うちの目玉は、海の底から上がった天の民の石板さ。' : '天の民は空に住んでいた、という言い伝えがある。ばかげてると思うかい？');
  };
  SC.fisher1 = () => G.say('漁師', p() <= 2 ? '灯台の灯がともったら、沖の船もみんな帰ってこられる。ありがてえ。' : 'さっき沖で、海の底から時計の音がした気がしたんだ。……飲みすぎかな。');
  SC.kid1 = () => G.say('子ども', p() <= 2 ? 'リオにいちゃん！ 祭りの日はね、ちょうちんの下で手紙を読むと、ねがいがかなうんだよ！' : 'ねえ、灯台の光がぐるぐる回ってるの、見た？');
  SC.girl1 = () => G.say('女の子', p() <= 2 ? 'わたし、おばあちゃんに手紙を書いたの。遠くに住んでるけど、ちゃんと届くよね？' : 'おばあちゃんから、返事がきたの！');
  SC.oldw1 = () => G.say('おばあさん', p() <= 2 ? '言えるうちに、言っておくもんだよ。ありがとうも、ごめんねもね。' : '灯がともったねえ。……長生きはするもんだ。');
  SC.man1 = () => G.say('町の人', p() <= 2 ? '祭りの屋台は広場だ。傷薬も売ってるぞ。岬に行くなら持っていけ。' : '灯台の灯がともった瞬間、岬のほうで青い光が見えたって話だ。');
  SC.woman1 = () => G.say('町の人', p() <= 2 ? 'リオくん、今日も配達？ えらいわねえ。' : 'ノエちゃん、灯台の上で泣いてたって。うれし泣きかしらね。');
  SC.sailor = () => G.say('船乗り', 'この港の青いポスト、知ってるか？ 千年前からあるって話だ。中に入れた手紙は、どこに届くかわからないんだと。');
  SC.elder1 = () => G.say('長老', p() <= 2 ? '灯台の下の岬には、千年前の青いポストがある。昔は「時のポスト」と呼ばれていたものじゃ。' : '時のポストが光ったのを見た、と若いのが騒いでおる。……言い伝えは、言い伝えじゃよ。');

  // ---------------- 1206: the cape and the lighthouse ----------------
  SC.enter_cape = async () => {
    if (p() === 2 && !G.flags.capeTalk) {
      G.flags.capeTalk = 1;
      await M('……見て、リオ。道の上で、インクのしみが動いてる。');
      await HR('あれが噂の「変なの」か。……灯台まで、突っきるぞ。');
      await N('（敵は地図の上に見えている。ぶつかると、その場で戦闘になる。）');
    }
  };
  SC.enter_lighthouse = async () => {
    if (p() === 2) await lensScene();
  };
  SC.setup_lighthouse = () => { if (p() === 2) { S.place('haru', 5, 6, 'up'); S.place('mio', 6, 6, 'up'); } };
  async function lensScene() {
    S.place('haru', 5, 6, 'up'); S.place('mio', 6, 6, 'up');
    await G.wait(20);
    await M('ここが、灯台のてっぺん。……レンズ、はめるね。');
    await S.walk('mio', 'u'); await G.wait(10); G.se('switch'); await G.wait(20);
    await M('よいしょ……っと。ぴったり。');
    await S.walk('mio', 'd'); S.face('mio', 'left'); S.face('haru', 'right');
    await M('……リオ。手紙のこと、まだ気にしてる？');
    await HR('ちょっとだけ。……お前の字なんだよ、あれ。');
    await M('もし、本当にわたしが書いたんだとしたら……未来のわたしは、きっと何かを後悔してるんだね。');
    await M('でもね。灯台の灯は、帰ってくる船のためのもの。だれかを待つための光だよ。悪いことなんて、起きない。');
    const r = await S.ask('ノエ', '……ともすよ。', ['うん', '……待って']);
    if (r === 1) { await HR('……いや、なんでもない。ともそう。'); await M('ふふ。リオが止めても、ともしてたけどね。'); }
    S.face('mio', 'up'); await G.wait(20);
    G.audio.stop(1);
    G.se('light'); G.flags.lit = 1; G.doFlash('#fff4c0', 0.9, 0.02);
    await G.wait(60);
    G.bgm('town');
    await N('レンズに灯がともった。光は海をこえ、町の屋根をなで、岬の先まで――');
    G.audio.stop(0.3);
    G.se('rift'); S.shake(40); await G.wait(40);
    await HR('な、なんだ！？ 揺れてる……！');
    await M('リオ、外！ 岬の青いポストが……光ってる！');
    G.flags.night = 1; G.flags.riftOpen = 'cape'; G.flags.riftAt = [31 * 16 + 8, 12 * 16 - 4]; G.flags.riftSize = 1;
    S.p(3);
    await F.warp('cape', 31, 9, 'down', { nobanner: true });
    S.place('mio', 30, 9, 'down');
    G.bgm('rift');
    await G.wait(20);
    await M('ポストの口から、うずまきが……！');
    await HR('何か出てくるぞ！');
    G.se('rift'); S.shake(20);
    const r2 = await S.battle({ foes: [['waxseal', 31, 13, { main: 1 }]], party: [[30, 10], [32, 10]], boss: 'waxseal', bgm: 'boss', canEscape: false });
    await afterWax();
  }
  async function afterWax() {
    S.regroup('down');
    await M('はあ……はあ……やっつけた……？');
    G.flags.riftSize = 2.4; G.se('rift'); S.shake(60);
    await HR('まだだ！ うずまきが大きくなって……吸いこまれる！');
    await M('リオ、手を――！');
    G.audio.stop(0.5); G.se('warp');
    await S.whiteout();
    G.flags.riftOpen = null;
    await G.wait(60);
    await arrive806();
  }

  // ---------------- 806 ----------------
  async function arrive806() {
    S.p(4);
    await F.warp('cape806', 31, 13, 'down', { instant: true, nobanner: true, stayDark: true });
    S.place('mio', 30, 14, 'up'); S.place('haru', 31, 13, 'down');
    F.find('haru').pose = 'hurt';
    G.fade.color = '#ffffff';
    await G.fadeTo(0, 0.02); G.fade.color = '#000';
    F.banner = { text: 'のろし岬', era: '806', t: 0 };
    await G.wait(40);
    F.find('haru').pose = null;
    await HR('いてて……。ノエ、無事か？');
    await M('うん……。ここ、岬……だよね？ でも、灯台がない。');
    await HR('かわりに、石の塔が建ってる。……テントに、たき火？');
    S.spawn('dan2', 'soldier', 26, 12, 'right'); S.spawn('sold3', 'soldier', 26, 14, 'right');
    G.se('ok');
    await S.walkAll([['dan2', 'rr'], ['sold3', 'rr']], 2);
    await G.say('兵士', '何者だ！ 灰の手先か！');
    await HR('ち、ちがう！ おれたちはただの――');
    G.bgm('varn');
    S.spawn('sena', 'sena', 31, 6, 'down');
    await S.walk('sena', 'dddd', 2);
    await SE('待ちなさい、ジン。');
    await SE('武器を持った子どもが二人。間者にしては、ずいぶん間が抜けてる。');
    await HR('間が抜けてるって……。');
    await SE('わたしはイオリ。ヴァルン王国の騎士で、こののろし岬を預かってる。あなたたちは？');
    await M('ノエです。こっちはリオ。ええと……ハスネという町から。');
    await SE('ハスネ？ 聞かない名ね。');
    S.face('mio', 'right'); await M('（リオ……ポストの消印、見て。「806年」って書いてある。）');
    await HR('（はあ！？ 八〇六年って……過去！？）');
    await SE('のろし台の火が消えてから、この岬には灰の獣が出る。夜は危ない。');
    await SE('村まで来なさい。村長に会わせる。話はそれから。');
    await S.walk('sena', 'lllllllll', 2);
    S.remove('sena'); S.remove('dan2'); S.remove('sold3');
    S.regroup('left');
    await N('（ヴァルン村は、岬の西にある。）');
  }
  SC.dan = async () => {
    if (G.party.letters.L1 && !G.party.delivered.L1) return G.say('ジン', '手紙？ 母さんに……？ おれが書いて、出しそびれたやつだ。……届けてくれるのか？ 村のヘレナが、おれの母さんだ。');
    if (p() <= 4) return G.say('ジン', 'イオリ隊長は村へ向かった。ついていけ。……さっきは悪かったな。');
    if (p() < 7) return G.say('ジン', 'のろしの火がもどれば、灰の獣も寄ってこなくなるはずなんだ。');
    return G.say('ジン', 'のろしの火が燃えてる。隊長たちのおかげだ。春になったら、村に帰れるかもな。');
  };
  SC.soldier2 = () => G.say('兵士', p() < 7 ? 'のろし台の火は、王都まで危険を知らせる大事な火なんだ。' : '火がもどってから、灰の獣は一匹も来ない。');
  SC.enter_varn = async () => {
    if (p() === 4 && !G.flags.varnIn) {
      G.flags.varnIn = 1;
      await N('村の入り口で、イオリが待っていた。');
      await G.say('イオリ', '村長の家は、村のまんなか。……こっちよ。', {});
    }
  };
  SC.elderv = async () => {
    if (p() === 4) {
      S.spawn('sena', 'sena', 16, 14, 'left');
      await G.say('村長', '旅の方か。イオリから聞いたよ。……妙な時に来たものだ。');
      await G.say('村長', 'ひと月前、北の森の洞窟に「灰喰い」が住みついた。そいつが、のろし台の火を喰っていったのだ。');
      await G.say('村長', 'のろしの火は、ただの火ではない。この地の守り火だ。火が消えてから、灰の獣が増えつづけている。');
      await SE('わたしが洞窟へ行きます。騎士団の応援は、待っていられない。');
      await SE('あなたたちは村にいなさい。危ないから。');
      await HR('手伝うよ。');
      await SE('……は？');
      await HR('おれたち、帰り方がわからないんだ。岬のポストからうずまきが出て、気づいたらここにいた。');
      await M('岬で戦った封蝋のおばけ……あれも、灰喰いと同じ「ほころび」だと思う。火を取りもどせば、何かが変わる気がするの。');
      await SE('……。');
      await SE('好きにしなさい。足手まといなら、置いていく。');
      S.remove('sena');
      await joinMember('sena', 5);
      G.flags.p = 5;
      await N('（村の北から、燠火の森に入れる。宿屋と店で準備をととのえよう。）');
      return;
    }
    if (p() < 6) return G.say('村長', '洞窟は、燠火の森の奥。北の道をまっすぐだ。気をつけてな。');
    if (p() === 6) return G.say('村長', 'おお、種火を取りもどしたか！ のろし台にともしてくれ。岬の塔だ。');
    return G.say('村長', 'のろしの火が見える。ありがとう、旅の方。');
  };
  SC.vsold = async () => { if (p() < 5) return G.say('兵士', 'この先は燠火の森だ。村長の許しがなければ通せない。'); return G.say('兵士', '森の獣は火に強い。風や水の技が効くらしいぞ。'); };
  SC.forest_locked = () => G.say('兵士', '待て。この先は燠火の森だ。村長の許しがなければ通せない。');
  SC.inn_varn = () => G.inn('varn', '宿屋のおかみ');
  SC.shop_varn = () => G.shop('varn');
  SC.martha = async () => {
    if (G.party.letters.L1 && !G.party.delivered.L1) return deliver('L1', async () => {
      await HR('ヘレナさん。息子さんのジンから、手紙です。');
      await G.say('ヘレナ', 'ジンから？ あの子、字なんか書けたのかい。');
      await N('ヘレナは手紙を胸に当てて、目を閉じた。');
      await G.say('ヘレナ', '「豆のスープを作っておいて」……まったく。春までに、大鍋で作っておくよ。');
      await G.say('ヘレナ', 'ありがとうね。これ、うちの人の形見なんだけど、あんたたちが持っていきな。');
    });
    return G.say('ヘレナ', p() < 7 ? '息子のジンが、のろし岬で見張りをしてるんだ。手紙のひとつもよこさないんだから。' : '岬の火、見えるかい。あの子も、あの火のそばにいるんだねえ。');
  };
  SC.toma = async () => {
    if (G.party.letters.L2 && !G.party.delivered.L2 && has('sena')) return deliver('L2', async () => {
      S.spawn('sena_t', 'sena', 24, 10, 'right');
      const L = F.leader(); const sv = L.visible;
      await G.say('ルイ', '……姉さん？');
      await G.say('イオリ', 'ルイ。……これ。');
      await N('イオリは手紙を差しだした。ルイは黙って読んだ。');
      await G.say('ルイ', '……ばかだな、姉さん。怒ってなんかないよ。');
      await G.say('ルイ', '姉さんが騎士団に入った日、ぼくは修道院の鐘を鳴らしたんだ。姉さんが、ちゃんと聞こえるように。');
      await G.say('イオリ', '……聞こえてた。ずっと、聞こえてた。');
      await G.say('ルイ', 'いってらっしゃい、姉さん。ちゃんと帰ってきてよ。');
      await G.say('イオリ', '……うん。いってきます。');
      S.remove('sena_t');
    });
    if (G.party.letters.L2 && !G.party.delivered.L2) return G.say('ルイ', '姉さんは、元気かな。');
    return G.say('ルイ', p() < 5 ? 'ぼくの姉さんは騎士なんだ。……家を出ていってから、一度も帰ってこないけど。' : '姉さんが、ちゃんと笑ってた。ありがとう。');
  };
  SC.monk = () => G.say('修道士', p() < 7 ? '鐘の音は、言葉の届かないところまで届く。わたしたちはそう信じて鐘を鳴らしています。' : '時の外から来た方々に、祝福を。');
  SC.farmer = () => G.say('農夫', '灰の獣のせいで、畑に出られなかったんだ。今年の豆は、少し遅れるな。');
  SC.vkid = () => G.say('子ども', p() < 7 ? 'イオリ姉ちゃんはね、村でいちばん強いんだよ！' : 'イオリ姉ちゃん、どこかへ行っちゃうの？');
  SC.boss_ashgram = async () => {
    G.flags.bossGram = 1;
    await N('灰喰いの体がくずれ、灰の中から小さな火が転がり出た。');
    await SE('のろしの種火……！ まだ、生きてる。');
    await S.give('k_ember');
    await M('あったかい……。この火、のろし台にもどしてあげよう。');
    G.flags.p = 6;
    await N('（のろし岬の塔へ、種火を届けよう。）');
  };
  SC.enter_cape806 = async () => {
    if (p() === 6) {
      await SE('……塔の上まで、種火を運ぶ。ついてきて。');
      S.place('haru', 35, 7, 'up'); S.place('mio', 34, 7, 'up'); S.place('sena', 36, 7, 'up');
      await G.wait(20);
      G.se('fire'); G.flags.beaconLit = 1; G.doFlash('#ffb060', 0.6, 0.03);
      await G.wait(40);
      await N('のろしの火が、ふたたび燃えあがった。');
      await G.say('ジン', '火だ……！ 隊長、やりましたね！');
      await G.wait(20);
      G.se('rift'); S.shake(30);
      G.flags.riftOpen = 'cape806'; G.flags.riftAt = [31 * 16 + 8, 12 * 16 - 4]; G.flags.riftSize = 1.3;
      await M('ポストが、また……！ あのときと同じ光！');
      await HR('帰れるかもしれない。');
      S.face('haru', 'right'); S.face('sena', 'left');
      await SE('……行くの？');
      await HR('イオリも来いよ。灰喰いも、うずまきの封蝋も、たぶん全部つながってる。');
      await M('わたしの灯がポストを照らしたあの夜から、何かがほどけはじめてる。……一人じゃ、こわいの。');
      await SE('……わたしは騎士よ。この岬を守るのが仕事。');
      await SE('でも、この岬を壊すものが「時」のむこうから来るなら――むこうまで、守りに行く。');
      await SE('ジン。村を頼む。');
      await G.say('ジン', 'はっ！ ……隊長、気をつけて！');
      S.regroup('down');
      await S.walk('haru', 'ddddd', 2);
      G.se('warp'); await S.whiteout();
      G.flags.riftOpen = null;
      await arriveOffice();
    }
  };
  SC.post_806 = async () => { if (p() >= 8) return postBack('806'); return N('古い伝令箱だ。消印の型には「806」と刻まれている。'); };
  SC.post_1206 = async () => { if (p() >= 8) return postBack('1206'); return N('町ができる前からあるという、青いポストだ。'); };
  SC.post_2406 = async () => { if (p() >= 8) return postBack('2406'); };
  SC.post_800 = async () => postBack('800');
  SC.post_final = async () => postBack('final');
  async function postBack() {
    const r = await S.ask(null, '時のポストだ。消印スタンプが青く光っている。宛先不明局へ戻りますか？', ['戻る', 'やめる'], { cancel: 1 });
    if (r !== 0) return;
    G.se('stamp'); await G.wait(10); G.se('warp');
    await F.warp('office', 11, 9, 'up');
  }

  // ---------------- the Dead Letter Office ----------------
  async function arriveOffice() {
    await F.warp('office', 11, 10, 'up', { instant: true, nobanner: true, stayDark: true });
    G.fade.color = '#ffffff'; await G.fadeTo(0, 0.02); G.fade.color = '#000';
    F.banner = { text: '宛先不明局', era: '—', t: 0 };
    S.place('haru', 11, 10, 'up'); S.place('mio', 10, 11, 'up'); S.place('sena', 12, 11, 'up');
    await G.wait(40);
    await M('……手紙が、浮いてる。');
    await SE('ここはどこ？ 地面も空も、ない。');
    await S.emote('haco', '!');
    await HA('ようこそ、宛先不明局へ。');
    await HA('わたしはポッコ。この局の、最後の局員。');
    await HR('ポストが……しゃべった。');
    await HA('ここは時の外。あらゆる時代の、出せなかった手紙、届かなかった手紙が、最後にたどりつく場所。');
    await HR('じゃあ、これも？');
    await N('リオは未来からの手紙を見せた。');
    await HA('……その手紙は、まだ書かれていない手紙だ。消印は2406年。時が止まる年。');
    await HA('2406年、海の底の大時計が止まる。そして世界の時は、二度と動かない。');
    await HA('止めるのは「とばり」。言えなかった言葉、届かなかった想いを食べて、大きくなるもの。');
    await M('灯台の光が……関係あるの？');
    await HA('きみの灯は、時のポストを照らした。それで、時の継ぎ目が少しほつれた。ほつれから、とばりのかけらがこぼれた。');
    await M('……やっぱり、わたしのせい。');
    await HA('ほつれただけだ。とばりを育てたのは、もっと長い時間と、もっとたくさんの沈黙だよ。');
    await HA('2406年へ行くといい。ほつれの先が見える。');
    await S.give('k_stamp');
    await HA('消印スタンプだ。これがあれば、この局のポストから、宛先のわかる時代へ行ける。');
    await HA('それと――頼みがある。');
    await HA('ここにたまった手紙を、届けてほしい。届いた言葉は、とばりを弱らせる。');
    await S.letters(['L1', 'L2', 'L3']);
    await SE('……待って。この手紙、わたしの字だ。');
    await SE('ルイに書いた手紙……出さずに、燃やしたはずなのに。');
    await HA('燃やしても、出せなかった言葉は消えない。だから、ここにある。');
    await SE('……持っていく。いつか、ちゃんと渡す。');
    G.flags.p = 8;
    S.regroup('up');
    await HA('ポストの前で調べれば、その時代へ行ける。いまは1206年、806年、2406年。……いってらっしゃい。');
    await N('（左上：1206年　右上：806年　左下：2406年。手紙はメニューの「手紙」で読める。）');
  }
  SC.haco = async () => {
    // hand out letters as the story unlocks them
    if (p() >= 12 && !G.party.letters.L7) {
      await HA('新しい手紙が届いている。2406年から、それから1206年の、ずっと古い手紙。');
      await S.letters(['L4', 'L7']);
      if (G.party.letters.L7) await HR('……これ、宛先、うちの母さんだ。差出人は……トウジ。父さんの名前だ。');
      return;
    }
    if (p() >= 15 && !G.party.letters.L8) {
      await HA('天の宮から、二通。');
      await S.letters(['L6', 'L8']);
      await M('カナタさんの字……。ホノカちゃんに書いた手紙、出さなかったんだ。');
      return;
    }
    const held = G.lettersHeld().length, done = G.deliveredCount();
    const opts = ['話す', '休む（お茶）', '品物を見る', 'やめる'];
    const r = await S.ask('ポッコ', done ? `届けた手紙は ${done}通。とばりの声が、少し小さくなった。` : '手紙は、届くのを待っている。', opts, { cancel: 3 });
    if (r === 0) {
      if (p() < 9) return HA('2406年へ。ほつれの先を見てきなさい。');
      if (p() < 12) return HA('止まった町にも、まだ動いているものがいるはずだ。');
      if (p() < 15) return HA('前800年。天の民が大時計を作った時代だ。');
      if (held) return HA(`まだ ${held}通、届いていない手紙がある。届けるほど、とばりは弱る。……海鳴りの大時計へは、下のポストから行ける。`);
      return HA('すべての手紙が届いた。……こんな日が来るとは思わなかった。いってらっしゃい、配達人たち。');
    }
    if (r === 1) { await HA('あたたかいお茶だよ。時の外でも、湯気はちゃんと立つ。'); return G.restScene(); }
    if (r === 2) return G.shop('hub');
  };
  async function goEra(era) {
    const dest = { go1206: ['cape', 31, 13, 'down', 8], go806: ['cape806', 31, 13, 'down', 8], go2406: ['frozen', 18, 19, 'down', 8], go800: ['skyvillage', 17, 6, 'down', 12], gofinal: ['depths', 20, 27, 'up', 15] }[era];
    if (!dest || p() < dest[4]) { G.se('buzz'); return N('ポストの口は暗いままだ。宛先が、まだわからない。'); }
    if (era === 'gofinal') {
      const held = G.lettersHeld().length;
      const r = await S.ask(null, held ? `海鳴りの大時計へ。……まだ届けていない手紙が ${held}通ある。行きますか？` : '海鳴りの大時計へ。行きますか？', ['行く', 'やめる'], { cancel: 1 });
      if (r !== 0) return;
    }
    G.se('stamp'); await G.wait(12); G.se('warp');
    await F.warp(dest[0], dest[1], dest[2], dest[3]);
  }
  for (const e of ['go1206', 'go806', 'go2406', 'go800', 'gofinal']) SC['post_' + e] = () => goEra(e);

  // ---------------- 2406 ----------------
  SC.enter_frozen = async () => {
    if (p() === 8 && !G.flags.frozenIn) {
      G.flags.frozenIn = 1;
      await HR('ここが……2406年のハスネ？');
      await M('雨が……空中で止まってる。');
      await SE('人が、石みたいに動かない。……息もしてない。');
      await M('でも、町の形は同じ。広場も、郵便局も……ぜんぶ、壊れてるけど。');
      await N('（広場に、何か動くものがいる。）');
    }
  };
  SC.pipnpc = async () => {
    if (p() === 8) {
      await PI('ピピッ！ 動いている人間を確認しました！');
      await PI('お届け物は、ありますか？ 出したい手紙は、ありますか？');
      await HR('うわっ、なんだこいつ。');
      await PI('わたしは配達ドローン、チック。時が止まってから、0秒間、配達を続けています。');
      await M('0秒……？');
      await PI('時が止まっているので、何日たっても0秒です。わたしだけ、自分のゼンマイで動いています。ピピ。');
      await SE('止まった理由を知ってる？');
      await PI('時刻管制塔の記録を見れば、わかるはずです。でも、塔の扉はカードで閉まっています。');
      await PI('カードは地下水道の奥。わたしは小さいので、水門を開けられません。……いっしょに行ってくれますか？');
      await HR('もちろん。');
      await PI('ピピ！ それから――お届けできなかった荷物が、ひとつあります。宛先はサヤさん。差出人も、サヤさん。');
      await S.letters(['L5']);
      S.remove('pipnpc');
      await joinMember('pip', Math.max(10, Math.round(G.party.active.reduce((a, id) => a + G.party.members[id].lv, 0) / G.party.active.length)));
      G.flags.p = 9;
      await N('（地下水道の入り口は、港の東のはしごだ。）');
      return;
    }
  };
  SC.got_card = async () => { if (p() === 9) { G.flags.p = 10; await PI('管制塔のカードです！ これで塔の扉が開きます。ピピ！'); } };
  SC.tower_locked = () => PI(p() < 10 ? '塔の扉はカードで閉まっています。カードは地下水道の奥です。' : '……');
  SC.statue = () => N('動かない。触れると、ひんやりと冷たい。');
  SC.statue_old = () => N('杖をついたおばあさんが、空を見上げたまま止まっている。');
  SC.sou = async () => {
    if (G.party.letters.L4 && !G.party.delivered.L4) return deliver('L4', async () => {
      await N('止まった少年の手に、そっと手紙を持たせた。');
      await M('……アオくん。おばあちゃんからだよ。時間が動いたら、読んでね。');
      await N('気のせいだろうか。少年の目に、光がひとつ、ともった気がした。');
    });
    return N('男の子が、何かを言いかけた顔のまま止まっている。');
  };
  SC.nagi = async () => {
    if (G.party.letters.L5 && !G.party.delivered.L5 && party('pip')) return deliver('L5', async () => {
      await PI('お届け物です。……サヤさん。');
      await N('チックは、種の小包を止まった女の人の腕にのせた。');
      await PI('配達、完了。……0秒かかりました。ピピ。');
      await HR('チック……。');
      await PI('いいんです。届けるのが、わたしの仕事ですから。');
    });
    return N('女の人が、小さなじょうろを手に止まっている。');
  };
  SC.vend = async () => {
    const r = await S.ask('販売機', 'イラッシャイマセ。時ガ止マッテモ、営業中デス。', ['買う', '休憩カプセルで休む（80G）', 'やめる'], { cancel: 2 });
    if (r === 0) return G.shop('future');
    if (r === 1) { if (G.party.gold < 80) return G.say('販売機', 'オ金ガ、足リマセン。'); G.party.gold -= 80; await G.restScene(); }
  };
  SC.boss_geargolem = async () => {
    G.flags.bossGolem = 1;
    await N('時計守がくずれ落ちると、奥の壁が開き、古い記録装置が光った。');
    await PI('記録を読みます。ピピ……。');
    await PI('「1206年、灯り祭りの夜。ハスネ岬にて、時の継ぎ目に揺らぎ」');
    await PI('「2406年。海鳴りの大時計、停止。原因：心臓のゼンマイの摩耗。封印の限界」');
    await PI('「大時計は、前800年、天の民により建造。とばりを封じるための檻」');
    await M('……やっぱり、わたしの灯が、最初のほつれ。');
    await HR('ちがう。揺らいだだけだ。止めたのは、とばりってやつだろ。');
    await SE('檻、と言ったわね。大時計は、とばりを閉じこめていた。それが、千六百年たって壊れた。');
    await PI('前800年の宛先座標を、宛先不明局に送信しました。天の民に会えば、大時計のことがわかるはずです。');
    await M('……ねえ、チック。手紙、出せる？ 1206年に。');
    await PI('お届けできます！ 宛先は？');
    await M('ハスネ、郵便配達人のリオへ。');
    await HR('おい、それ……。');
    await N('ノエは、記録装置の明かりの下で、短い手紙を書いた。');
    await M('……最初の手紙を書いたのは、わたしだった。今、わかった。');
    await M('「灯をともさないで」。そう書いても、あの日のわたしは、きっとともす。だから、わたしはここにいる。');
    await M('それでも書くよ。あの日のリオに、わたしが今いること、知っててほしいから。');
    await PI('お預かりしました。2406年の消印で、お届けします。ピピ。');
    G.flags.p = 12;
    await N('（宛先不明局から、前800年へ行けるようになった。）');
  };

  // ---------------- 前800 ----------------
  SC.enter_skyvillage = async () => {
    if (p() === 12 && !G.flags.skyIn) {
      G.flags.skyIn = 1;
      await M('雲の上に……島が浮いてる！');
      await HR('前800年って、こんなだったのか。');
      await PI('天の民の宮殿は、北東の大きな建物です。ピピ。');
    }
  };
  SC.amane = async () => {
    if (p() === 12) {
      await G.say('カナタ', '時の外から来た人たち。……あなたたちの持つ時計の音は、とても遠いところで鳴っている。');
      await G.say('カナタ', 'わたしはカナタ。天の宮の女王。');
      await HR('とばりって、知ってるか？ おれたち、それを止めに来たんだ。');
      await G.say('カナタ', '……知っている。とばりは、この空で生まれた。');
      await G.say('カナタ', '天の民は長く生きすぎて、言葉を交わすことをやめた。言わなくても伝わる、と思いこんだ。');
      await G.say('カナタ', '言われなかった言葉は、空にたまり、やがて形をもった。それが、とばり。');
      await G.say('カナタ', 'わたしは海の底に大時計を沈め、その中にとばりを封じる。時計が時を刻むかぎり、とばりは眠る。');
      await SE('……その時計が、千六百年後に止まる。');
      await G.say('カナタ', '……そう。やはり、永遠ではないのね。');
      await G.say('カナタ', '時計を動かすには、心臓のゼンマイがいる。歯車の庭の奥、天の祭壇にある。でも、とばりの影が見張っている。');
      await G.say('カナタ', '力を貸して。この空の、最後の仕事に。');
      G.flags.p = 13;
      await N('（歯車の庭へは、村の東の雲の道から行ける。）');
      return;
    }
    if (p() === 13) return G.say('カナタ', '歯車の庭は東。庭の仕掛けは、両側のレバーで動くわ。');
    if (p() === 14) return amaneResolve();
  };
  async function amaneResolve() {
    await G.say('カナタ', '心臓のゼンマイ。……ありがとう。');
    await G.say('カナタ', 'これで大時計は動く。でも、ゼンマイだけでは足りない。時計には、心臓がいるの。');
    await M('心臓って……。');
    await G.say('カナタ', 'わたしが、時計の中に入る。とばりを抱いて、眠りながら時を刻む。それが、女王の役目。');
    await G.say('ホノカ', '姉さま……！ そんなの、聞いてない！');
    await G.say('カナタ', 'ホノカ。……。');
    await N('カナタは何か言いかけて、口を閉じた。');
    await G.say('カナタ', '……いってきます、とだけ。');
    G.audio.stop(1);
    await S.fadeOut(0.02);
    G.bgm('sad');
    await N('その日、天の宮は、しずかに海へ沈んでいった。');
    await N('海の底で、大きな時計が、ひとつ目の音を鳴らした。');
    await N('ホノカは、ずっと待っていた。姉の「さよなら」を。');
    G.flags.p = 15;
    await F.warp('office', 11, 9, 'up', { instant: true, nobanner: true, stayDark: true });
    await S.fadeIn(0.02);
    await HA('……おかえり。見てきたんだね。');
    await HA('カナタは千六百年、ひとりで時を刻んだ。2406年、その心臓が尽きる。');
    await HA('海鳴りの大時計へ行けるようになった。下のポストだ。止まる直前の、時計の中へ。');
    await HA('……それと、天の宮から手紙が届いている。');
    await S.letters(['L6', 'L8']);
    await M('カナタさんの字……。ホノカちゃんへの手紙。書いて、出さなかったんだ。');
    await SE('届けよう。前800年の、あの子のところへ。');
    await N('（まだ届けていない手紙があれば、大時計へ行く前に届けよう。届けた手紙が多いほど、とばりは弱くなる。）');
  }
  SC.yura = async () => {
    if (G.party.letters.L8 && !G.party.delivered.L8) return deliver('L8', async () => {
      await M('ホノカちゃん。……お姉さんから、手紙。');
      await G.say('ホノカ', '姉さまから……？');
      await N('ホノカは震える手で封を開けた。');
      await G.say('ホノカ', '「時計の音が聞こえたら、それがわたしです」……。');
      await G.say('ホノカ', 'ずるいよ、姉さま。最後まで、自分では言わないんだから。');
      await G.say('ホノカ', '……でも、聞こえた。ちゃんと聞こえたよ。');
      await N('遠い海の底で、時計の音がひとつ、やさしく鳴った気がした。');
    });
    if (p() < 15) return G.say('ホノカ', p() < 13 ? 'わたしはホノカ。姉さまは女王さまなの。……最近、ずっと難しい顔をしてる。' : '姉さまが、何かを決めた顔をしてる。こわい。');
    return G.say('ホノカ', '姉さまは、何も言わずに行っちゃった。……「いってきます」だけ。');
  };
  SC.riku = async () => G.say('ケイ', p() < 15 ? 'ぼく、手紙を書いてるんだ。未来のだれかに読んでもらうの！' : 'ぼくの手紙、いつか、だれかが読んでくれるかな。');
  SC.sky1 = () => G.say('天の民', '言葉を交わすのは、何年ぶりだろう。……声の出し方を、忘れかけていた。');
  SC.sky2 = () => G.say('天の民', p() < 15 ? '女王さまは、海に大きな時計を沈めるおつもりだ。' : '女王さまの時計の音が、雲の下から聞こえる。');
  SC.sky3 = () => G.say('天の民', '歯車の庭は、天の民が時を学んだ場所。今は、とばりの影がうろついている。');
  SC.inn_sky = () => G.inn('sky', '宿の主');
  SC.shop_sky = () => G.shop('sky');
  SC.garden_locked = () => G.say('天の民', 'この先は歯車の庭。女王さまのお許しなしには入れません。');
  SC.boss_queenshadow = async () => {
    G.flags.bossQueen = 1;
    await N('影が消えると、祭壇の上に金色のゼンマイが残った。');
    await S.give('k_spring');
    await PI('心臓のゼンマイ……！ 構造は、わたしのゼンマイとそっくりです。ピピ。');
    G.flags.p = 14;
    await N('（カナタのもとへ、ゼンマイを届けよう。）');
  };

  // ---------------- letters ----------------
  async function deliver(k, scene) {
    G.cutscene++;
    try {
      G.se('letter');
      await scene();
      G.party.delivered[k] = 1;
      const L = D.LETTERS[k];
      G.se('stamp'); G.doFlash('#fff4c0', 0.3);
      await G.notice(`「${L.name}」を届けた！`, { icon: 'letter' });
      if (L.reward) { G.addItem(L.reward, 1); await G.notice(`お礼に ${D.ITEMS[L.reward].name} をもらった`, { icon: D.ITEMS[L.reward].icon, se: 'item' }); }
    } finally { G.cutscene--; }
  }

  // ---------------- final ----------------
  SC.enter_depths = async () => {
    if (!G.flags.depthsIn) {
      G.flags.depthsIn = 1;
      await M('海の底……なのに、息ができる。');
      await PI('時計の中です。2406年、止まる直前。歯車の音が、どんどん遅くなっています。');
      await SE('奥から、だれかの声がする。');
    }
  };
  SC.enter_heart = async () => { G.bgm('stillness'); };
  SC.final_battle = async () => {
    S.place('haru', 11, 11, 'up'); S.place('mio', 10, 12, 'up'); S.place('sena', 12, 12, 'up'); if (F.find('pip')) S.place('pip', 13, 12, 'up');
    const n = G.deliveredCount();
    await G.say('カナタ', '……だれ？ ここまで来たのは。');
    await M('カナタさん……！');
    await G.say('カナタ', 'もう、心臓がもたない。とばりが、目を覚ます。……逃げて。');
    G.se('dark'); S.shake(30);
    await G.say('とばり', '言わなくて、いい。');
    await G.say('とばり', '言わなければ、だれも傷つかない。さよならも、ごめんねも、いらない。時が止まれば、なにも終わらない。');
    await HR('……ちがう。終わらないってことは、何も始まらないってことだ。');
    await M('わたしは、言えなかった。リオに「こわい」って。でも、手紙は書けた。届いた。');
    await SE('黙って出ていったわたしを、ルイは待っててくれた。言葉が届いたから。');
    if (party('pip')) await PI('配達人は、どんな言葉も届けます。0秒でも、千年でも。ピピ。');
    if (n) await N(`届けた ${n}通の手紙の光が、とばりの体をほどいていく。`);
    await G.say('とばり', '…………。');
    G.flags.lockOrder = 1;
    await finalBattle(n);
  };
  async function finalBattle(n) {
    const hpMul = Math.max(0.52, 1 - n * 0.06);
    const sp = [[11, 6], [7, 7], [15, 7]];
    S.regroup('up');
    const pp = [[9, 11], [11, 12], [13, 11]];
    let phase = 1;
    const onFoeDeath = async (f, st) => {
      if (f.id === 'shijima1' && phase === 1) {
        phase = 2;
        await G.wait(20);
        st.msg = { text: '白紙がやぶれ、中から黒い核があらわれた！', t: 120 };
        G.se('dark'); G.doShake(20);
        const core = G.battle.spawnFoe('shijimacore', sp[0][0] * 16, sp[0][1] * 16, { hpMul, main: 0 });
        const l = G.battle.spawnFoe('seal_l', sp[1][0] * 16, sp[1][1] * 16, { hpMul, part: 1 });
        const r = G.battle.spawnFoe('seal_r', sp[2][0] * 16, sp[2][1] * 16, { hpMul, part: 1 });
        for (let i = 0; i <= 20; i++) { core.alpha = l.alpha = r.alpha = i / 20; await G.wait(1); }
        core.coreRef = 1;
      } else if (f.id === 'shijimacore' && phase === 2) {
        phase = 3;
        for (const x of st.foes) if (x.alive) { x.alive = false; x.alpha = 0; }
        await G.wait(20);
        G.bgm('final', { restart: true });
        st.msg = { text: 'とばりが、ほんとうの姿をあらわした――', t: 140 };
        G.doFlash('#ffffff', 0.8, 0.02); G.se('rift'); G.doShake(30);
        const t = G.battle.spawnFoe('shijima3', sp[0][0] * 16, sp[0][1] * 16 + 8, { hpMul, main: 1 });
        for (let i = 0; i <= 30; i++) { t.alpha = i / 30; await G.wait(1); }
        // the delivered letters answer back: they heal the party, and with enough of them, wake the fallen
        const k = 0.25 + n * 0.06;
        G.se('heal'); G.doFlash('#fff4c0', 0.5, 0.03);
        for (const b of st.party) {
          if (!b.alive && n >= 6) { b.alive = true; b.pose = null; b.atb = 0; b.hp = Math.round(b.maxhp * k); }
          else if (b.alive) b.hp = Math.min(b.maxhp, b.hp + Math.round(b.maxhp * k));
        }
        st.msg = { text: n ? `届けた ${n}通の手紙が、光になってみんなを包んだ` : '……どこからも、声は返ってこない', t: 140 };
        if (n >= 4) t.st.defdown = 99999;
      }
    };
    await S.battle({ foes: [['shijima1', sp[0][0], sp[0][1], { hpMul, main: 0 }]], party: pp, boss: 'final', bgm: 'final', canEscape: false, onFoeDeath, noFanfare: true });
    G.flags.bossFinal = 1;
    await ending(n);
  }
  G._ending = n => ending(n);
  async function ending(n) {
    G.audio.stop(1);
    S.regroup('up');
    const truth = G.party.delivered.L8 && n >= 6;
    await G.wait(40);
    G.se('gear'); await G.wait(30); G.se('gear');
    await N('止まりかけていた歯車が、ひとつ、またひとつと回りはじめた。');
    G.bgm('sad');
    await G.say('カナタ', '……時計の音。こんなに、たくさん。');
    if (truth) {
      await G.say('カナタ', 'ホノカに……届いたのね。わたしの手紙。');
      await G.say('カナタ', '届いた言葉が、ゼンマイになっている。ルイの鐘、ジンのスープ、アオの時計、サヤの種……。');
      await G.say('カナタ', 'もう、時計に心臓はいらない。言葉が、時を刻んでくれる。');
      await G.say('カナタ', 'ありがとう、配達人たち。……わたし、やっと、言える。');
      await G.say('カナタ', 'ただいま、ホノカ。');
      await N('カナタの姿は光になり、時計の外へ――遠い空のほうへ、ほどけていった。');
    } else if (n >= 4) {
      await G.say('カナタ', '時計は、また動ける。……わたしは、ここで時を刻む。それでいいの。');
      await G.say('カナタ', '行って。あなたたちの明日へ。');
    } else {
      await G.say('カナタ', '時計は動きだした。でも、とばりは消えない。言えない言葉があるかぎり、また、どこかで……。');
      await G.say('カナタ', 'それでも、今日の時は動く。……行って。');
    }
    await S.fadeOut(0.02);
    await epilogue(n, truth);
  }
  async function epilogue(n, truth) {
    G.bgm('ending', { restart: true });
    G.flags.eve = 1; G.flags.night = 1; G.flags.lit = 1; G.flags.riftOpen = null;
    await F.warp('cape', 31, 10, 'down', { instant: true, nobanner: true, stayDark: true });
    for (const id of ['mio', 'sena', 'pip']) if (F.find(id)) S.place(id, { mio: 30, sena: 32, pip: 33 }[id], { mio: 11, sena: 11, pip: 10 }[id], 'up');
    S.place('haru', 31, 11, 'up');
    await S.fadeIn(0.02);
    await N('1206年、灯り祭りの夜。');
    await N('時のポストの前に、四人は立っていた。');
    if (party('pip')) {
      await PI('2406年に帰ります。時が動いたら、配達がたくさんたまっているはずです。ピピ。');
      await PI('サヤさんの種が、芽を出すところを見たいです。');
    }
    await SE('わたしは806年へ。……岬の火を、守らなきゃ。');
    await SE('ルイに、ただいまを言いに行く。');
    await HR('……また、会えるかな。');
    await SE('手紙を書くわ。宛先不明局に出せば、きっと届くでしょう。');
    G.se('warp');
    for (const id of ['sena', 'pip']) { const a = F.find(id); if (a) { for (let i = 0; i < 20; i++) { a.alpha = 1 - i / 20; await G.wait(1); } a.visible = false; } }
    await G.wait(30);
    S.face('mio', 'right'); S.face('haru', 'left');
    await M('……ねえ、リオ。');
    await M('わたし、ずっと言えなかったことがあるの。灯台に灯をともすのが、本当はこわかった。');
    await M('みんなが待ってる光だから、失敗したらどうしようって。でも、言ったら、もっとこわくなる気がして。');
    await HR('……知ってた。');
    await M('え？');
    await HR('レンズの話をするとき、お前、いつも早口になる。');
    await M('……ばか。');
    await M('ありがとう、リオ。言えてよかった。');
    await S.fadeOut(0.02);
    // what happened to each delivered letter
    const notes = {
      L1: '806年。春、ジンは大鍋の豆のスープを、のろし岬の仲間みんなに配った。',
      L2: '806年。イオリは修道院の鐘の下で、弟と並んで夕焼けを見た。',
      L3: '1206年。ゴロウ局長は、灯台守イサオの墓に、一通の手紙を供えた。',
      L4: '2406年。時が動きだした朝、アオはおばあちゃんの手紙を読み、時計のねじを巻いた。',
      L5: '2406年。サヤの植えた種は、春、ハスネの広場で小さな花をつけた。',
      L6: '1206年。天の子ケイの手紙は、博物館のいちばん明るい窓辺に飾られた。',
      L7: '1206年。秋、南の島から一隻の漁船が、ハスネの港に帰ってきた。',
      L8: '前800年。ホノカは毎朝、海に耳をすませた。時計の音は、いつもやさしかった。',
    };
    const lines = Object.keys(notes).filter(k => G.party.delivered[k]).map(k => notes[k]);
    for (const l of lines) await creditLine(l);
    if (!lines.length) await creditLine('届かなかった手紙は、いまも宛先不明局で、だれかを待っている。');
    await rollCredits(n, truth);
  }
  function creditLine(text) {
    return new Promise(res => {
      let t = 0;
      const o = { kind: 'card', update() { t++; if (t > 240 || (t > 40 && G.pressed('ok'))) { G.consumeAll(); G.pop(o); res(); } }, draw() { ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = Math.min(1, t / 40, (240 - t) / 40); G.wrap(text, 480).forEach((l, i) => G.text(l, W / 2, 210 + i * 30, '#efe6d2', 'center')); ctx.globalAlpha = 1; } };
      G.push(o);
    });
  }
  function rollCredits(n, truth) {
    return new Promise(res => {
      const lines = ['ときわたりの郵便屋', 'Courier of Hours', '', '', '企画・制作', 'SuedoGaming', '', '物語・プログラム・ドット絵・音楽', 'SuedoGaming', '', 'フォント', 'DotGothic16（SIL Open Font License 1.1）', '', '', '登場人物', '', 'リオ', 'ノエ', 'イオリ', 'チック', '', 'ポッコ', 'カナタ　ホノカ', 'ゴロウ局長　母さん', 'ジン　ヘレナ　ルイ', 'アオ　サヤ　ケイ', '', '', `届けた手紙　${n} / 8`, truth ? '— すべての言葉が、届いた —' : n >= 4 ? '— 時は、ふたたび動きだした —' : '— 言えない言葉は、まだどこかに —', '', '', '', 'プレイしてくれて、ありがとう。', '', '', '', 'おわり'];
      let y = H + 20; let t = 0; let done = false;
      const o = {
        kind: 'credits',
        update() {
          t++; y -= G.held('ok') ? 2.4 : 0.6;
          const end = y + lines.length * 34;
          if (end < H / 2 + 40 && !done) { done = true; }
          if (done && (G.pressed('ok') || G.pressed('cancel'))) { G.consumeAll(); G.pop(o); res(); finishGame(n, truth); }
        },
        draw() {
          ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H);
          lines.forEach((l, i) => { const yy = Math.max(y + i * 34, i === lines.length - 1 ? H / 2 - 10 : -100); if (yy < -40 || yy > H + 40) return; const big = i === 0 || l === 'おわり'; G.text(l, W / 2, yy, l.startsWith('—') ? '#e2b04a' : big ? '#f3ead6' : '#c8c0d8', 'center', big ? 28 : 16, null); });
          if (done) G.text('決定ボタンで終わる', W / 2, H - 40, '#5a587a', 'center', 12, null);
        },
      };
      G.push(o);
    });
  }
  G._credits = (n, t) => rollCredits(n, t);
  async function finishGame(n, truth) {
    const clear = { gold: G.party.gold, items: G.party.items, members: {}, ng: G.party.ng || 0, n, truth };
    for (const [id, m] of Object.entries(G.party.members)) clear.members[id] = { lv: m.lv, exp: m.exp, eq: m.eq };
    G.store.set('clear', clear);
    G.flags = { p: 0 };
    await G.fadeTo(1, 0.03);
    await G.toTitle();
  }

  // ---------------- new game+: re-apply carried levels to later joiners ----------------
  const _addMember = G.addMember;
  G.addMember = function (id, lv, active) {
    const m = _addMember(id, lv, active);
    if (G.party.carry && G.party.carry[id] && m.lv < G.party.carry[id].lv) applyCarry(id);
    return m;
  };
  SC.none = () => { };

  // ---------------- side activity: the delivery race ----------------
  const RACE = [['innkeep', '宿屋'], ['fisher1', '桟橋の漁師'], ['sailor', '船乗り'], ['curator', '博物館の館長'], ['elder1', '東通りの長老']];
  const fmtRace = f => { const s = f / 60; return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}.${Math.floor((s * 10) % 10)}`; };
  SC.race = async () => {
    if (p() < 8) return G.say('配達人', '祭りの日はみんな忙しくてな。落ちついたら「配達レース」をやろうぜ。');
    const best = G.flags.raceBest;
    const r = await S.ask('配達人', `配達レース、やるか？ 町の5か所に小包を届けて、ここに戻るまでの時間を競うんだ。${best ? `（最高記録 ${fmtRace(best)}）` : ''}`, ['やる', 'やめる'], { cancel: 1 });
    if (r !== 0) return;
    await G.say('配達人', (G.QUEST ? '届け先は、宿屋、桟橋の漁師、船乗り、博物館の館長、東通りの長老。届けたら、またおれに話しかけろ。制限時間は90秒。走れよ（「走る」ボタン）！……よーい、どん！' : '届け先は、宿屋、桟橋の漁師、船乗り、博物館の館長、東通りの長老。届けたら、またおれに話しかけろ。制限時間は90秒。走れよ（シフトキー）！……よーい、どん！'));
    G.flags.race = { t: 0, done: [] }; G.se('encounter');
  };
  G.raceTalk = async function (a) {
    const R = G.flags.race; if (!R) return false;
    if (a && a.npc && a.npc.id === 'racer') {
      if (R.done.length < RACE.length) { await G.say('配達人', `まだ ${RACE.length - R.done.length}か所残ってるぞ！ 急げ！`); return true; }
      const t = R.t; G.flags.race = null;
      G.se('levelup');
      const rank = t < 60 * 22 ? 'S' : t < 60 * 30 ? 'A' : t < 60 * 45 ? 'B' : 'C';
      const newBest = !G.flags.raceBest || t < G.flags.raceBest; if (newBest) G.flags.raceBest = t;
      await G.say('配達人', `ゴール！ タイムは ${fmtRace(t)}。評価は「${rank}」だ！${newBest ? '　新記録！' : ''}`);
      const prize = { S: 600, A: 300, B: 150, C: 50 }[rank]; G.party.gold += prize;
      await G.notice(`賞金 ${prize}G をもらった`, { icon: 'gold', se: 'buy' });
      if (rank === 'S' && !G.flags.raceS) { G.flags.raceS = 1; await G.say('配達人', 'Sなんて、おれも見たことないぞ……。これを持ってけ。伝説の配達人がかぶってた帽子だ。'); await S.give('h_courier'); }
      return true;
    }
    const k = RACE.findIndex(([id]) => a && a.npc && a.npc.id === id);
    if (k < 0) return false;
    if (R.done.includes(k)) { await G.say(null, 'もう届けた。'); return true; }
    R.done.push(k); G.se('stamp');
    await G.say(RACE[k][1], ['おっ、ご苦労さん！', 'はやいな！', 'ありがとよ！', '確かに受けとった。', 'おお、待っておったぞ。'][k], { auto: 40 });
    if (R.done.length === RACE.length) await G.notice('全部届けた！ 郵便局へ戻ろう', { auto: 60 });
    return true;
  };
  G.updateRace = function () {
    const R = G.flags.race; if (!R || G.mode !== 'field') return;
    const m = F.map && F.map.id; if (m !== 'hasune' && m !== 'post_office') return;
    if (!G.overlays.length) R.t++;
    if (R.t > 60 * 90) { G.flags.race = null; G.runScript('race_timeout'); }
  };
  SC.race_timeout = () => G.say(null, '時間切れ……。配達レースは失敗だ。（郵便局の配達人に話せば、もう一度挑戦できる）');
  G.drawRaceHud = function () {
    const R = G.flags.race; if (!R) return;
    const w = 210, x = W - w - 12, y = 12;
    G.ui.win(x, y, w, 70, { title: '配達レース' });
    G.text(fmtRace(R.t), x + 14, y + 12, R.t > 60 * 70 ? '#ff8a8a' : '#f3ead6', 'left', 20);
    G.text(`届けた ${R.done.length} / ${RACE.length}`, x + w - 14, y + 16, '#e2b04a', 'right', 13);
    const left = RACE.filter((_, k) => !R.done.includes(k)).map(r => r[1]).join('・') || '郵便局へ戻ろう';
    G.text(left, x + 14, y + 44, '#c8c0d8', 'left', left.length > 16 ? 10 : 12);
  };

  // ---------------- the hidden superboss ----------------
  SC.nushi = async () => {
    if (G.flags.nushiDown) return G.say(null, '手紙の山は、ただの静かな手紙の山にもどった。');
    if (p() < 15) return G.say(null, 'ほこりをかぶった手紙の山だ。奥のほうで、何かがかさりと動いた気がした。');
    G.se('dark'); G.doShake(10);
    await HA('……その山には近づかないほうがいい。');
    await HA('届かずにたまりすぎた手紙が、形を持ってしまったもの。「とどかずの主」。とばりより古く、とばりより重い。');
    const r = await S.ask(null, '手紙の山がふくらんでいく……。戦いますか？', ['戦う', 'やめておく'], { cancel: 1 });
    if (r !== 0) return HA('賢明だ。準備ができたら、また来なさい。');
    const res = await S.battle({ foes: [['nushi', 16, 10, { main: 1 }]], party: [[11, 8], [10, 10], [11, 12]], boss: 'nushi', bgm: 'final', canEscape: false });
    G.flags.nushiDown = 1;
    await HA('……信じられない。主が、ただの手紙にもどっていく。');
    await HA('ほら、ごらん。山の中から出てきた。差出人も宛先も消えてしまった、金色の消印だ。');
    await S.give('c_trophy');
    await S.give('tomorrow', 3);
    await HA('きみたちは、この局がはじまって以来の配達人だよ。');
  };
})();
