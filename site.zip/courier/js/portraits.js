'use strict';
// Dialogue portraits (48x48, drawn by code). Expressions: normal, smile, surprise, sad, firm
(function () {
  const { Spr, shade, mix } = G.art;
  const OUT = '#1b1229';
  const P = {
    haru: { skin: '#f2c8a0', hair: '#7a4a2a', eye: '#4a3a2a', cloth: '#d8d0bc', accent: '#c9473d', style: 'cap', cap: '#2f4472' },
    mio: { skin: '#f4cfac', hair: '#3a3048', eye: '#3a6a5a', cloth: '#5d8f6e', accent: '#e2b04a', style: 'pony' },
    sena: { skin: '#f0caa6', hair: '#e8d8a8', eye: '#3a5a8a', cloth: '#b8c0cc', accent: '#8a2e2e', style: 'bob' },
    gen: { skin: '#e8b890', hair: '#e8e8e8', eye: '#3a3040', cloth: '#2f4472', accent: '#e2b04a', style: 'beard' },
    mom: { skin: '#f2c8a0', hair: '#6a4030', eye: '#4a3a2a', cloth: '#9a4a5a', accent: '#f0e0c0', style: 'bun' },
    amane: { skin: '#f8e4d4', hair: '#f4f4ff', eye: '#6a7ab8', cloth: '#ffffff', accent: '#e2b04a', style: 'crown' },
    yura: { skin: '#f8e4d4', hair: '#f4f4ff', eye: '#6a8ac8', cloth: '#d8e8ff', accent: '#e2b04a', style: 'sky' },
    toma: { skin: '#f0caa6', hair: '#e8d8a8', eye: '#3a5a8a', cloth: '#7a6a50', accent: '#6a5a40', style: 'short' },
    dan: { skin: '#e8b890', hair: '#4a3020', eye: '#3a3040', cloth: '#9aa0aa', accent: '#6a3a3a', style: 'helm' },
  };
  function face(s, c, expr, open) {
    const sk = c.skin, skD = shade(sk, -0.18);
    // neck and shoulders
    s.rect(19, 36, 10, 6, skD);
    s.poly([[6, 48], [10, 40], [20, 38], [28, 38], [38, 40], [42, 48]], c.cloth, { side: 1 });
    // head
    s.ell(24, 23, 13, 14.5, sk, { lit: 0.12, dark: -0.14 });
    s.ell(11.5, 25, 2, 3, sk); s.ell(36.5, 25, 2, 3, sk); // ears
    // eyes
    const ey = 24, ex = [18, 30];
    const browY = expr === 'surprise' ? 17 : expr === 'sad' ? 19 : 19;
    for (const [i, x] of ex.entries()) {
      if (expr === 'smile') { s.line(x - 2, ey + 1, x, ey - 1, '#2a1a2a'); s.line(x, ey - 1, x + 2, ey + 1, '#2a1a2a'); }
      else if (expr === 'sad') { s.rect(x - 2, ey, 5, 3, '#ffffff'); s.rect(x - 1, ey, 3, 3, c.eye); s.px(x, ey + 1, '#140c1c'); s.hline(x - 2, x + 2, ey - 1, '#2a1a2a'); s.px(x + (i ? 1 : -1), ey + 3, '#9ad8ff'); }
      else {
        const h = expr === 'surprise' ? 6 : 5;
        s.rect(x - 2, ey - 2, 5, h, '#ffffff'); s.rect(x - 1, ey - 2, 3, h, c.eye); s.rect(x, ey - 1, 1, h - 2, '#140c1c');
        s.px(x - 1, ey - 2, '#ffffff'); s.hline(x - 2, x + 2, ey - 3, '#2a1a2a');
        if (expr === 'firm') s.hline(x - 2, x + 2, ey - 2, '#2a1a2a');
      }
      // brows
      const c2 = shade(c.hair, -0.35);
      if (expr === 'sad') s.line(x - 2, browY + (i ? -1 : 1) - 1, x + 2, browY + (i ? 1 : -1) - 1, c2);
      else if (expr === 'firm') s.line(x - 2, browY + (i ? 1 : -1), x + 2, browY + (i ? -1 : 1), c2);
      else s.hline(x - 2, x + 2, browY - (expr === 'surprise' ? 1 : 0), c2);
    }
    // nose and mouth
    s.px(24, 28, skD);
    const my = 32;
    if (open && expr !== 'surprise') { s.ell(24, my, 2, 1.5, '#6a2a2a', { flat: 1 }); s.hline(23, 25, my + 1, '#c86a6a'); }
    else if (expr === 'smile') { s.hline(22, 26, my, '#8a3a3a'); s.px(21, my - 1, '#8a3a3a'); s.px(27, my - 1, '#8a3a3a'); s.hline(23, 25, my + 1, '#c86a6a'); }
    else if (expr === 'surprise') { s.ell(24, my, 1.6, 2, '#6a2a2a', { flat: 1 }); }
    else if (expr === 'sad') { s.hline(22, 26, my + 1, '#8a3a3a'); s.px(21, my + 2, '#8a3a3a'); s.px(27, my + 2, '#8a3a3a'); }
    else if (expr === 'firm') { s.hline(22, 26, my, '#8a3a3a'); }
    else { s.hline(23, 25, my, '#8a3a3a'); }
    // cheeks
    if (expr !== 'sad') { s.px(15, 29, mix(sk, '#ff8a8a', 0.4)); s.px(16, 29, mix(sk, '#ff8a8a', 0.3)); s.px(32, 29, mix(sk, '#ff8a8a', 0.3)); s.px(33, 29, mix(sk, '#ff8a8a', 0.4)); }
  }
  function hair(s, c, layer) {
    const h = c.hair, hd = shade(h, -0.3), hl = shade(h, 0.25);
    if (c.style === 'cap') {
      if (layer === 'back') { s.ell(24, 20, 15, 13, h); s.rect(10, 20, 4, 12, h); s.rect(34, 20, 4, 12, h); return; }
      s.poly([[11, 18], [15, 22], [17, 18], [20, 23], [23, 18], [27, 23], [30, 18], [33, 22], [37, 18], [36, 13], [12, 13]], h, { grad: 1 });
      s.ell(24, 11, 15, 7, c.cap, { lit: 0.2 }); s.rect(9, 13, 30, 3, c.accent); s.hline(9, 38, 16, shade(c.cap, -0.4));
      s.ell(18, 7, 4, 2, shade(c.cap, 0.25), { flat: 1 });
      s.rect(20, 9, 8, 3, '#e8e2d2'); s.px(22, 10, c.accent); s.px(25, 10, '#3765b0');
      return;
    }
    if (c.style === 'pony') {
      if (layer === 'back') { s.ell(24, 20, 15, 14, h); s.rect(9, 20, 5, 16, h); s.rect(34, 20, 5, 16, h); s.poly([[34, 6], [44, 4], [46, 20], [40, 30], [38, 14]], h, { side: 1 }); return; }
      s.poly([[10, 22], [12, 12], [20, 7], [30, 7], [37, 12], [38, 22], [34, 16], [28, 19], [24, 14], [18, 18], [14, 17]], h, { grad: 1 });
      s.rect(10, 10, 28, 3, '#c8963a'); s.ell(17, 9, 4, 3.5, '#9ad8f0', { lit: 0.4 }); s.ell(31, 9, 4, 3.5, '#9ad8f0', { lit: 0.4 }); s.px(15, 8, '#ffffff'); s.px(29, 8, '#ffffff');
      s.px(38, 7, '#c9473d'); s.px(39, 7, '#c9473d'); s.px(38, 8, '#c9473d');
      return;
    }
    if (c.style === 'bob') {
      if (layer === 'back') { s.ell(24, 21, 16, 15, h); s.rect(8, 21, 6, 15, h); s.rect(34, 21, 6, 15, h); return; }
      s.poly([[9, 34], [9, 18], [14, 10], [24, 7], [34, 10], [39, 18], [39, 34], [35, 26], [34, 18], [27, 15], [21, 16], [14, 18], [13, 26]], h, { grad: 1 });
      s.hline(12, 36, 12, '#d8d0b8'); s.hline(13, 35, 13, shade('#d8d0b8', -0.3)); s.ell(24, 12, 2, 1.5, '#7ac8f0', { flat: 1 });
      s.poly([[6, 48], [12, 38], [18, 42], [24, 44], [30, 42], [36, 38], [42, 48]], c.accent, { side: 1 });
      return;
    }
    if (c.style === 'beard') {
      if (layer === 'back') return;
      s.rect(11, 18, 4, 8, h); s.rect(33, 18, 4, 8, h);
      s.poly([[13, 30], [16, 38], [24, 42], [32, 38], [35, 30], [30, 34], [24, 35], [18, 34]], h, { grad: 1 }); s.hline(20, 28, 31, h);
      s.ell(24, 10, 12, 5, shade(c.skin, 0.1), { flat: 1 });
      return;
    }
    if (c.style === 'bun') {
      if (layer === 'back') { s.ell(24, 21, 15, 14, h); s.ell(24, 6, 6, 5, h); return; }
      s.poly([[10, 24], [12, 13], [20, 8], [30, 8], [36, 13], [38, 24], [33, 15], [24, 12], [15, 15]], h, { grad: 1 });
      return;
    }
    if (c.style === 'crown' || c.style === 'sky') {
      if (layer === 'back') { s.ell(24, 21, 16, 15, h); s.rect(8, 21, 6, 22, h); s.rect(34, 21, 6, 22, h); return; }
      s.poly([[9, 26], [12, 12], [20, 7], [28, 7], [36, 12], [39, 26], [35, 18], [26, 14], [24, 18], [21, 14], [13, 18]], h, { grad: 1 });
      if (c.style === 'crown') { s.poly([[15, 9], [17, 3], [20, 7], [24, 1], [28, 7], [31, 3], [33, 9]], c.accent, { side: 1 }); s.ell(24, 6, 1.5, 1.5, '#9ad8f0', { flat: 1 }); }
      else { s.vline(37, 6, 13, '#ffffff'); s.px(36, 8, '#c0e0ff'); }
      return;
    }
    if (c.style === 'short') {
      if (layer === 'back') { s.ell(24, 20, 14.5, 13, h); return; }
      s.poly([[11, 22], [12, 12], [20, 8], [30, 8], [36, 12], [37, 22], [33, 16], [26, 15], [24, 18], [21, 15], [14, 17]], h, { grad: 1 });
      return;
    }
    if (c.style === 'helm') {
      if (layer === 'back') return;
      s.ell(24, 15, 16, 12, '#8a8a96', { lit: 0.3 }); s.rect(8, 15, 32, 4, '#6a6a76'); s.vline(24, 3, 15, '#c8c8d0');
      return;
    }
  }
  function human(id, expr, open) {
    const c = P[id], s = new Spr(48, 48);
    hair(s, c, 'back'); face(s, c, expr, open); hair(s, c, 'front');
    s.outline(OUT); return s;
  }
  function pip(expr) {
    const s = new Spr(48, 48);
    s.rect(22, 2, 4, 5, '#5a6268'); s.hline(10, 38, 2, '#c8d0d8'); s.hline(12, 36, 1, '#a8b0b8');
    s.ell(24, 26, 19, 18, '#e8eef4', { lit: 0.3 });
    s.ell(24, 36, 14, 8, '#57a6d8', { lit: 0.2 });
    s.rect(10, 16, 28, 14, '#1a2a3a'); s.rect(11, 17, 26, 12, '#0e1a26');
    const eye = '#7af0ff';
    const draw = (x, kind) => {
      if (kind === 'smile') { s.line(x - 3, 24, x, 21, eye); s.line(x, 21, x + 3, 24, eye); }
      else if (kind === 'sad') { s.hline(x - 3, x + 3, 23, eye); s.px(x - 3, 22, eye); s.px(x + 3, 24, eye); }
      else if (kind === 'surprise') { s.rect(x - 2, 19, 5, 7, eye); s.rect(x - 1, 20, 3, 5, '#0e1a26'); }
      else if (kind === 'firm') { s.rect(x - 3, 21, 7, 3, eye); }
      else { s.rect(x - 2, 20, 4, 5, eye); s.px(x - 2, 20, '#ffffff'); }
    };
    draw(17, expr); draw(31, expr);
    s.rect(21, 31, 6, 2, '#e2b04a');
    s.rect(1, 22, 6, 8, '#c9473d'); s.rect(41, 22, 6, 8, '#c9473d');
    s.outline(OUT); return s;
  }
  function haco(expr) {
    const s = new Spr(48, 48);
    s.rect(8, 10, 32, 38, '#c8392e'); s.ell(24, 10, 16, 8, '#d84a3a', { lit: 0.25 }); s.vline(8, 10, 47, '#e0624e'); s.vline(39, 10, 47, '#8e2a22');
    s.rect(13, 16, 22, 4, '#1a1220');
    const l = expr === 'smile' ? 1 : 0;
    for (const x of [17, 31]) { s.ell(x, 27, 4, 4, '#ffe6a0', { lit: 0.3 }); if (expr === 'sad') s.rect(x - 4, 23, 9, 3, '#c8392e'); else s.ell(x, 27 + l, 1.5, 1.5, '#1a1220', { flat: 1 }); }
    s.rect(16, 36, 16, 8, '#efe6d2'); s.hline(18, 29, 39, '#c8392e'); s.hline(18, 26, 41, '#3a3a48');
    s.rect(20, 0, 8, 4, '#e2b04a'); s.px(22, 1, '#fff0b0');
    s.outline(OUT); return s;
  }
  function shijima() {
    const s = new Spr(48, 48);
    s.poly([[24, 2], [42, 20], [38, 48], [10, 48], [6, 20]], '#efe6d2', { side: 1 });
    for (let y = 18; y < 48; y += 5) s.hline(10, 38, y, '#d8ccb0');
    s.ell(24, 20, 8, 8, '#05060c', { flat: 1 }); s.ell(24, 20, 2, 3, '#ff3050', { flat: 1 });
    s.outline(OUT); return s;
  }
  const NAME = { 'リオ': 'haru', 'ノエ': 'mio', 'イオリ': 'sena', 'チック': 'pip', 'ポッコ': 'haco', 'ゴロウ': 'gen', '母さん': 'mom', 'カナタ': 'amane', 'ホノカ': 'yura', 'ルイ': 'toma', 'ジン': 'dan', 'とばり': 'shijima' };
  const cache = new Map();
  G.portrait = function (name, expr = 'normal', open = false) {
    const id = NAME[name]; if (!id) return null;
    if (id === 'pip' || id === 'haco' || id === 'shijima') open = false;
    const k = id + ':' + expr + ':' + open; let c = cache.get(k);
    if (!c) {
      const s = id === 'pip' ? pip(expr) : id === 'haco' ? haco(expr) : id === 'shijima' ? shijima() : human(id, expr, open);
      c = s.canvas(); cache.set(k, c);
    }
    return c;
  };
  // pick an expression from the line itself unless one is given with [smile] etc.
  G.guessExpr = function (text) {
    const m = /^\[(normal|smile|surprise|sad|firm)\]/.exec(text); if (m) return m[1];
    const t = text;
    if (/^(……|…)/.test(t) || /ごめん|こわ|すまない|ずるい|さよなら|もう会えない|のせい|やっぱり/.test(t)) return 'sad';
    if (/^(な、|うわ|えっ|え？|はあ！|ポストが|ピピッ！|待って)/.test(t) || /！？|なんだ！|まさか/.test(t)) return 'surprise';
    if (/ありがと|よかった|ふふ|きれい|ただいま|おかえり|うれし|やった|もちろん|いってきます|ばか。/.test(t)) return 'smile';
    if (/守|止め|行こう|行く|ちがう|まかせ|突っきる|届け|好きにしなさい/.test(t)) return 'firm';
    return 'normal';
  };
})();
