'use strict';
// Game data for ときわたりの郵便屋
(function () {
  const D = G.DATA = {};
  D.ELEM = { wind: '風', light: '光', earth: '地', thunder: '雷', fire: '火', water: '水', dark: '闇', none: '無' };
  D.ELEMCOL = { wind: '#7ee0a0', light: '#ffe68a', earth: '#d8a060', thunder: '#a8c8ff', fire: '#ff8a4a', water: '#6ab0ff', dark: '#b07ad8', none: '#ffffff' };

  // ---------------- Party ----------------
  D.PARTY = {
    haru: { name: 'リオ', spr: 'haru', elem: 'wind', wtype: 'sword', voice: 0, color: '#c9473d',
      base: { hp: 74, mp: 8, pow: 9, mag: 5, def: 6, mdef: 4, spd: 13, hit: 94, eva: 9 },
      grow: { hp: 11.5, mp: 1.6, pow: 2.15, mag: 1.0, def: 1.3, mdef: 0.95, spd: 0.17 },
      desc: '港町ハスネの配達人。足の速さなら町いちばん。' },
    mio: { name: 'ノエ', spr: 'mio', elem: 'light', wtype: 'tube', voice: 5, color: '#5d8f6e',
      base: { hp: 58, mp: 14, pow: 6, mag: 9, def: 4, mdef: 7, spd: 11, hit: 96, eva: 8 },
      grow: { hp: 8.8, mp: 2.6, pow: 1.3, mag: 2.2, def: 1.0, mdef: 1.6, spd: 0.14 },
      desc: 'レンズ職人の娘。灯台の新しいレンズを作った。' },
    sena: { name: 'イオリ', spr: 'sena', elem: 'earth', wtype: 'lance', voice: 2, color: '#8a2e2e',
      base: { hp: 98, mp: 6, pow: 11, mag: 4, def: 9, mdef: 5, spd: 10, hit: 92, eva: 6 },
      grow: { hp: 13.5, mp: 1.2, pow: 2.4, mag: 0.8, def: 1.8, mdef: 1.1, spd: 0.12 },
      desc: '806年、ヴァルン王国の岬を守る騎士。' },
    pip: { name: 'チック', spr: 'pip', elem: 'thunder', wtype: 'arm', voice: 9, color: '#57a6d8',
      base: { hp: 66, mp: 10, pow: 8, mag: 8, def: 7, mdef: 7, spd: 12, hit: 95, eva: 10 },
      grow: { hp: 10, mp: 2.0, pow: 1.75, mag: 1.85, def: 1.5, mdef: 1.5, spd: 0.15 },
      desc: '2406年の配達ドローン。自前のゼンマイで動きつづけている。' },
  };
  D.expNeed = lv => Math.round(12 * lv * lv + 8 * lv);

  // area: single | line | circleT | circleS | all | ally | allies | self
  D.TECHS = {
    gale: { name: '疾風斬り', user: 'haru', lv: 2, mp: 2, area: 'line', kind: 'phys', power: 1.5, elem: 'wind', fx: 'dash', desc: '一直線に駆けぬけて斬る。線上の敵すべてに風のダメージ。' },
    whirl: { name: 'つむじ', user: 'haru', lv: 5, mp: 4, area: 'circleT', r: 30, kind: 'phys', power: 1.3, elem: 'wind', fx: 'whirl', desc: '敵のもとへ跳び、回転斬り。まわりの敵もまきこむ。' },
    tailwind: { name: '追い風', user: 'haru', lv: 8, mp: 5, area: 'ally', kind: 'buff', status: 'haste', fx: 'buff', desc: '味方ひとりの行動を速くする。' },
    express: { name: '速達', user: 'haru', lv: 13, mp: 8, area: 'single', kind: 'phys', power: 0.95, hits: 3, elem: 'none', fx: 'multi', desc: '目にもとまらぬ三連撃。' },
    heavenwind: { name: '天つ風', user: 'haru', lv: 18, mp: 14, area: 'all', kind: 'mag', power: 2.4, elem: 'wind', fx: 'tornado', desc: '天からの風で敵全体を切りさく。' },

    lamp: { name: '灯', user: 'mio', lv: 1, mp: 2, area: 'ally', kind: 'heal', power: 1.6, fx: 'heal', desc: '味方ひとりのHPを回復。' },
    focus: { name: '集光', user: 'mio', lv: 3, mp: 3, area: 'line', kind: 'mag', power: 1.35, elem: 'light', fx: 'beam', desc: 'レンズで光を集め、一直線に放つ。' },
    stardust: { name: '星くず', user: 'mio', lv: 7, mp: 6, area: 'circleT', r: 32, kind: 'mag', power: 1.55, elem: 'light', fx: 'stars', desc: '星くずを降らせ、まとまった敵をまとめて打つ。' },
    lantern: { name: '灯火', user: 'mio', lv: 10, mp: 9, area: 'allies', kind: 'heal', power: 1.3, fx: 'heal', desc: '味方全員のHPを回復。' },
    wake: { name: '目覚めの光', user: 'mio', lv: 14, mp: 12, area: 'ally', kind: 'revive', power: 0.5, fx: 'revive', desc: '倒れた味方をよみがえらせる。' },
    meteor: { name: '流星群', user: 'mio', lv: 19, mp: 16, area: 'all', kind: 'mag', power: 2.6, elem: 'light', fx: 'meteor', desc: '流れ星の雨で敵全体を打つ。' },

    crush: { name: '鎧砕き', user: 'sena', lv: 1, mp: 2, area: 'single', kind: 'phys', power: 1.25, elem: 'none', fx: 'heavy', debuff: 'defdown', desc: '槍の一撃で敵の守りを下げる。' },
    tremor: { name: '地ならし', user: 'sena', lv: 6, mp: 4, area: 'circleS', r: 40, kind: 'phys', power: 1.4, elem: 'earth', fx: 'quake', desc: '足もとを打ち鳴らし、自分の近くの敵すべてを打つ。' },
    vow: { name: '守りの誓い', user: 'sena', lv: 9, mp: 6, area: 'allies', kind: 'buff', status: 'guard', fx: 'buff', desc: '味方全員の守りを上げる。' },
    rocklance: { name: '岩槍', user: 'sena', lv: 12, mp: 7, area: 'line', kind: 'phys', power: 1.8, elem: 'earth', fx: 'spikes', desc: '大地から岩の槍を突き上げる。線上の敵に地のダメージ。' },
    heartbeat: { name: '大地の鼓動', user: 'sena', lv: 17, mp: 13, area: 'all', kind: 'phys', power: 2.2, elem: 'earth', fx: 'bigquake', desc: '大地をゆるがせ、敵全体を打つ。' },

    zap: { name: '放電', user: 'pip', lv: 1, mp: 2, area: 'single', kind: 'mag', power: 1.5, elem: 'thunder', fx: 'zap', desc: '電撃で敵ひとりを打つ。' },
    scan: { name: 'スキャン', user: 'pip', lv: 1, mp: 1, area: 'single', kind: 'scan', fx: 'scan', desc: '敵のHPと弱点を調べる。' },
    net: { name: '雷網', user: 'pip', lv: 12, mp: 6, area: 'circleT', r: 30, kind: 'mag', power: 1.45, elem: 'thunder', fx: 'net', debuff: 'slow', chance: 0.45, desc: '雷の網でまとめて打ち、動きを鈍らせることがある。' },
    repair: { name: '修理', user: 'pip', lv: 13, mp: 4, area: 'ally', kind: 'heal', power: 1.3, cure: 1, fx: 'heal', desc: '味方ひとりのHPを回復し、状態異常も治す。' },
    tune: { name: '時刻合わせ', user: 'pip', lv: 15, mp: 8, area: 'allies', kind: 'cure', fx: 'buff', desc: '味方全員の状態異常を治す。' },
    railgun: { name: '超電磁', user: 'pip', lv: 18, mp: 12, area: 'line', kind: 'mag', power: 2.4, elem: 'thunder', fx: 'rail', desc: '雷の槍を撃ちだす。線上の敵を貫く。' },
  };
  // Dual and triple techs: all listed members must be ready (and alive), each pays their MP.
  D.COMBOS = {
    lightwhirl: { name: '光のつむじ', users: ['haru', 'mio'], need: ['whirl', 'focus'], mp: { haru: 4, mio: 3 }, area: 'circleT', r: 42, kind: 'mag', power: 2.4, elem: 'light', fx: 'lightwhirl', desc: 'ノエの光をリオの旋風がまきこむ。広い範囲の敵に光のダメージ。' },
    galespear: { name: '疾風岩槍', users: ['haru', 'sena'], need: ['gale', 'rocklance'], mp: { haru: 2, sena: 7 }, area: 'line', kind: 'phys', power: 3.0, elem: 'earth', fx: 'galespear', desc: 'イオリの岩槍をリオが駆けぬけて押しこむ。' },
    raijin: { name: '雷迅', users: ['haru', 'pip'], need: ['gale', 'zap'], mp: { haru: 2, pip: 2 }, area: 'line', kind: 'phys', power: 2.5, elem: 'thunder', fx: 'raijin', desc: '雷をまとったリオが一直線に走る。' },
    sanctuary: { name: '聖域', users: ['mio', 'sena'], need: ['lantern', 'vow'], mp: { mio: 9, sena: 6 }, area: 'allies', kind: 'heal', power: 1.5, status: 'guard', fx: 'sanctuary', desc: '味方全員を回復し、守りを上げる。' },
    prism: { name: 'プリズム砲', users: ['mio', 'pip'], need: ['focus', 'net'], mp: { mio: 3, pip: 6 }, area: 'all', kind: 'mag', power: 2.2, elem: 'light', fx: 'prism', desc: '光を七色に分けて敵全体を撃つ。' },
    thunderquake: { name: '地雷震', users: ['sena', 'pip'], need: ['tremor', 'net'], mp: { sena: 4, pip: 6 }, area: 'circleS', r: 60, kind: 'mag', power: 2.6, elem: 'thunder', fx: 'thunderquake', desc: '地面に雷を流す。イオリの近くの敵を広く打つ。' },
    postmark: { name: '時の消印', users: ['haru', 'mio', 'sena'], need: ['tailwind', 'stardust', 'vow'], mp: { haru: 5, mio: 6, sena: 6 }, area: 'all', kind: 'mag', power: 3.6, elem: 'light', fx: 'postmark', desc: '三人の力をひとつの消印にこめ、敵全体に押す。' },
    express_meteor: { name: '速達流星', users: ['haru', 'mio', 'pip'], need: ['express', 'meteor', 'net'], mp: { haru: 8, mio: 16, pip: 6 }, area: 'all', kind: 'mag', power: 4.2, elem: 'light', fx: 'expressmeteor', desc: '流星を届け先へ速達で。最強の一撃。' },
  };

  // ---------------- Items ----------------
  // kind: use | key | weapon | armor | helm | acc
  D.ITEMS = {
    salve: { name: '傷薬', kind: 'use', icon: 'potion', price: 20, eff: { hp: 70 }, target: 'ally', desc: 'HPを70回復。' },
    hisalve: { name: '上傷薬', kind: 'use', icon: 'hipotion', price: 90, eff: { hp: 240 }, target: 'ally', desc: 'HPを240回復。' },
    fullsalve: { name: '特効傷薬', kind: 'use', icon: 'hipotion', price: 400, eff: { hp: 9999 }, target: 'ally', desc: 'HPを全回復。' },
    allsalve: { name: 'まるごと薬', kind: 'use', icon: 'cure', price: 600, eff: { hp: 300 }, target: 'allies', desc: '味方全員のHPを300回復。' },
    dew: { name: '星の雫', kind: 'use', icon: 'ether', price: 120, eff: { mp: 30 }, target: 'ally', desc: 'MPを30回復。' },
    bigdew: { name: '星の大雫', kind: 'use', icon: 'ether', price: 500, eff: { mp: 9999 }, target: 'ally', desc: 'MPを全回復。' },
    revive: { name: '気付け薬', kind: 'use', icon: 'revive', price: 150, eff: { revive: 0.35 }, target: 'ally', ko: 1, desc: '倒れた味方をHP35%で起こす。' },
    cure: { name: '万能薬', kind: 'use', icon: 'cure', price: 40, eff: { cure: 1 }, target: 'ally', desc: '状態異常を治す。' },
    blanket: { name: '旅の毛布', kind: 'use', icon: 'tent', price: 250, eff: { rest: 1 }, target: 'field', desc: 'ポストのそばで使うと、全員のHPとMPが全回復。' },
    tomorrow: { name: 'あしたの薬', kind: 'use', icon: 'revive', price: 0, eff: { hp: 9999, mp: 9999, revive: 1 }, target: 'ally', ko: 1, desc: 'HPとMPを全回復。倒れていても起こせる。' },

    // key items
    k_letter: { name: '未来からの手紙', kind: 'key', icon: 'letter', desc: '2406年の消印。「リオへ」とある。' },
    k_lens: { name: '星読みレンズ', kind: 'key', icon: 'ether', desc: 'ノエが作った灯台のレンズ。' },
    k_ember: { name: '種火', kind: 'key', icon: 'flame', desc: 'のろし台にともす火。あたたかい。' },
    k_stamp: { name: '消印スタンプ', kind: 'key', icon: 'stamp', desc: '時のポストを開くスタンプ。ポッコからもらった。' },
    k_valve: { name: '水門のハンドル', kind: 'key', icon: 'key', desc: '地下水道の水門を動かすハンドル。' },
    k_card: { name: '管制塔のカード', kind: 'key', icon: 'key', desc: '時刻管制塔の扉を開けるカード。' },
    k_spring: { name: '心臓のゼンマイ', kind: 'key', icon: 'spring', desc: '大時計を動かすためのゼンマイ。' },

    // weapons
    w_wood: { name: '木刀', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 0, atk: 4, desc: '配達の合間に素振りしている木刀。' },
    w_dagger: { name: '鉄の短剣', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 140, atk: 9, desc: '軽くて扱いやすい。' },
    w_knight: { name: '騎士の剣', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 320, atk: 16, desc: 'ヴァルンの騎士が使う剣。' },
    w_ash: { name: '灰鋼の剣', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 0, atk: 21, desc: '燠火の洞窟で見つけた。熱を帯びている。' },
    w_silver: { name: '白銀の剣', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 1300, atk: 29, desc: '2406年の合金。刃こぼれしない。' },
    w_cloud: { name: '雲切り', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 2600, atk: 39, desc: '雲さえ切れるという天の剣。' },
    w_time: { name: '時渡りの剣', kind: 'weapon', wtype: 'sword', icon: 'sword', price: 0, atk: 52, spd: 1, desc: '大時計の針から打ちだした剣。' },
    t_wood: { name: '木の光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 0, atk: 3, mag: 2, desc: 'レンズで光を撃ちだす筒。' },
    t_brass: { name: '真鍮の光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 150, atk: 7, mag: 3, desc: '真鍮の筒。光がよく通る。' },
    t_star: { name: '星読みの光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 340, atk: 12, mag: 5, desc: '星読みレンズの予備をはめた。' },
    t_volt: { name: '電光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 1350, atk: 19, mag: 8, desc: '2406年の技術で作られた光筒。' },
    t_sky: { name: '天球の光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 2700, atk: 27, mag: 11, desc: '天の民の天球儀を組みこんだ。' },
    t_dawn: { name: '暁の光筒', kind: 'weapon', wtype: 'tube', icon: 'bow', price: 0, atk: 36, mag: 15, desc: '夜明けの光を集める光筒。' },
    l_knight: { name: '騎士の槍', kind: 'weapon', wtype: 'lance', icon: 'lance', price: 450, atk: 14, desc: 'ヴァルン騎士団の槍。' },
    l_ash: { name: '灰鋼の槍', kind: 'weapon', wtype: 'lance', icon: 'lance', price: 0, atk: 20, desc: '灰鋼で鍛えた槍。' },
    l_silver: { name: '白銀の槍', kind: 'weapon', wtype: 'lance', icon: 'lance', price: 1300, atk: 28, desc: '2406年の合金の槍。' },
    l_sky: { name: '天の槍', kind: 'weapon', wtype: 'lance', icon: 'lance', price: 2700, atk: 38, desc: '天の民の衛士の槍。' },
    l_earth: { name: '大地の槍', kind: 'weapon', wtype: 'lance', icon: 'lance', price: 0, atk: 50, desc: '大地の鼓動が聞こえる槍。' },
    a_post: { name: '配達アーム', kind: 'weapon', wtype: 'arm', icon: 'tool', price: 0, atk: 16, mag: 3, desc: 'チックの荷物つかみアーム。' },
    a_volt: { name: '雷のアーム', kind: 'weapon', wtype: 'arm', icon: 'tool', price: 1400, atk: 24, mag: 6, desc: '放電機能つき。' },
    a_sky: { name: '天空アーム', kind: 'weapon', wtype: 'arm', icon: 'tool', price: 2800, atk: 34, mag: 9, desc: '天の民の歯車で強化。' },
    a_future: { name: '未来アーム', kind: 'weapon', wtype: 'arm', icon: 'tool', price: 0, atk: 46, mag: 13, desc: 'どこの時代でもない技術。' },
    // body armor (all)
    b_clothes: { name: '旅人の服', kind: 'armor', icon: 'armor', price: 30, def: 4, desc: 'じょうぶな布の服。' },
    b_leather: { name: '革の胸当て', kind: 'armor', icon: 'armor', price: 120, def: 8, desc: '軽い革の防具。' },
    b_chain: { name: '鎖かたびら', kind: 'armor', icon: 'armor', price: 420, def: 14, mdef: 2, desc: 'ヴァルンの鍛冶屋のしごと。' },
    b_ash: { name: '灰鋼の鎧', kind: 'armor', icon: 'armor', price: 0, def: 19, mdef: 4, who: ['sena', 'haru'], desc: '燠火の洞窟の奥にあった鎧。' },
    b_fiber: { name: '合成繊維の服', kind: 'armor', icon: 'armor', price: 1100, def: 23, mdef: 7, desc: '2406年の服。軽くて強い。' },
    b_feather: { name: '羽衣', kind: 'armor', icon: 'armor', price: 2300, def: 30, mdef: 12, desc: '天の民の織物。' },
    b_time: { name: '時の衣', kind: 'armor', icon: 'armor', price: 0, def: 40, mdef: 18, desc: '時間の流れを織りこんだ衣。' },
    // helms
    h_cap: { name: '布の帽子', kind: 'helm', icon: 'helm', price: 20, def: 2, desc: 'ただの帽子。' },
    h_leather: { name: '革の帽子', kind: 'helm', icon: 'helm', price: 90, def: 4, desc: '頭を守る革の帽子。' },
    h_iron: { name: '鉄の兜', kind: 'helm', icon: 'helm', price: 360, def: 8, mdef: 1, desc: 'ずっしり重い。' },
    h_fiber: { name: '合成メット', kind: 'helm', icon: 'helm', price: 950, def: 12, mdef: 4, desc: '2406年のヘルメット。' },
    h_feather: { name: '羽根の冠', kind: 'helm', icon: 'helm', price: 2000, def: 16, mdef: 7, desc: '天の民の冠。' },
    h_time: { name: '時の冠', kind: 'helm', icon: 'helm', price: 0, def: 22, mdef: 12, desc: '大時計の歯車をかたどった冠。' },
    // accessories
    c_badge: { name: '速達バッジ', kind: 'acc', icon: 'acc', price: 300, spd: 2, desc: '速さ+2。配達人のあこがれ。' },
    c_power: { name: '力の指輪', kind: 'acc', icon: 'acc', price: 500, pow: 5, desc: '力+5。' },
    c_magic: { name: '星の指輪', kind: 'acc', icon: 'acc', price: 500, mag: 5, desc: '魔力+5。' },
    c_ward: { name: '守りの護符', kind: 'acc', icon: 'acc', price: 450, def: 6, mdef: 6, desc: '守り+6、魔法の守り+6。' },
    c_bell: { name: '目覚めの鈴', kind: 'acc', icon: 'acc', price: 350, immune: ['sleep', 'poison'], desc: '眠りとインク染みを防ぐ。' },
    c_clock: { name: '時計のお守り', kind: 'acc', icon: 'acc', price: 900, immune: ['stop', 'slow'], desc: '「とばり」と「鈍足」を防ぐ。' },
    h_courier: { name: '速達の帽子', kind: 'helm', icon: 'helm', price: 0, def: 26, mdef: 16, spd: 3, desc: '伝説の配達人の帽子。守り26・魔守16・速さ+3。' },
    c_trophy: { name: '金の消印', kind: 'acc', icon: 'stamp', price: 0, pow: 8, mag: 8, def: 8, mdef: 8, spd: 3, immune: ['stop', 'slow', 'sleep', 'poison'], desc: 'とどかずの主を倒した証。全能力が上がり、状態異常を防ぐ。' },
    c_hope: { name: 'あしたの切手', kind: 'acc', icon: 'stamp', price: 0, pow: 6, mag: 6, spd: 2, desc: '力と魔力+6、速さ+2。届いた想いのしるし。' },
  };
  // dead letters (key items with delivery data)
  D.LETTERS = {
    L1: { name: '兵士ジンの手紙', to: 'ヘレナ（806年 ヴァルン村）', npc: 'martha', era: '806', reward: 'c_bell',
      text: '母さんへ。のろし台の見張りは寒いけど、イオリ隊長がいるから平気です。春になったら帰ります。豆のスープを作っておいて。ジン' },
    L2: { name: 'イオリの手紙', to: 'ルイ（806年 ヴァルン村の修道院）', npc: 'toma', era: '806', reward: 'c_power',
      text: 'ルイへ。黙って騎士団に入ってごめん。あなたを置いていったんじゃない。あなたの住む村を守りたかったの。いつか、ちゃんと顔を見て言うね。イオリ' },
    L3: { name: '灯台守の手紙', to: 'ゴロウ局長（1206年 ハスネ郵便局）', npc: 'gen', era: '1206', reward: 'hisalve',
      text: 'ゴロウへ。三十年前、嵐の晩に灯を落としたのはおれだ。お前の船が帰れなかったのは、おれのせいだ。ずっと言えなかった。すまない。灯台守イサオ' },
    L4: { name: 'おばあちゃんの手紙', to: 'アオ（2406年 止まったハスネ）', npc: 'sou', era: '2406', reward: 'c_ward',
      text: 'アオへ。十歳のお誕生日おめでとう。プレゼントは時計よ。時間が止まらないように、毎朝ねじを巻いてね。おばあちゃんより' },
    L5: { name: 'チックの最後の荷物', to: 'サヤ（2406年 止まったハスネ）', npc: 'nagi', era: '2406', reward: 'c_clock',
      text: '（配達票）お届け物：種の小包。差出人：サヤ。宛先：サヤ。メモ「来年の春、自分で植えること」' },
    L6: { name: '空の子の手紙', to: '博物館の館長（1206年 ハスネ）', npc: 'curator', era: '1206', reward: 'c_magic',
      text: '未来のだれかへ。わたしたちの島は、もうすぐ海にしずみます。でも、こわくありません。だれかがこの手紙を読んでくれたら、わたしたちはいなくならないから。天の子ケイ' },
    L7: { name: '父さんの手紙', to: 'リオの母（1206年 ハスネ）', npc: 'mom', era: '1206', reward: 'c_badge',
      text: 'チヨへ。嵐で船が流されたが、おれは無事だ。南の島で漁師に拾われた。必ず帰る。リオに、背がのびたか聞いておいてくれ。トウジ' },
    L8: { name: 'カナタの手紙', to: 'ホノカ（前800年 天の宮）', npc: 'yura', era: '前800', reward: 'c_hope',
      text: 'ホノカへ。わたしは大時計の心臓になります。もう会えないけれど、時計の音が聞こえたら、それがわたしです。あなたが生きる明日を、ずっと刻みつづけます。姉より' },
  };

  // ---------------- Enemies ----------------
  // atk: physical attack value, mag: magic, def/mdef, spd: ATB speed, weak/resist: multipliers by element
  const P = (a, b, c, e) => ({ a, b, c, e });
  D.ENEMIES = {
    // 1206 cape
    inkblob: { name: 'インクぼう', spr: 'inkblob', pal: P('#2c3a6a', '#1a2448', '#7ab0ff', '#ffe060'), hp: 26, atk: 15, mag: 8, def: 2, mdef: 3, spd: 8, exp: 9, g: 9, drop: ['salve', 0.2], weak: { light: 1.5 }, acts: [['attack', 3], ['inksplash', 1]], hop: 1 },
    envbat: { name: 'ふうとうコウモリ', spr: 'envbat', pal: P('#efe6d2', '#6a4a8a', '#c9473d', '#1a1020'), hp: 20, atk: 14, mag: 6, def: 2, mdef: 2, spd: 13, exp: 9, g: 10, drop: ['salve', 0.15], weak: { wind: 1.5 }, acts: [['attack', 3], ['swoop', 2]], fly: 1, roam: 1 },
    stampcrab: { name: '切手ガニ', spr: 'stampcrab', pal: P('#c9473d', '#d86a3a', '#e2b04a', '#101010'), hp: 44, atk: 18, mag: 4, def: 9, mdef: 2, spd: 7, exp: 16, g: 16, drop: ['cure', 0.2], weak: { thunder: 1.5 }, resist: { water: 0.5 }, acts: [['attack', 3], ['pinch', 2], ['shell', 1]] },
    // 806
    emberwolf: { name: '火の粉オオカミ', spr: 'emberwolf', pal: P('#6a4a3a', '#ff8a3a', '#ffb040', '#ffe060'), hp: 58, atk: 22, mag: 12, def: 6, mdef: 5, spd: 12, exp: 34, g: 20, drop: ['salve', 0.25], weak: { water: 1.5, wind: 1.3 }, resist: { fire: 0 }, acts: [['attack', 3], ['bite', 2], ['firebreath', 1]], roam: 1 },
    ashsoldier: { name: '灰の兵', spr: 'ashsoldier', pal: P('#6a6470', '#4a4450', '#ff8a3a', '#ffb040'), hp: 84, atk: 26, mag: 8, def: 12, mdef: 4, spd: 8, exp: 44, g: 32, drop: ['hisalve', 0.12], weak: { earth: 1.5 }, resist: { fire: 0.5 }, acts: [['attack', 3], ['slash', 2], ['guardup', 1]] },
    lanternshroom: { name: 'ちょうちんダケ', spr: 'lanternshroom', pal: P('#d06a3a', '#e8dcc0', '#ffe070', '#2a1a10'), hp: 50, atk: 17, mag: 17, def: 6, mdef: 10, spd: 9, exp: 34, g: 22, drop: ['cure', 0.3], weak: { fire: 1.5, wind: 1.3 }, acts: [['attack', 2], ['spores', 2], ['emberlight', 1]] },
    inkred: { name: 'しゅインクぼう', spr: 'inkblob', pal: P('#8a2a2a', '#5a1a1a', '#ff8a6a', '#ffe060'), hp: 54, atk: 22, mag: 15, def: 6, mdef: 8, spd: 10, exp: 30, g: 18, drop: ['dew', 0.1], weak: { light: 1.5 }, acts: [['attack', 3], ['inksplash', 2]], hop: 1 },
    // 2406
    gearbug: { name: '歯車ムシ', spr: 'gearbug', pal: P('#8a929a', '#c8a050', '#57c4e6', '#ff4040'), hp: 104, atk: 34, mag: 20, def: 16, mdef: 10, spd: 11, exp: 99, g: 50, drop: ['hisalve', 0.15], weak: { thunder: 1.6 }, acts: [['attack', 3], ['gearspin', 2]], roam: 1 },
    stopdoll: { name: '止まり人形', spr: 'stopdoll', pal: P('#e8e2d8', '#7a8a9a', '#57c4e6', '#101828'), hp: 120, atk: 32, mag: 30, def: 13, mdef: 16, spd: 9, exp: 112, g: 60, drop: ['cure', 0.3], weak: { light: 1.5 }, resist: { dark: 0.5 }, acts: [['attack', 2], ['stoptouch', 1], ['still', 1]] },
    watcheye: { name: '見張りの目', spr: 'watcheye', pal: P('#5a6270', '#8a929a', '#ff4040', '#ff3030'), hp: 88, atk: 28, mag: 31, def: 11, mdef: 15, spd: 12, exp: 105, g: 55, drop: ['dew', 0.15], weak: { thunder: 1.5, earth: 1.3 }, acts: [['laser', 3], ['scan_alarm', 1]], fly: 1, roam: 1 },
    inkgold: { name: 'こがねインク', spr: 'inkblob', pal: P('#c8962a', '#8a6a1a', '#fff0a0', '#2a1a10'), hp: 70, atk: 30, mag: 30, def: 30, mdef: 30, spd: 18, exp: 240, g: 300, drop: ['bigdew', 0.25], weak: {}, acts: [['attack', 2], ['flee', 1]], hop: 1 },
    // 前800
    cloudjelly: { name: '雲クラゲ', spr: 'cloudjelly', pal: P('#f0f4ff', '#a8c8f0', '#ffffff', '#3a4a6a'), hp: 170, atk: 50, mag: 48, def: 18, mdef: 24, spd: 10, exp: 220, g: 80, drop: ['dew', 0.2], weak: { thunder: 1.5, fire: 1.3 }, resist: { water: 0.5 }, acts: [['attack', 2], ['mist', 2], ['sting', 1]], fly: 1, roam: 1 },
    pendbird: { name: '振り子鳥', spr: 'pendbird', pal: P('#e8d8a8', '#c8a050', '#e2b04a', '#1a1020'), hp: 150, atk: 58, mag: 30, def: 20, mdef: 16, spd: 15, exp: 230, g: 85, drop: ['hisalve', 0.2], weak: { wind: 1.5 }, acts: [['attack', 3], ['pendswing', 2]], fly: 1, roam: 1 },
    springknight: { name: 'ゼンマイ騎士', spr: 'springknight', pal: P('#d8c08a', '#a8884a', '#e2b04a', '#57c4e6'), hp: 260, atk: 64, mag: 20, def: 34, mdef: 14, spd: 9, exp: 320, g: 120, drop: ['fullsalve', 0.1], weak: { thunder: 1.5, earth: 1.2 }, acts: [['attack', 3], ['windup', 1], ['slash', 2]] },
    // final
    shard: { name: 'とばりの欠片', spr: 'shard', pal: P('#efe6f8', '#b8b0d0', '#ffffff', '#ff4060'), hp: 260, atk: 66, mag: 64, def: 26, mdef: 30, spd: 13, exp: 440, g: 140, drop: ['bigdew', 0.08], weak: { light: 1.6 }, resist: { dark: 0 }, acts: [['attack', 2], ['stoptouch', 1], ['stillwave', 1]], fly: 1 },
    seawisp: { name: '泡のゆうれい', spr: 'seawisp', pal: P('#9ae0f0', '#58a8c0', '#ffffff', '#0a1a2a'), hp: 220, atk: 60, mag: 70, def: 22, mdef: 34, spd: 12, exp: 420, g: 130, drop: ['dew', 0.25], weak: { thunder: 1.5, light: 1.3 }, resist: { water: 0 }, acts: [['attack', 2], ['bubble', 2], ['mist', 1]], fly: 1, roam: 1 },

    // ----- bosses -----
    waxseal: { name: 'うずまき封蝋', spr: 'waxseal', pal: P('#b8382e', '#8a2a22', '#ffd060', '#ff4040'), hp: 340, atk: 22, mag: 16, def: 6, mdef: 6, spd: 9, exp: 130, g: 150, boss: 1, weak: { wind: 1.3 }, acts: [['attack', 3], ['waxdrip', 2], ['swirl', 1]], ai: 'waxseal' },
    ashgram: { name: '灰喰いグラム', spr: 'ashgram', pal: P('#5a4a48', '#3a2a28', '#ff8a2a', '#ffd040'), hp: 760, atk: 34, mag: 26, def: 12, mdef: 10, spd: 9, exp: 650, g: 400, boss: 1, weak: { water: 1.5, earth: 1.2 }, resist: { fire: 0 }, acts: [['bite', 2], ['ashbreath', 1]], ai: 'ashgram' },
    ashclaw: { name: 'グラムの腕', spr: 'ashclaw', pal: P('#5a4a48', '#3a2a28', '#ff8a2a', '#ffd040'), hp: 220, atk: 28, mag: 10, def: 16, mdef: 6, spd: 10, exp: 90, g: 0, boss: 1, part: 1, weak: { wind: 1.3 }, resist: { fire: 0 }, acts: [['attack', 3], ['claw', 2]], ai: 'ashclaw' },
    geargolem: { name: '時計守ギアゴーレム', spr: 'geargolem', pal: P('#8a3a2e', '#6a7280', '#e2b04a', '#ff4040'), hp: 2200, atk: 62, mag: 44, def: 26, mdef: 18, spd: 9, exp: 1920, g: 1000, boss: 1, weak: { thunder: 1.4 }, acts: [['attack', 2], ['punch', 2], ['chime', 1]], ai: 'geargolem' },
    queenshadow: { name: 'とばりの影', spr: 'queenshadow', pal: P('#2a2440', '#4a4470', '#e2b04a', '#ff4060'), hp: 2000, atk: 56, mag: 54, def: 24, mdef: 26, spd: 10, exp: 3600, g: 1600, boss: 1, weak: { light: 1.5 }, resist: { dark: 0 }, acts: [['attack', 2], ['stillwave', 2], ['stoptouch', 1]], ai: 'queen' },
    pendulum: { name: '影の振り子', spr: 'pendulum', pal: P('#3a3460', '#4a4470', '#c8a050', '#ff4060'), hp: 380, atk: 44, mag: 36, def: 22, mdef: 18, spd: 9, exp: 225, g: 0, boss: 1, part: 1, weak: { earth: 1.4 }, acts: [['pendswing', 1]], ai: 'pendulum' },
    shijima1: { name: 'とばり', spr: 'shijima1', pal: P('#efe6d2', '#8a8498', '#ffffff', '#ff3050'), hp: 3800, atk: 70, mag: 66, def: 27, mdef: 27, spd: 11, exp: 0, g: 0, boss: 1, weak: { light: 1.3 }, resist: { dark: 0 }, acts: [['attack', 2], ['stillwave', 2], ['erase', 1]], ai: 'shijima1' },
    shijimacore: { name: 'とばりの核', spr: 'shijimacore', pal: P('#3a3460', '#efe6d2', '#ff3050', '#ff3050'), hp: 2200, atk: 56, mag: 56, def: 28, mdef: 28, spd: 12, exp: 0, g: 0, boss: 1, weak: {}, resist: { dark: 0 }, acts: [['stillwave', 2], ['erase', 1]], ai: 'core' },
    nushi: { name: 'とどかずの主', spr: 'nushi', pal: P('#d8ccb0', '#c9473d', '#3765b0', '#ff3050'), hp: 12000, atk: 96, mag: 92, def: 36, mdef: 36, spd: 12, exp: 6000, g: 5000, boss: 1, weak: { light: 1.2, wind: 1.2 }, resist: { dark: 0 }, acts: [['attack', 2], ['returnto', 2], ['stillwave', 1], ['erase', 1]], ai: 'nushi' },
    seal_l: { name: '封の印・左', spr: 'seal', pal: P('#3765b0', '#c9473d', '#ffffff', '#ffffff'), hp: 560, atk: 44, mag: 46, def: 32, mdef: 16, spd: 10, exp: 0, g: 0, boss: 1, part: 1, weak: { earth: 1.3 }, acts: [['sealbeam', 1]], ai: 'seal' },
    seal_r: { name: '封の印・右', spr: 'seal', pal: P('#c9473d', '#3765b0', '#ffffff', '#ffffff'), hp: 560, atk: 44, mag: 46, def: 16, mdef: 32, spd: 10, exp: 0, g: 0, boss: 1, part: 1, weak: { thunder: 1.3 }, acts: [['sealheal', 1]], ai: 'seal' },
    shijima3: { name: 'とばり（真の姿）', spr: 'shijima3', pal: P('#efe6d2', '#2a2440', '#e2b04a', '#ff3050'), hp: 4200, atk: 58, mag: 48, def: 28, mdef: 28, spd: 10, exp: 0, g: 0, boss: 1, weak: { light: 1.2 }, resist: { dark: 0 }, acts: [['attack', 2], ['stillwave', 2], ['erase', 1], ['unsaid', 1]], ai: 'shijima3' },
  };
  // enemy techs
  D.ETECH = {
    attack: { name: null, kind: 'phys', power: 1.0, area: 'single' },
    bite: { name: 'かみつき', kind: 'phys', power: 1.35, area: 'single', fx: 'bite' },
    swoop: { name: 'きゅうこうか', kind: 'phys', power: 1.25, area: 'single', fx: 'swoop' },
    pinch: { name: 'はさむ', kind: 'phys', power: 1.5, area: 'single', fx: 'bite' },
    claw: { name: 'ひっかき', kind: 'phys', power: 1.5, area: 'single', fx: 'bite' },
    punch: { name: 'てっけん', kind: 'phys', power: 1.6, area: 'single', fx: 'heavy' },
    slash: { name: 'きりつけ', kind: 'phys', power: 1.45, area: 'single', fx: 'slash' },
    shell: { name: 'からにこもる', kind: 'self', status: 'guard', fx: 'buff' },
    guardup: { name: 'かまえる', kind: 'self', status: 'guard', fx: 'buff' },
    windup: { name: 'ねじを巻く', kind: 'self', status: 'haste', fx: 'buff' },
    inksplash: { name: 'インクとばし', kind: 'mag', power: 0.9, area: 'circleT', r: 26, elem: 'dark', status: 'poison', chance: 0.35, fx: 'ink' },
    firebreath: { name: 'ひのいき', kind: 'mag', power: 1.2, area: 'line', elem: 'fire', fx: 'fireline' },
    emberlight: { name: 'ほたび', kind: 'mag', power: 1.0, area: 'single', elem: 'fire', fx: 'fireball' },
    spores: { name: 'ねむりの胞子', kind: 'status', area: 'circleT', r: 30, status: 'sleep', chance: 0.55, fx: 'spores' },
    gearspin: { name: 'はぐるまかいてん', kind: 'phys', power: 1.1, area: 'circleS', r: 44, fx: 'spin' },
    stoptouch: { name: 'とめる指', kind: 'status', area: 'single', status: 'stop', chance: 0.5, fx: 'still' },
    still: { name: 'しずけさ', kind: 'status', area: 'all', status: 'slow', chance: 0.4, fx: 'stillwave' },
    laser: { name: 'けいこうせん', kind: 'mag', power: 1.2, area: 'line', elem: 'fire', fx: 'laser' },
    scan_alarm: { name: 'けいほう', kind: 'self', status: 'haste', fx: 'alarm' },
    flee: { name: 'にげだした', kind: 'flee' },
    mist: { name: 'つめたい霧', kind: 'mag', power: 0.85, area: 'all', elem: 'water', status: 'slow', chance: 0.25, fx: 'mist' },
    sting: { name: 'さす', kind: 'phys', power: 1.2, area: 'single', status: 'poison', chance: 0.5, fx: 'bite' },
    pendswing: { name: 'ふりこうち', kind: 'phys', power: 1.3, area: 'line', fx: 'swing' },
    bubble: { name: 'あわだま', kind: 'mag', power: 1.2, area: 'circleT', r: 28, elem: 'water', fx: 'bubble' },
    stillwave: { name: 'とばりの波', kind: 'mag', power: 1.0, area: 'all', elem: 'dark', status: 'slow', chance: 0.25, fx: 'stillwave' },
    // boss techs
    waxdrip: { name: 'ろうのしずく', kind: 'mag', power: 1.2, area: 'circleT', r: 26, elem: 'fire', fx: 'wax' },
    swirl: { name: 'うずまき', kind: 'mag', power: 0.9, area: 'all', elem: 'none', fx: 'swirl' },
    ashbreath: { name: 'はいのいき', kind: 'mag', power: 1.1, area: 'all', elem: 'fire', fx: 'ash' },
    devour: { name: 'のみこむ', kind: 'phys', power: 2.2, area: 'single', fx: 'bite' },
    chime: { name: '時報', kind: 'mag', power: 1.15, area: 'all', elem: 'thunder', fx: 'chime' },
    overclock: { name: 'オーバークロック', kind: 'self', status: 'haste', fx: 'alarm' },
    erase: { name: '白紙', kind: 'mag', power: 2.0, area: 'single', elem: 'dark', fx: 'erase' },
    unsaid: { name: 'いえなかったことば', kind: 'mag', power: 1.35, area: 'all', elem: 'dark', status: 'stop', chance: 0.15, fx: 'unsaid' },
    returnto: { name: '差出人へ返送', kind: 'mag', power: 1.25, area: 'all', elem: 'none', fx: 'unsaid' },
    stampslam: { name: '大消印', kind: 'phys', power: 1.6, area: 'circleT', r: 34, fx: 'heavy' },
    sealbeam: { name: '封印の光', kind: 'mag', power: 1.4, area: 'line', elem: 'dark', fx: 'laser' },
    sealheal: { name: '封印の修復', kind: 'healboss', fx: 'heal' },
  };

  // ---------------- Shops ----------------
  D.SHOPS = {
    hasune: ['salve', 'cure', 'w_dagger', 't_brass', 'b_clothes', 'b_leather', 'h_cap', 'h_leather'],
    varn: ['salve', 'hisalve', 'cure', 'revive', 'dew', 'blanket', 'w_knight', 't_star', 'l_knight', 'b_chain', 'h_iron', 'c_bell'],
    hub: ['salve', 'hisalve', 'cure', 'revive', 'dew', 'blanket'],
    future: ['hisalve', 'cure', 'revive', 'dew', 'blanket', 'w_silver', 't_volt', 'l_silver', 'a_volt', 'b_fiber', 'h_fiber', 'c_ward', 'c_badge'],
    sky: ['hisalve', 'fullsalve', 'allsalve', 'revive', 'dew', 'bigdew', 'blanket', 'w_cloud', 't_sky', 'l_sky', 'a_sky', 'b_feather', 'h_feather', 'c_power', 'c_magic', 'c_clock'],
  };
  D.INN = { hasune: 10, varn: 30, future: 80, sky: 150 };
})();
