'use strict';
// Chip-style synthesizer and sequencer (all sound is generated; no audio files)
(function () {
  const A = G.audio = {
    ac: null, unlocked: false, song: null, songId: null, timer: null, waves: {}, noise: null,
    pendingSong: null,
  };
  const midiHz = m => 440 * Math.pow(2, (m - 69) / 12);
  A.midiHz = midiHz;

  function makePulse(ac, duty) {
    const n = 48, re = new Float32Array(n), im = new Float32Array(n);
    for (let k = 1; k < n; k++) re[k] = (2 / (k * Math.PI)) * Math.sin(Math.PI * k * duty);
    return ac.createPeriodicWave(re, im);
  }

  A.unlock = function () {
    if (A.ac) { if (A.ac.state === 'suspended') A.ac.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ac = A.ac = new AC();
    A.master = ac.createGain(); A.master.gain.value = 0.55;
    const comp = ac.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 10; comp.ratio.value = 4; comp.attack.value = 0.004; comp.release.value = 0.18;
    A.master.connect(comp); comp.connect(ac.destination);
    A.music = ac.createGain(); A.music.connect(A.master);
    A.sfxG = ac.createGain(); A.sfxG.connect(A.master);
    // echo bus for leads
    A.echo = ac.createDelay(1); A.echo.delayTime.value = 0.27;
    A.echoFb = ac.createGain(); A.echoFb.gain.value = 0.28;
    A.echoOut = ac.createGain(); A.echoOut.gain.value = 0.22;
    const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
    A.echo.connect(lp); lp.connect(A.echoFb); A.echoFb.connect(A.echo); lp.connect(A.echoOut); A.echoOut.connect(A.music);
    A.waves.p12 = makePulse(ac, 0.125); A.waves.p25 = makePulse(ac, 0.25); A.waves.p50 = makePulse(ac, 0.5);
    const len = ac.sampleRate * 1.5, buf = ac.createBuffer(1, len, ac.sampleRate), d = buf.getChannelData(0);
    let r = 1; for (let i = 0; i < len; i++) { r ^= r << 13; r ^= r >> 17; r ^= r << 5; d[i] = ((r >>> 0) / 4294967296) * 2 - 1; }
    A.noise = buf;
    A.applyVolume();
    A.unlocked = true;
    if (A.pendingSong) { const p = A.pendingSong; A.pendingSong = null; A.play(p.id, p.opt); }
  };
  A.applyVolume = function () {
    if (!A.ac) return;
    A.music.gain.setTargetAtTime(G.cfg.bgm * 0.9, A.ac.currentTime, 0.05);
    A.sfxG.gain.setTargetAtTime(G.cfg.se, A.ac.currentTime, 0.02);
  };

  // ---------- instruments ----------
  const INST = {
    lead: { wave: 'p25', a: 0.006, d: 0.16, s: 0.55, r: 0.09, vol: 0.16, vib: 1, echo: 1 },
    lead2: { wave: 'p12', a: 0.006, d: 0.2, s: 0.5, r: 0.08, vol: 0.13, vib: 1, echo: 1 },
    soft: { wave: 'p50', a: 0.03, d: 0.3, s: 0.6, r: 0.18, vol: 0.09, vib: 1, echo: 1, lp: 1800 },
    harm: { wave: 'p50', a: 0.004, d: 0.09, s: 0.25, r: 0.05, vol: 0.07, lp: 2400 },
    arp: { wave: 'p12', a: 0.002, d: 0.07, s: 0.2, r: 0.04, vol: 0.065, echo: 0.6 },
    pad: { wave: 'p50', a: 0.25, d: 0.5, s: 0.7, r: 0.5, vol: 0.045, lp: 1200, detune: 7 },
    bass: { wave: 'triangle', a: 0.004, d: 0.12, s: 0.75, r: 0.05, vol: 0.32 },
    sbass: { wave: 'p50', a: 0.004, d: 0.1, s: 0.5, r: 0.04, vol: 0.08, lp: 900 },
    bell: { wave: 'sine', a: 0.002, d: 0.9, s: 0.0, r: 0.4, vol: 0.16, bell: 1, echo: 0.8 },
    pluck: { wave: 'triangle', a: 0.002, d: 0.22, s: 0.0, r: 0.08, vol: 0.2, echo: 0.5 },
    flute: { wave: 'sine', a: 0.04, d: 0.2, s: 0.8, r: 0.12, vol: 0.13, vib: 1.4, echo: 1, breath: 1 },
  };
  A.INST = INST;

  function env(g, t, dur, I, peak) {
    const a = I.a, d = I.d, s = I.s, r = I.r;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.setTargetAtTime(Math.max(0.0001, peak * s), t + a, d / 3);
    const end = t + Math.max(dur, a + 0.01);
    g.gain.setTargetAtTime(0.0001, end, r / 3);
    return end + r * 2;
  }
  function tone(inst, midi, t, dur, vol = 1, dest) {
    const ac = A.ac, I = INST[inst]; if (!I) return;
    const f = midiHz(midi);
    const g = ac.createGain();
    let out = g;
    if (I.lp) { const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = I.lp; g.connect(lp); out = lp; }
    out.connect(dest || A.music);
    if (I.echo) { const eg = ac.createGain(); eg.gain.value = I.echo; out.connect(eg); eg.connect(A.echo); }
    const oscs = [];
    const mk = (det, mult = 1, gainMul = 1) => {
      const o = ac.createOscillator();
      if (A.waves[I.wave]) o.setPeriodicWave(A.waves[I.wave]); else o.type = I.wave;
      o.frequency.value = f * mult; o.detune.value = det;
      if (gainMul !== 1) { const gg = ac.createGain(); gg.gain.value = gainMul; o.connect(gg); gg.connect(g); } else o.connect(g);
      oscs.push(o); return o;
    };
    mk(0);
    if (I.detune) mk(I.detune, 1, 0.8);
    if (I.bell) { mk(0, 2.0, 0.35); mk(3, 3.01, 0.12); }
    if (I.vib && dur > 0.22) {
      const lfo = ac.createOscillator(), lg = ac.createGain();
      lfo.frequency.value = 5.6; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(f * 0.006 * I.vib, t + Math.min(0.5, dur));
      lfo.connect(lg); oscs.forEach(o => lg.connect(o.frequency)); lfo.start(t); lfo.stop(t + dur + 0.6);
    }
    const end = env(g, t, dur, I, I.vol * vol);
    oscs.forEach(o => { o.start(t); o.stop(end + 0.05); });
  }
  function drum(kind, t, vol = 1, dest) {
    const ac = A.ac, out = dest || A.music;
    if (kind === 'k') {
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
      g.gain.setValueAtTime(0.55 * vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
      o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.22);
      return;
    }
    const src = ac.createBufferSource(); src.buffer = A.noise;
    const f = ac.createBiquadFilter(), g = ac.createGain();
    let len = 0.05, v = 0.2;
    if (kind === 's') { f.type = 'bandpass'; f.frequency.value = 1900; f.Q.value = 0.7; len = 0.16; v = 0.32;
      const o = ac.createOscillator(), og = ac.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(190, t); o.frequency.exponentialRampToValueAtTime(120, t + 0.08);
      og.gain.setValueAtTime(0.22 * vol, t); og.gain.exponentialRampToValueAtTime(0.001, t + 0.1); o.connect(og); og.connect(out); o.start(t); o.stop(t + 0.12);
    } else if (kind === 'h') { f.type = 'highpass'; f.frequency.value = 7000; len = 0.035; v = 0.1; }
    else if (kind === 'o') { f.type = 'highpass'; f.frequency.value = 6000; len = 0.18; v = 0.08; }
    else if (kind === 'c') { f.type = 'highpass'; f.frequency.value = 4000; len = 0.9; v = 0.12; }
    else if (kind === 't') { f.type = 'bandpass'; f.frequency.value = 600; f.Q.value = 2; len = 0.12; v = 0.25; }
    g.gain.setValueAtTime(v * vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + len);
    src.connect(f); f.connect(g); g.connect(out);
    src.start(t, Math.random() * 0.5); src.stop(t + len + 0.02);
  }
  A.tone = tone; A.drum = drum;

  // ---------- sequencer ----------
  // song = { bpm, len (16ths), loopFrom (16ths), events: [{t, d, m, inst, v}] sorted by t, drums: [{t, k, v}] }
  function tick() {
    const s = A.song; if (!s || !A.ac) return;
    const ac = A.ac, spb = 60 / s.bpm / 4; // seconds per 16th
    const ahead = ac.currentTime + 0.2;
    for (let guard = 0; guard < 2000; guard++) {
      const ev = s.evs[s.idx];
      if (!ev) {
        if (!s.loop || s.len <= s.loopFrom) return;
        s.offset += (s.len - s.loopFrom) * spb; s.idx = s.loopIdx; continue;
      }
      const when = s.offset + ev.t * spb;
      if (when > ahead) break;
      if (when >= ac.currentTime - 0.03) {
        if (ev.k) drum(ev.k, when, ev.v || 1, s.gain);
        else tone(ev.inst, ev.m + (s.transpose || 0), when, ev.d * spb * (ev.leg || 0.9), ev.v || 1, s.gain);
      }
      s.idx++;
    }
  }
  A.play = function (id, opt = {}) {
    if (!A.ac || !A.unlocked) { A.pendingSong = { id, opt }; A.songId = id; return; }
    if (A.songId === id && A.song && !opt.restart) return;
    A.stop(opt.fadeOut != null ? opt.fadeOut : 0.4);
    A.songId = id;
    const def = G.songs && G.songs[id];
    if (!def) { A.song = null; return; }
    const comp = def.compiled || (def.compiled = G.compileSong(def));
    const gain = A.ac.createGain(); gain.connect(A.music);
    gain.gain.value = 0.0001; gain.gain.setTargetAtTime(def.vol || 1, A.ac.currentTime + 0.02, opt.fadeIn || 0.03);
    const loopIdx = comp.evs.findIndex(e => e.t >= comp.loopFrom);
    A.song = { ...comp, idx: 0, offset: A.ac.currentTime + 0.08, gain, loopIdx: loopIdx < 0 ? 0 : loopIdx, loop: def.loop !== false };
    if (!A.timer) A.timer = setInterval(tick, 25);
    tick();
  };
  A.stop = function (fade = 0.4) {
    if (A.song && A.ac) {
      const g = A.song.gain; g.gain.cancelScheduledValues(A.ac.currentTime);
      g.gain.setTargetAtTime(0.0001, A.ac.currentTime, Math.max(0.01, fade / 4));
      setTimeout(() => { try { g.disconnect(); } catch (e) { } }, fade * 1000 + 600);
    }
    A.song = null; A.songId = null;
  };
  A.duck = function (amount, time = 0.3) {
    if (!A.ac) return; A.music.gain.setTargetAtTime(G.cfg.bgm * 0.9 * amount, A.ac.currentTime, time / 3);
  };

  // ---------- sound effects ----------
  function sweep(type, f0, f1, len, vol, t0 = 0, curve = 'exp') {
    const ac = A.ac, t = ac.currentTime + t0, o = ac.createOscillator(), g = ac.createGain();
    if (A.waves[type]) o.setPeriodicWave(A.waves[type]); else o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (curve === 'exp') o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + len); else o.frequency.linearRampToValueAtTime(f1, t + len);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + len);
    o.connect(g); g.connect(A.sfxG); o.start(t); o.stop(t + len + 0.02);
  }
  function noise(len, vol, ftype, f0, f1, t0 = 0, q = 1) {
    const ac = A.ac, t = ac.currentTime + t0, src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
    src.buffer = A.noise; f.type = ftype; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + len);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + len);
    src.connect(f); f.connect(g); g.connect(A.sfxG); src.start(t, Math.random()); src.stop(t + len + 0.02);
  }
  function notes(inst, list, step, vol = 1) {
    const t = A.ac.currentTime + 0.01;
    list.forEach((m, i) => { if (m != null) tone(inst, m, t + i * step, step * 0.9, vol, A.sfxG); });
  }
  const SFX = {
    cursor: () => sweep('p50', 1320, 1320, 0.035, 0.05),
    ok: () => { sweep('p25', 880, 880, 0.05, 0.06); sweep('p25', 1320, 1320, 0.07, 0.06, 0.05); },
    cancel: () => sweep('p25', 660, 330, 0.09, 0.06),
    buzz: () => { sweep('p50', 140, 120, 0.16, 0.08); },
    blip: (p = 0) => sweep('p50', 520 * Math.pow(2, p / 12), 520 * Math.pow(2, p / 12), 0.03, 0.025),
    step: () => noise(0.03, 0.03, 'lowpass', 900, 400),
    door: () => { noise(0.18, 0.12, 'lowpass', 1500, 200); sweep('triangle', 200, 120, 0.15, 0.1); },
    chest: () => { notes('pluck', [72, 76, 79, 84], 0.07, 1.4); },
    item: () => { notes('lead', [76, 79, 84, null, 84], 0.09, 1.3); },
    save: () => { notes('bell', [79, 84, 88, 91], 0.11, 1.2); },
    heal: () => { notes('bell', [84, 88, 91, 96, 100], 0.06, 0.9); sweep('sine', 600, 1400, 0.4, 0.05); },
    encounter: () => { sweep('p25', 220, 880, 0.18, 0.08); sweep('p25', 330, 1320, 0.18, 0.06, 0.06); noise(0.3, 0.1, 'highpass', 2000, 8000); },
    swing: () => noise(0.12, 0.14, 'bandpass', 2500, 700, 0, 1.2),
    hit: () => { noise(0.1, 0.3, 'lowpass', 3000, 300); sweep('square', 180, 60, 0.08, 0.12); },
    crit: () => { noise(0.18, 0.4, 'lowpass', 5000, 200); sweep('square', 300, 50, 0.16, 0.16); sweep('p25', 1600, 400, 0.12, 0.06); },
    miss: () => noise(0.12, 0.08, 'highpass', 3000, 6000),
    guard: () => { sweep('p50', 900, 700, 0.08, 0.06); noise(0.05, 0.1, 'highpass', 5000, 3000); },
    cast: () => { notes('arp', [72, 79, 84, 91], 0.04, 1.6); },
    wind: () => { noise(0.5, 0.25, 'bandpass', 600, 3200, 0, 3); noise(0.4, 0.15, 'bandpass', 2400, 500, 0.15, 4); },
    light: () => { notes('bell', [96, 103, 108], 0.05, 0.9); sweep('sine', 2000, 4000, 0.3, 0.05); },
    earth: () => { noise(0.6, 0.4, 'lowpass', 400, 60); sweep('triangle', 90, 35, 0.5, 0.3); },
    thunder: () => { noise(0.08, 0.4, 'highpass', 3000, 1000); noise(0.5, 0.35, 'lowpass', 2000, 100, 0.06); sweep('square', 1200, 80, 0.2, 0.08); },
    fire: () => { noise(0.45, 0.25, 'bandpass', 800, 300, 0, 0.8); noise(0.3, 0.1, 'highpass', 3000, 1500, 0.1); },
    ice: () => { notes('bell', [100, 95, 103, 98], 0.04, 0.6); noise(0.3, 0.1, 'highpass', 6000, 9000); },
    dark: () => { sweep('p12', 300, 70, 0.6, 0.1); noise(0.6, 0.12, 'lowpass', 600, 100); },
    boom: () => { noise(0.8, 0.5, 'lowpass', 1200, 40); sweep('triangle', 120, 30, 0.6, 0.35); },
    enemyDie: () => { sweep('p12', 900, 120, 0.35, 0.06); noise(0.35, 0.1, 'highpass', 4000, 1500); },
    ko: () => { sweep('p25', 440, 110, 0.4, 0.08); },
    run: () => { for (let i = 0; i < 4; i++) noise(0.04, 0.08, 'lowpass', 1200, 500, i * 0.06); },
    ready: () => sweep('p12', 1760, 1760, 0.03, 0.035),
    levelup: () => { notes('lead', [72, 76, 79, 84, 79, 84, 88], 0.075, 1.2); },
    buy: () => { notes('pluck', [84, 91], 0.06, 1.4); },
    stamp: () => { noise(0.08, 0.35, 'lowpass', 1800, 200); sweep('triangle', 160, 70, 0.1, 0.25); },
    warp: () => { sweep('sine', 200, 1600, 0.9, 0.12); sweep('p12', 1600, 200, 0.9, 0.05); noise(0.9, 0.08, 'bandpass', 500, 4000, 0, 2); },
    rift: () => { sweep('p12', 80, 40, 1.5, 0.1); noise(1.5, 0.15, 'bandpass', 200, 1500, 0, 3); },
    switch: () => { sweep('square', 400, 400, 0.04, 0.08); sweep('square', 600, 600, 0.05, 0.08, 0.05); },
    gear: () => { for (let i = 0; i < 5; i++) noise(0.03, 0.12, 'bandpass', 1500, 1200, i * 0.07, 3); },
    freeze: () => { notes('bell', [108, 103, 99], 0.05, 0.7); sweep('sine', 3000, 200, 0.6, 0.05); },
    splash: () => noise(0.4, 0.2, 'bandpass', 1500, 400, 0, 1),
    poison: () => { sweep('p50', 400, 200, 0.2, 0.05); sweep('p50', 300, 150, 0.2, 0.05, 0.1); },
    letter: () => { notes('bell', [84, 91, 96], 0.12, 1.2); },
  };
  A.sfx = function (name, ...args) {
    if (!A.ac || !A.unlocked) return;
    const f = SFX[name]; if (f) try { f(...args); } catch (e) { }
  };
  G.se = A.sfx;
  G.bgm = (id, opt) => A.play(id, opt);
})();
