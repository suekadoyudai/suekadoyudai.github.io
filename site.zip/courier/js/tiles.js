'use strict';
// Procedural 16x16 tiles. Each era has its own palette so the same layouts read very differently.
(function () {
  const { Spr, shade, mix, bayer } = G.art;
  const PAL = {
    hasune: {
      g: ['#68a84c', '#548f3e', '#86c463', '#3f7333'], d: ['#c29a64', '#a47f4f', '#d8b880'], c: ['#b6ada0', '#968d80', '#d2cabd', '#7b7266'],
      s: ['#e5d29c', '#cfba84', '#f3e6bd'], w: ['#3577b0', '#285f95', '#5597cf', '#cfe9f5'], r: ['#9b8f7c', '#776c5c', '#b9ad98'],
      wall: ['#efe4cb', '#d5c6a6', '#fff6e2'], fl: ['#a8774a', '#8a5f3a', '#c08e5e'], tree: ['#4f9a45', '#3a7536', '#72bb5a', '#7a5434', '#5a3c26'],
      fence: ['#d9c8a2', '#b19f7c'], acc: '#d65a4a', flower: ['#f2e05c', '#f08aa0', '#ffffff', '#9bc8ff'],
    },
    varn: {
      g: ['#8a9a4a', '#727f3d', '#a8b45e', '#5a6532'], d: ['#9c7a52', '#7f6242', '#b8966a'], c: ['#9c9688', '#7c766a', '#b8b2a2', '#625d53'],
      s: ['#cdbb8c', '#b5a276', '#e0d2a8'], w: ['#3f6f86', '#2f5669', '#5d8fa6', '#cde3e8'], r: ['#8c8270', '#6a604f', '#aba08a'],
      wall: ['#a39c8c', '#827b6c', '#c0b9a8'], fl: ['#8e6c4a', '#715538', '#a8845c'], tree: ['#c0662f', '#933f22', '#e09040', '#5f4630', '#46321f'],
      fence: ['#8a6a48', '#684e33'], acc: '#b03a2e', flower: ['#e8c040', '#d06030', '#f0e6c8', '#c8a0e0'],
    },
    cave: {
      g: ['#5b4a44', '#47382f', '#715d52', '#33271f'], d: ['#6e5546', '#563f33', '#87695a'], c: ['#6a5a52', '#53453e', '#83716a', '#3f342f'],
      s: ['#8a6a50', '#6e5240', '#a4846a'], w: ['#d0521e', '#a03812', '#f0902a', '#ffe070'], r: ['#5e4a40', '#45352d', '#7a6254'],
      wall: ['#5e4a40', '#3e2f27', '#7a6254'], fl: ['#5b4a44', '#47382f', '#715d52'], tree: ['#7a3a2a', '#5a2418', '#a0502e', '#3a2a22', '#2a1c16'],
      fence: ['#6a5040', '#4a3628'], acc: '#ff8a2a', flower: ['#ff9a3a', '#ffd060', '#ffefb0', '#ff6a2a'],
    },
    hub: {
      g: ['#3a3466', '#2e2852', '#4a4480', '#221d3e'], d: ['#5a4a6e', '#463a58', '#6e5e86'], c: ['#4a4470', '#3a355a', '#5e5888', '#2a2646'],
      s: ['#6a5a7e', '#544866', '#827296'], w: ['#1e1838', '#15102a', '#2c2650', '#8a80c8'], r: ['#3e3860', '#2c2848', '#524c7a'],
      wall: ['#4a3e6a', '#352c50', '#5e5284'], fl: ['#6e4e3e', '#573c30', '#86604c'], tree: ['#4a4480', '#352f60', '#6a64a8', '#3a2e48', '#2a2036'],
      fence: ['#8a6a50', '#6a503c'], acc: '#e2b04a', flower: ['#efe6d2', '#e2b04a', '#c9473d', '#3765b0'],
    },
    future: {
      g: ['#7d8c8a', '#68766f', '#97a5a2', '#525e5a'], d: ['#8a8680', '#706c66', '#a29e98'], c: ['#8c949c', '#6e767e', '#a8b0b8', '#555c64'],
      s: ['#a49c8c', '#8a8274', '#bcb4a4'], w: ['#5d7f99', '#4a6880', '#7ea0b8', '#e0f0ff'], r: ['#6f7780', '#565d66', '#8a929a'],
      wall: ['#a2aab2', '#7e868e', '#c0c8d0'], fl: ['#7a8288', '#62696f', '#949ca2'], tree: ['#7c8a84', '#606c66', '#98a6a0', '#5a5450', '#423e3a'],
      fence: ['#7a8288', '#5a6268'], acc: '#57c4e6', flower: ['#cfe6f0', '#a8c0d0', '#ffffff', '#8ad0e8'],
    },
    sky: {
      g: ['#a8d8a0', '#88c088', '#c8ecb8', '#6aa478'], d: ['#e6d6a8', '#cdbb8a', '#f6ead0'], c: ['#e8e2d2', '#cfc6b0', '#fffaf0', '#b8ad94'],
      s: ['#f2e8c8', '#ddd0a8', '#fff8e4'], w: ['#86b8e8', '#6a9ed4', '#a8d4f8', '#ffffff'], r: ['#d8cbb0', '#b8a888', '#f0e6d0'],
      wall: ['#e8dcc0', '#c9b890', '#fff4dc'], fl: ['#e0c27a', '#c4a25a', '#f4dc9c'], tree: ['#8fd08a', '#68ac6e', '#b4eaa4', '#a88a60', '#86683e'],
      fence: ['#d8b860', '#b09040'], acc: '#e2b04a', flower: ['#ffffff', '#ffd6e8', '#fff0a0', '#c0e0ff'],
    },
    deep: {
      g: ['#2f6a6a', '#245656', '#3f8282', '#1a4040'], d: ['#5a7a6e', '#46625a', '#6e9284'], c: ['#4a6a70', '#3a565c', '#5e8288', '#2a4046'],
      s: ['#8a9a7a', '#707e64', '#a4b490'], w: ['#123a4e', '#0c2c3c', '#1e5068', '#58a8c0'], r: ['#3a5a5e', '#2a4448', '#4e7276'],
      wall: ['#a8884a', '#7e6232', '#d0aa62'], fl: ['#3e5a5a', '#2e4646', '#527070'], tree: ['#2e8a6a', '#1f6a50', '#48b088', '#3a4a40', '#28362e'],
      fence: ['#a8884a', '#7e6232'], acc: '#f0c860', flower: ['#ff8aa8', '#ffb070', '#90f0d0', '#e0a0ff'],
    },
    house: {
      g: ['#68a84c', '#548f3e', '#86c463', '#3f7333'], d: ['#c29a64', '#a47f4f', '#d8b880'], c: ['#b6ada0', '#968d80', '#d2cabd', '#7b7266'],
      s: ['#e5d29c', '#cfba84', '#f3e6bd'], w: ['#3577b0', '#285f95', '#5597cf', '#cfe9f5'], r: ['#9b8f7c', '#776c5c', '#b9ad98'],
      wall: ['#e8d6b0', '#c9b289', '#f6e8c8'], fl: ['#b07c4c', '#8e603a', '#c8945e'], tree: ['#4f9a45', '#3a7536', '#72bb5a', '#7a5434', '#5a3c26'],
      fence: ['#d9c8a2', '#b19f7c'], acc: '#c9473d', flower: ['#f2e05c', '#f08aa0', '#ffffff', '#9bc8ff'],
    },
  };
  PAL.tower = Object.assign({}, PAL.future, { wall: ['#5a6470', '#444c56', '#727c88'], fl: ['#4e5862', '#3e4650', '#626c76'] });
  PAL.varnhouse = Object.assign({}, PAL.varn, { wall: ['#b8a888', '#988868', '#d0c0a0'], fl: ['#8e6c4a', '#715538', '#a8845c'] });
  G.PAL = PAL;

  // ---- tile painters ----
  const T = {};
  const def = (name, props, draw) => { T[name] = Object.assign({ draw }, props); };

  function speck(s, r, n, cols, x0 = 0, y0 = 0, w = 16, h = 16) { for (let i = 0; i < n; i++) s.px(x0 + Math.floor(r() * w), y0 + Math.floor(r() * h), cols[Math.floor(r() * cols.length)]); }
  function grassBase(s, p, r, v) {
    const [b, dk, lt] = p.g;
    s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const n = r(); if (n < 0.07) s.px(x, y, dk); else if (n < 0.1) s.px(x, y, lt); }
    const tufts = 2 + (v % 3);
    for (let i = 0; i < tufts; i++) { const x = 1 + Math.floor(r() * 13), y = 3 + Math.floor(r() * 11); s.px(x, y, lt); s.px(x + 1, y - 1, lt); s.px(x + 2, y, lt); s.px(x + 1, y, dk); }
  }
  def('grass', { vars: 4 }, (s, p, r, f, v) => grassBase(s, p, r, v));
  def('flowers', { vars: 3 }, (s, p, r, f, v) => {
    grassBase(s, p, r, v);
    for (let i = 0; i < 4; i++) { const x = 1 + Math.floor(r() * 13), y = 1 + Math.floor(r() * 13), c = p.flower[(v + i) % p.flower.length]; s.px(x, y, c); s.px(x + 1, y, c); s.px(x, y + 1, c); s.px(x + 1, y + 1, shade(c, -0.2)); s.px(x, y + 2, p.g[1]); }
  });
  def('tallgrass', { vars: 2 }, (s, p, r, f, v) => {
    grassBase(s, p, r, v);
    for (let i = 0; i < 7; i++) { const x = Math.floor(r() * 15), y = 5 + Math.floor(r() * 10); s.vline(x, y - 3, y, p.g[3]); s.px(x, y - 4, p.g[2]); s.vline(x + 1, y - 2, y, p.g[1]); }
  });
  def('dirt', { vars: 3 }, (s, p, r) => {
    const [b, dk, lt] = p.d; s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const n = r(); if (n < 0.1) s.px(x, y, dk); else if (n < 0.16) s.px(x, y, lt); }
    for (let i = 0; i < 2; i++) { const x = Math.floor(r() * 14), y = Math.floor(r() * 14); s.px(x, y, lt); s.px(x + 1, y + 1, dk); }
  });
  def('sand', { vars: 3 }, (s, p, r) => {
    const [b, dk, lt] = p.s; s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const n = r(); if (n < 0.08) s.px(x, y, dk); else if (n < 0.14) s.px(x, y, lt); }
  });
  def('cobble', { vars: 4 }, (s, p, r) => {
    const [b, dk, lt, m] = p.c; s.rect(0, 0, 16, 16, m);
    const stones = [[0, 0, 6, 5], [7, 0, 9, 4], [0, 6, 4, 5], [5, 5, 6, 6], [12, 5, 4, 5], [0, 12, 7, 4], [8, 12, 8, 4], [12, 0, 4, 4]];
    for (const [x, y, w, h] of stones) {
      const c = r() < 0.3 ? shade(b, -0.08) : r() < 0.3 ? shade(b, 0.06) : b;
      s.rect(x, y, w - 1, h - 1, c); s.hline(x, x + w - 2, y, lt); s.vline(x, y, y + h - 2, shade(lt, -0.05)); s.hline(x + 1, x + w - 2, y + h - 2, dk);
    }
  });
  def('plaza', { vars: 2 }, (s, p, r) => {
    const [b, dk, lt, m] = p.c; s.rect(0, 0, 16, 16, b);
    s.hline(0, 15, 0, lt); s.vline(0, 0, 15, lt); s.hline(0, 15, 15, dk); s.vline(15, 0, 15, dk); s.hline(1, 14, 7, m); s.vline(7, 8, 14, m);
    speck(s, r, 10, [dk, lt]);
  });
  def('water', { solid: 1, frames: 4, water: 1 }, (s, p, r, f, v, x, y) => {
    const [b, dk, lt, fo] = p.w; s.rect(0, 0, 16, 16, b);
    for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) if (bayer(i + x * 16, j + y * 16) < 0.18 && (j + i) % 3 === 0) s.px(i, j, dk);
    for (let k = 0; k < 3; k++) {
      const yy = (k * 5 + 2 + (x * 7 + y * 3) % 4) % 16, xx = ((k * 6 + f * 2 + x * 5) % 16);
      s.hline(xx, xx + 3, yy, lt); if (k === 0) s.px(xx + 1, yy - 1, fo);
    }
  });
  def('deepwater', { solid: 1, frames: 4, water: 1 }, (s, p, r, f, v, x, y) => {
    const [b, dk, lt] = p.w; s.rect(0, 0, 16, 16, dk);
    for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) if (bayer(i, j) < 0.25 && (i + j + f) % 4 === 0) s.px(i, j, b);
    const yy = (5 + x * 3 + y * 7) % 14, xx = (f * 3 + x * 5) % 13; s.hline(xx, xx + 2, yy, b);
  });
  def('lava', { solid: 1, frames: 4, water: 1, glow: '#ff7020' }, (s, p, r, f, v, x, y) => {
    const [b, dk, lt, hi] = p.w; s.rect(0, 0, 16, 16, b);
    for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) { const n = Math.sin((i + x * 16) * 0.5 + f * 0.8) + Math.cos((j + y * 16) * 0.45 - f * 0.6); if (n > 1.1) s.px(i, j, lt); else if (n > 1.6) s.px(i, j, hi); else if (n < -1.2) s.px(i, j, dk); }
  });
  def('rockwall', { solid: 1, vars: 3 }, (s, p, r) => {
    const [b, dk, lt] = p.r; s.rect(0, 0, 16, 16, b);
    const blocks = [[0, 0, 7, 6], [7, 0, 9, 5], [0, 6, 5, 6], [5, 5, 7, 7], [12, 5, 4, 6], [0, 12, 9, 4], [9, 12, 7, 4]];
    for (const [x, y, w, h] of blocks) { s.hline(x, x + w - 1, y, lt); s.vline(x, y, y + h - 1, lt); s.hline(x, x + w - 1, y + h - 1, dk); s.vline(x + w - 1, y, y + h - 1, dk); if (r() < 0.6) s.px(x + 2, y + 2, shade(b, 0.1)); }
  });
  def('cliff', { solid: 1, vars: 2 }, (s, p, r) => {
    const [b, dk, lt] = p.r; s.rect(0, 0, 16, 16, b);
    for (let x = 0; x < 16; x += 4) { const o = Math.floor(r() * 3); s.vline(x + o, 0, 15, dk); s.vline(x + o + 1, 0, 15, lt); }
    for (let i = 0; i < 6; i++) { const x = Math.floor(r() * 15), y = Math.floor(r() * 15); s.px(x, y, dk); s.px(x, y + 1, dk); }
  });
  def('cliftop', { solid: 1, vars: 2 }, (s, p, r, f, v) => {
    grassBase(s, p, r, v); const [b, dk, lt] = p.r;
    s.rect(0, 11, 16, 5, b); s.hline(0, 15, 11, p.g[3]); s.hline(0, 15, 12, lt);
    for (let x = 0; x < 16; x += 3) s.vline(x + Math.floor(r() * 2), 13, 15, dk);
  });
  def('wall', { solid: 1 }, (s, p, r) => {
    const [b, dk, lt] = p.wall; s.rect(0, 0, 16, 16, b);
    for (let row = 0; row < 4; row++) { const y = row * 4, off = row % 2 ? 4 : 0; s.hline(0, 15, y + 3, dk); for (let x = off; x < 16; x += 8) s.vline(x, y, y + 2, dk); s.hline(0, 15, y, lt); }
  });
  def('walltop', { solid: 1 }, (s, p) => { const [b, dk] = p.wall; s.rect(0, 0, 16, 16, shade(dk, -0.45)); s.hline(0, 15, 15, shade(dk, -0.2)); });
  def('iwall', { solid: 1 }, (s, p, r) => {
    const [b, dk, lt] = p.wall; s.rect(0, 0, 16, 16, b);
    for (let x = 0; x < 16; x += 4) s.vline(x, 0, 9, shade(b, -0.06));
    s.rect(0, 10, 16, 6, p.fl[1]); s.hline(0, 15, 10, p.fl[2]); s.hline(0, 15, 15, shade(p.fl[1], -0.3)); s.hline(0, 15, 0, lt);
  });
  def('iwindow', { solid: 1 }, (s, p) => {
    T.iwall.draw(s, p, () => 0.5);
    s.rect(4, 2, 8, 7, '#2a3a5a'); s.rect(5, 3, 6, 5, '#8ecaf0'); s.vline(8, 3, 7, '#e8f6ff'); s.hline(5, 10, 5, '#e8f6ff'); s.px(5, 3, '#ffffff');
    s.hline(3, 12, 9, p.fl[2]);
  });
  def('floor', { vars: 2 }, (s, p, r) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y += 4) { s.hline(0, 15, y + 3, dk); s.hline(0, 15, y, lt); const sx = (y * 5 + Math.floor(r() * 8)) % 16; s.vline(sx, y, y + 3, dk); }
  });
  def('stonefloor', { vars: 2 }, (s, p, r) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b);
    s.hline(0, 15, 0, lt); s.vline(0, 0, 15, lt); s.hline(0, 15, 15, dk); s.vline(15, 0, 15, dk); s.hline(1, 14, 8, dk); s.hline(1, 14, 9, lt);
    speck(s, r, 8, [dk, lt]);
  });
  def('metalfloor', { vars: 2 }, (s, p, r, f, v) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b);
    s.hline(0, 15, 0, lt); s.vline(0, 0, 15, lt); s.hline(0, 15, 15, dk); s.vline(15, 0, 15, dk);
    for (const [x, y] of [[2, 2], [13, 2], [2, 13], [13, 13]]) { s.px(x, y, lt); s.px(x + 1, y + 1, dk); }
    if (v) for (let i = 4; i < 12; i += 2) s.hline(4, 11, i, dk);
  });
  def('carpet', {}, (s, p) => {
    const c = p.acc; s.rect(0, 0, 16, 16, shade(c, -0.15));
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if ((x + y) % 4 === 0) s.px(x, y, shade(c, -0.3)); else if ((x - y + 16) % 8 === 0) s.px(x, y, shade(c, 0.12));
  });
  def('rug', {}, (s, p) => { s.rect(0, 0, 16, 16, '#3765b0'); s.rect(1, 1, 14, 14, '#2c4f8e'); s.rect(3, 3, 10, 10, '#c9473d'); s.rect(5, 5, 6, 6, '#e2b04a'); s.rect(7, 7, 2, 2, '#efe6d2'); });
  def('doormat', { }, (s, p) => { T.floor.draw(s, p, () => 0.3); s.rect(2, 4, 12, 9, '#7a4a2a'); s.rect(3, 5, 10, 7, '#a0663a'); for (let x = 4; x < 12; x += 2) s.vline(x, 6, 10, '#7a4a2a'); });
  def('bridge', { vars: 1 }, (s, p, r) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y += 4) { s.hline(0, 15, y, lt); s.hline(0, 15, y + 3, dk); if (r() < 0.5) s.px(Math.floor(r() * 14) + 1, y + 1, dk); }
    s.vline(0, 0, 15, shade(dk, -0.2)); s.vline(15, 0, 15, shade(dk, -0.2));
  });
  def('hbridge', {}, (s, p, r) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b);
    for (let x = 0; x < 16; x += 4) { s.vline(x, 0, 15, lt); s.vline(x + 3, 0, 15, dk); }
    s.hline(0, 15, 0, shade(dk, -0.2)); s.hline(0, 15, 15, shade(dk, -0.2));
  });
  def('stairs', {}, (s, p) => {
    const [b, dk, lt] = p.c; s.rect(0, 0, 16, 16, dk);
    for (let y = 0; y < 16; y += 4) { s.rect(1, y, 14, 3, b); s.hline(1, 14, y, lt); }
  });
  def('fence', { solid: 1 }, (s, p, r, f, v) => {
    grassBase(s, p, r, v); const [b, dk] = p.fence;
    s.hline(0, 15, 6, b); s.hline(0, 15, 7, dk); s.hline(0, 15, 10, b); s.hline(0, 15, 11, dk);
    for (const x of [2, 9]) { s.rect(x, 3, 3, 11, b); s.vline(x + 2, 3, 13, dk); s.px(x + 1, 3, shade(b, 0.2)); }
  });
  def('rock', { solid: 1, obj: 1 }, (s, p) => {
    s.ell(8, 9.5, 6.5, 5.5, p.r[0]); s.ell(5, 7, 2, 1.5, shade(p.r[0], 0.18), { flat: 1 });
  });
  def('bush', { solid: 1, obj: 1 }, (s, p) => {
    const [lf, dk, lt] = p.tree;
    s.ell(8, 9.5, 7, 5.5, lf); s.ell(5, 7, 3, 2.5, lt, { flat: 1 }); s.ell(11, 8, 2.5, 2, shade(lf, 0.1), { flat: 1 });
    s.px(6, 10, dk); s.px(10, 11, dk); s.px(8, 12, dk);
  });
  def('stump', { solid: 1, obj: 1 }, (s, p) => { const [, , , tr, td] = p.tree; s.ell(8, 10, 5, 4, tr); s.ell(8, 8, 4.5, 2.5, shade(tr, 0.35), { flat: 1 }); s.ell(8, 8, 2, 1, shade(tr, 0.15), { flat: 1 }); });
  def('crate', { solid: 1, obj: 1 }, (s) => {
    s.rect(2, 3, 12, 12, '#a87a48'); s.rect(2, 3, 12, 2, '#c8985e'); s.rect(2, 13, 12, 2, '#7a5430'); s.line(3, 5, 12, 12, '#7a5430'); s.line(3, 12, 12, 5, '#7a5430'); s.vline(2, 3, 14, '#7a5430'); s.vline(13, 3, 14, '#6a4628');
  });
  def('barrel', { solid: 1, obj: 1 }, (s) => {
    s.ell(8, 9, 5.5, 6.5, '#9a6a3c'); s.hline(3, 13, 5, '#5a5a62'); s.hline(3, 13, 12, '#5a5a62'); s.ell(8, 3.5, 4.5, 1.6, '#c09060', { flat: 1 });
  });
  def('lamp', { solid: 1, obj: 1, glow: '#ffd27a' }, (s, p) => {
    s.rect(7, 4, 2, 11, '#3a3a48'); s.rect(5, 14, 6, 2, '#2a2a36'); s.rect(5, 0, 6, 5, '#2a2a36'); s.rect(6, 1, 4, 3, '#ffe08a'); s.px(6, 1, '#fff6d0');
  });
  def('sign', { solid: 1, obj: 1 }, (s) => { s.rect(7, 8, 2, 7, '#6a4628'); s.rect(2, 3, 12, 7, '#b88a56'); s.rect(3, 4, 10, 5, '#d0a46a'); s.hline(4, 11, 5, '#6a4628'); s.hline(4, 9, 7, '#6a4628'); });
  def('well', { solid: 1, obj: 1 }, (s, p) => {
    s.ell(8, 10, 7, 5, p.c[0]); s.ell(8, 9, 5, 3, '#1a2238', { flat: 1 }); s.rect(2, 1, 2, 9, '#6a4628'); s.rect(12, 1, 2, 9, '#6a4628'); s.rect(1, 0, 14, 2, '#8a3a2e');
  });
  def('pot', { solid: 1, obj: 1 }, (s, p) => { s.ell(8, 10, 5, 5, '#b8683a'); s.rect(5, 3, 6, 3, '#9a5430'); s.ell(8, 3, 3.5, 1.2, '#6a3418', { flat: 1 }); s.px(5, 4, p.g[2]); s.px(9, 2, p.g[2]); s.px(7, 1, p.g[0]); });
  def('counter', { solid: 1 }, (s, p) => { const [b, dk, lt] = p.fl; s.rect(0, 2, 16, 14, dk); s.rect(0, 2, 16, 4, lt); s.hline(0, 15, 6, shade(dk, -0.2)); for (let x = 2; x < 16; x += 5) s.vline(x, 8, 15, shade(dk, -0.15)); });
  def('table', { solid: 1, obj: 1 }, (s, p) => { s.rect(1, 4, 14, 8, '#a0703e'); s.rect(1, 4, 14, 2, '#c08a52'); s.rect(2, 12, 2, 4, '#6a4628'); s.rect(12, 12, 2, 4, '#6a4628'); s.rect(5, 5, 3, 2, '#efe6d2'); s.px(10, 5, '#c9473d'); });
  def('chair', { solid: 1, obj: 1 }, (s) => { s.rect(4, 2, 8, 8, '#8a5a36'); s.rect(5, 3, 6, 6, '#a6744a'); s.rect(4, 10, 8, 2, '#6e4428'); s.rect(4, 12, 2, 4, '#5a3620'); s.rect(10, 12, 2, 4, '#5a3620'); });
  def('bedtop', { solid: 1, obj: 1 }, (s) => { s.rect(1, 2, 14, 14, '#6e4428'); s.rect(2, 4, 12, 12, '#e8e2d2'); s.rect(3, 5, 10, 5, '#ffffff'); s.hline(3, 12, 10, '#c8c0b0'); });
  def('bedbot', { solid: 1, obj: 1 }, (s) => { s.rect(1, 0, 14, 14, '#6e4428'); s.rect(2, 0, 12, 12, '#3765b0'); for (let y = 2; y < 12; y += 3) s.hline(2, 13, y, '#2c4f8e'); s.rect(1, 14, 14, 2, '#5a3620'); });
  def('shelf', { solid: 1 }, (s, p) => {
    s.rect(0, 0, 16, 16, '#6e4428'); s.rect(1, 1, 14, 14, '#4a2c18');
    const cols = ['#c9473d', '#3765b0', '#e2b04a', '#5f9e47', '#efe6d2', '#8a5aa0'];
    for (const y of [1, 6, 11]) { let x = 1; while (x < 15) { const w = 1 + (x * 7 + y) % 2, c = cols[(x * 3 + y) % cols.length]; s.rect(x, y + 1, w, 4, c); s.px(x, y + 1, shade(c, 0.3)); x += w + ((x + y) % 5 === 0 ? 1 : 0); } s.hline(1, 14, y + 5, '#8a5a36'); }
  });
  def('desk', { solid: 1, obj: 1 }, (s) => { s.rect(0, 5, 16, 8, '#7a4a2a'); s.rect(0, 5, 16, 2, '#9a6a3c'); s.rect(1, 13, 2, 3, '#5a3620'); s.rect(13, 13, 2, 3, '#5a3620'); s.rect(3, 3, 6, 3, '#efe6d2'); s.rect(4, 2, 5, 1, '#efe6d2'); s.px(11, 3, '#3a3a48'); s.vline(11, 1, 4, '#3a3a48'); s.px(12, 2, '#ffd27a'); });
  def('lensbench', { solid: 1, obj: 1 }, (s) => { s.rect(0, 6, 16, 7, '#6a5040'); s.rect(0, 6, 16, 2, '#8a6a50'); s.ell(5, 4, 3, 3, '#9ad8f0'); s.px(4, 3, '#ffffff'); s.ell(11, 5, 2, 2, '#c8eefc'); s.rect(13, 1, 1, 5, '#e2b04a'); s.rect(1, 13, 2, 3, '#4a3428'); s.rect(13, 13, 2, 3, '#4a3428'); });
  def('letters', { solid: 1, obj: 1, vars: 3 }, (s, p, r) => {
    const cols = ['#efe6d2', '#e8dcc0', '#f6f0e4', '#d8ccb0'];
    for (let i = 0; i < 9; i++) { const x = 1 + Math.floor(r() * 10), y = 3 + Math.floor(r() * 9), c = cols[i % 4]; s.rect(x, y, 6, 4, c); s.line(x, y, x + 3, y + 2, shade(c, -0.25)); s.line(x + 5, y, x + 3, y + 2, shade(c, -0.25)); if (r() < 0.4) s.px(x + 4, y + 1, i % 2 ? '#c9473d' : '#3765b0'); }
  });
  def('mailbox', { solid: 1, obj: 1 }, (s) => { s.rect(4, 3, 8, 10, '#3765b0'); s.ell(8, 3.5, 4, 2.5, '#4a7cc8'); s.rect(5, 6, 6, 1, '#16203a'); s.rect(7, 13, 2, 3, '#2a3048'); s.rect(4, 9, 8, 1, '#2c4f8e'); });
  def('pipe', { solid: 1 }, (s, p) => { s.rect(0, 0, 16, 16, p.wall[1]); s.rect(3, 0, 10, 16, '#6e767e'); s.vline(4, 0, 15, '#a8b0b8'); s.vline(12, 0, 15, '#4a5058'); s.rect(2, 6, 12, 3, '#5a6268'); s.hline(2, 13, 6, '#8a9298'); });
  def('grate', {}, (s, p) => { s.rect(0, 0, 16, 16, p.fl[1]); for (let x = 1; x < 16; x += 3) s.vline(x, 1, 14, '#2a3036'); s.hline(0, 15, 0, p.fl[2]); s.hline(0, 15, 15, '#2a3036'); });
  def('rubble', { solid: 1, obj: 1, vars: 2 }, (s, p, r) => {
    for (let i = 0; i < 5; i++) { const x = 3 + r() * 10, y = 6 + r() * 7, rx = 2 + r() * 3; s.ell(x, y, rx, rx * 0.8, i % 2 ? p.c[0] : p.r[0]); }
    s.line(2, 14, 6, 10, p.c[3]); s.rect(9, 3, 2, 6, '#5a5450');
  });
  def('puddle', { vars: 2 }, (s, p, r, f, v) => { T.cobble.draw(s, p, r); s.ell(8, 9, 6, 3.5, p.w[0], { flat: 1 }); s.hline(5, 9, 8, p.w[2]); s.px(10, 10, p.w[3]); });
  def('ice', {}, (s, p) => { s.rect(0, 0, 16, 16, '#bfe2f2'); s.line(0, 15, 15, 0, '#e8f8ff'); s.line(3, 15, 15, 3, '#ffffff'); s.hline(0, 15, 15, '#9ccce2'); });
  def('ember', { frames: 4, glow: '#ff7a2a' }, (s, p, r, f, v, x, y) => {
    const [b, dk, lt] = p.d; s.rect(0, 0, 16, 16, b); speck(s, r, 18, [dk, lt]);
    const cracks = [[2, 3, 7, 6], [7, 6, 12, 4], [7, 6, 9, 12], [9, 12, 14, 14]];
    const glow = ['#ff8a2a', '#ffb040', '#ffd060', '#ffb040'][(f + x + y) % 4];
    for (const [a, b2, c, d] of cracks) s.line(a, b2, c, d, glow);
  });
  def('mushroom', { solid: 1, obj: 1, glow: '#7af0d0' }, (s) => { s.rect(7, 8, 2, 7, '#e8dcc0'); s.ell(8, 7, 6, 3.5, '#4ad0b0'); s.px(5, 6, '#c8fff0'); s.px(10, 6, '#c8fff0'); s.ell(13, 12, 2, 1.5, '#4ad0b0'); s.vline(13, 13, 15, '#e8dcc0'); });
  def('crystal', { solid: 1, obj: 1, glow: '#9ad0ff' }, (s) => { s.poly([[8, 1], [12, 7], [10, 15], [6, 15], [4, 7]], '#7ab8ff', { side: 1 }); s.poly([[3, 8], [5, 11], [4, 15], [2, 15], [1, 11]], '#a8d4ff', { side: 1 }); s.vline(8, 3, 12, '#e8f6ff'); });
  def('gearfloor', { frames: 4 }, (s, p, r, f) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b); s.hline(0, 15, 0, lt); s.vline(0, 0, 15, lt); s.hline(0, 15, 15, dk); s.vline(15, 0, 15, dk);
    const a0 = f * Math.PI / 8;
    for (let k = 0; k < 8; k++) { const a = a0 + k * Math.PI / 4; s.rect(Math.round(8 + Math.cos(a) * 5) - 1, Math.round(8 + Math.sin(a) * 5) - 1, 2, 2, p.acc); }
    s.ell(8, 8, 4, 4, shade(p.acc, -0.1)); s.ell(8, 8, 1.5, 1.5, dk, { flat: 1 });
  });
  def('cloud', { vars: 3 }, (s, p, r) => {
    s.rect(0, 0, 16, 16, '#f6f8ff');
    for (let i = 0; i < 4; i++) { const x = r() * 16, y = r() * 16; s.ell(x, y, 3 + r() * 3, 2 + r() * 2, '#ffffff', { flat: 1 }); }
    for (let j = 0; j < 16; j++) for (let i = 0; i < 16; i++) if (bayer(i, j) < 0.12 && (i * 3 + j) % 5 === 0) s.px(i, j, '#dde6f8');
  });
  def('skyvoid', { solid: 1, frames: 1 }, (s, p, r, f, v, x, y) => {
    const t = (y % 8) / 8; s.rect(0, 0, 16, 16, mix('#8cc4f0', '#c6e4fa', t));
    if ((x * 7 + y * 13) % 11 === 0) s.ell(8, 8, 5, 2, '#ffffff', { flat: 1 });
  });
  def('cloudedge', { solid: 1 }, (s, p, r) => {
    s.rect(0, 0, 16, 16, '#9ccaf0');
    for (let i = 0; i < 5; i++) s.ell(i * 4, 3 + r() * 2, 4, 3.5, '#ffffff', { flat: 1 });
    s.hline(0, 15, 8, '#dde6f8');
  });
  def('goldfloor', { vars: 2 }, (s, p, r, f, v) => {
    const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, b); s.rect(0, 0, 16, 1, lt); s.rect(0, 0, 1, 16, lt); s.hline(0, 15, 15, dk); s.vline(15, 0, 15, dk);
    if (v) { s.ell(8, 8, 4, 4, lt); s.ell(8, 8, 2, 2, b, { flat: 1 }); } else { s.line(3, 3, 12, 12, dk); s.line(3, 12, 12, 3, dk); }
  });
  def('pillar', { solid: 1, obj: 1 }, (s, p) => { const [b, dk, lt] = p.wall; s.rect(4, 0, 8, 16, b); s.vline(5, 0, 15, lt); s.vline(11, 0, 15, dk); s.rect(3, 0, 10, 2, lt); s.rect(3, 14, 10, 2, dk); });
  def('seafloor', { vars: 3 }, (s, p, r) => {
    const [b, dk, lt] = p.s; s.rect(0, 0, 16, 16, b);
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const n = r(); if (n < 0.08) s.px(x, y, dk); else if (n < 0.13) s.px(x, y, lt); }
    if (r() < 0.5) { const x = Math.floor(r() * 12) + 2, y = Math.floor(r() * 12) + 2; s.px(x, y, '#e8e0c8'); s.px(x + 1, y, '#c8b8a0'); }
  });
  def('coral', { solid: 1, obj: 1, vars: 2 }, (s, p, r, f, v) => {
    const c = p.flower[v % 4];
    s.vline(8, 4, 15, c); s.line(8, 10, 3, 5, c); s.line(8, 8, 13, 3, c); s.line(4, 6, 2, 2, c); s.line(12, 4, 14, 1, c);
    s.vline(9, 5, 15, shade(c, -0.25)); s.px(3, 5, shade(c, 0.3)); s.px(13, 3, shade(c, 0.3));
  });
  def('seaweed', { frames: 4, vars: 2 }, (s, p, r, f, v) => {
    T.seafloor.draw(s, p, r); const c = p.tree[0];
    for (const bx of [4, 10]) for (let y = 2; y < 16; y++) { const x = bx + Math.round(Math.sin(y * 0.6 + f * 0.8 + bx) * 1.2); s.px(x, y, y % 3 ? c : shade(c, 0.2)); }
  });
  def('brass', { solid: 1 }, (s, p) => {
    const [b, dk, lt] = p.wall; s.rect(0, 0, 16, 16, b); s.hline(0, 15, 0, lt); s.hline(0, 15, 15, dk); s.vline(0, 0, 15, lt); s.vline(15, 0, 15, dk);
    for (const [x, y] of [[2, 2], [13, 2], [2, 13], [13, 13]]) { s.px(x, y, lt); s.px(x + 1, y + 1, dk); }
    s.ell(8, 8, 4, 4, shade(b, -0.12)); s.ell(8, 8, 2, 2, lt, { flat: 1 });
  });
  def('void', { solid: 1 }, (s) => { s.rect(0, 0, 16, 16, '#05060c'); });
  def('forest', { solid: 1, vars: 3 }, (s, p, r) => {
    const [lf, dk, lt] = p.tree; s.rect(0, 0, 16, 16, shade(dk, -0.25));
    for (let i = 0; i < 6; i++) { const x = r() * 16, y = r() * 16; s.ell(x, y, 4 + r() * 3, 3.5 + r() * 2, i % 2 ? lf : dk); }
    for (let i = 0; i < 4; i++) { const x = Math.floor(r() * 14), y = Math.floor(r() * 14); s.px(x, y, lt); s.px(x + 1, y, lt); }
  });
  def('statueplinth', { solid: 1, obj: 1 }, (s, p) => { s.rect(2, 8, 12, 8, p.c[0]); s.hline(2, 13, 8, p.c[2]); s.hline(2, 13, 15, p.c[1]); s.rect(4, 0, 8, 9, p.c[1]); s.ell(8, 3, 3, 3, p.c[2]); });
  def('stall', { solid: 1 }, (s, p) => { const [b, dk, lt] = p.fl; s.rect(0, 0, 16, 16, dk); s.rect(0, 0, 16, 5, lt); s.hline(0, 15, 5, shade(dk, -0.3)); s.rect(2, 1, 4, 3, '#e2b04a'); s.rect(9, 1, 5, 3, '#c9473d'); });
  def('festivalcobble', { vars: 4 }, (s, p, r) => { T.cobble.draw(s, p, r); });

  G.TILEDEF = T;
  const cache = new Map();
  G.tiles = {
    get(theme, name, x = 0, y = 0, frame = 0) {
      const t = T[name]; if (!t) return null;
      const v = t.vars ? ((x * 73856093 ^ y * 19349663) >>> 0) % t.vars : 0;
      const fr = t.frames ? frame % t.frames : 0;
      const key = theme + ':' + name + ':' + v + ':' + fr + (t.water || t.frames ? ':' + (x % 4) + ',' + (y % 4) : '');
      let c = cache.get(key);
      if (!c) {
        const s = new Spr(16, 16), r = G.rng(((v + 1) * 2654435761 ^ name.length * 97 ^ (t.water ? x * 31 + y * 17 : 0)) >>> 0);
        t.draw(s, PAL[theme] || PAL.hasune, r, fr, v, x % 4, y % 4);
        c = s.canvas(); cache.set(key, c);
      }
      return c;
    },
    def(name) { return T[name]; },
  };
})();
