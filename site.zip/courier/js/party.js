'use strict';
// Party, inventory and stats
(function () {
  const D = G.DATA;
  const START_EQ = {
    haru: { weapon: 'w_wood', armor: 'b_clothes', helm: 'h_cap', acc: null },
    mio: { weapon: 't_wood', armor: 'b_clothes', helm: null, acc: null },
    sena: { weapon: 'l_knight', armor: 'b_chain', helm: 'h_iron', acc: null },
    pip: { weapon: 'a_post', armor: 'b_leather', helm: null, acc: null },
  };
  G.newParty = function () {
    G.party = { active: [], members: {}, items: {}, gold: 60, letters: {}, delivered: {}, time: 0, steps: 0, battles: 0 };
  };
  G.expAt = lv => { let t = 0; for (let l = 1; l < lv; l++) t += D.expNeed(l); return t; };
  G.addMember = function (id, lv = 1, active = true) {
    const P = G.party; if (P.members[id]) { if (active && !P.active.includes(id) && P.active.length < 3) P.active.push(id); return P.members[id]; }
    const m = { id, lv, exp: G.expAt(lv), hp: 1, mp: 1, eq: Object.assign({}, START_EQ[id]), st: {} };
    P.members[id] = m;
    const s = G.stats(id); m.hp = s.maxhp; m.mp = s.maxmp;
    if (active && P.active.length < 3) P.active.push(id);
    G.field && G.field.syncParty && G.field.map && G.field.syncParty();
    return m;
  };
  G.removeActive = id => { const P = G.party; P.active = P.active.filter(x => x !== id); G.field.syncParty(); };
  G.baseStats = function (id, lv) {
    const d = D.PARTY[id], b = d.base, g = d.grow, L = lv - 1;
    return {
      maxhp: Math.floor(b.hp + g.hp * L), maxmp: Math.floor(b.mp + g.mp * L), pow: Math.floor(b.pow + g.pow * L), mag: Math.floor(b.mag + g.mag * L),
      def: Math.floor(b.def + g.def * L), mdef: Math.floor(b.mdef + g.mdef * L), spd: Math.floor(b.spd + g.spd * L), hit: b.hit, eva: b.eva,
    };
  };
  G.stats = function (id, eqOverride) {
    const m = G.party.members[id]; const s = G.baseStats(id, m.lv);
    s.watk = 0; s.wmag = 0; s.immune = [];
    const eq = eqOverride || m.eq;
    for (const slot of ['weapon', 'armor', 'helm', 'acc']) {
      const it = eq[slot] && D.ITEMS[eq[slot]]; if (!it) continue;
      if (slot === 'weapon') { s.watk += it.atk || 0; s.wmag += it.mag || 0; }
      else { s.def += it.def || 0; s.mdef += it.mdef || 0; s.mag += it.mag || 0; if (slot === 'helm') s.spd += it.spd || 0; }
      if (slot === 'acc' || slot === 'weapon') { s.pow += it.pow || 0; if (slot === 'acc') s.mag += 0; s.spd += it.spd || 0; }
      if (it.immune) s.immune.push(...it.immune);
    }
    if (eq.acc) { const a = D.ITEMS[eq.acc]; if (a && a.mag && false) s.mag += a.mag; }
    s.atk = Math.round(s.pow * 1.6 + s.watk * 1.8);
    s.matk = s.mag + s.wmag;
    return s;
  };
  G.canEquip = (id, itemId) => {
    const it = D.ITEMS[itemId]; if (!it) return false;
    if (it.kind === 'weapon') return it.wtype === D.PARTY[id].wtype;
    if (it.who) return it.who.includes(id);
    return ['armor', 'helm', 'acc'].includes(it.kind);
  };
  G.slotOf = it => ({ weapon: 'weapon', armor: 'armor', helm: 'helm', acc: 'acc' })[it.kind];
  G.equip = function (id, itemId, slot) {
    const m = G.party.members[id];
    const old = m.eq[slot]; if (old) G.addItem(old, 1);
    if (itemId) { G.removeItem(itemId, 1); }
    m.eq[slot] = itemId || null;
    const s = G.stats(id); m.hp = Math.min(m.hp, s.maxhp); m.mp = Math.min(m.mp, s.maxmp);
  };
  // pick the strongest gear for one member from what the party owns
  G.autoEquip = function (id) {
    const role = { haru: [1.4, 0.4], mio: [0.4, 1.5], sena: [1.4, 0.3], pip: [0.9, 1.0] }[id] || [1, 1];
    const score = eq => { const st = G.stats(id, eq); return st.atk * role[0] + st.matk * role[1] * 1.6 + st.def * 1.1 + st.mdef + st.spd * 4 + (st.immune.length * 6); };
    const m = G.party.members[id]; let changed = 0;
    for (const slot of ['weapon', 'armor', 'helm', 'acc']) {
      let best = m.eq[slot], bs = score(m.eq);
      for (const k of Object.keys(G.party.items)) {
        const it = D.ITEMS[k]; if (!it || G.slotOf(it) !== slot || !G.canEquip(id, k) || G.count(k) < 1) continue;
        const sc = score(Object.assign({}, m.eq, { [slot]: k })); if (sc > bs + 0.01) { bs = sc; best = k; }
      }
      if (best !== m.eq[slot]) { G.equip(id, best, slot); changed++; }
    }
    return changed;
  };
  G.addItem = (id, n = 1) => { const it = G.party.items; it[id] = (it[id] || 0) + n; if (it[id] > 99 && D.ITEMS[id] && D.ITEMS[id].kind !== 'key') it[id] = 99; if (it[id] <= 0) delete it[id]; };
  G.removeItem = (id, n = 1) => G.addItem(id, -n);
  G.hasItem = id => (G.party.items[id] || 0) > 0;
  G.count = id => G.party.items[id] || 0;
  G.techsOf = id => { const m = G.party.members[id]; return Object.entries(D.TECHS).filter(([k, t]) => t.user === id && t.lv <= m.lv).map(([k, t]) => Object.assign({ id: k }, t)); };
  G.hasTech = (id, tid) => { const t = D.TECHS[tid]; return t && t.user === id && G.party.members[id] && G.party.members[id].lv >= t.lv; };
  G.combosFor = (ids) => Object.entries(D.COMBOS).filter(([k, c]) => c.users.every(u => ids.includes(u)) && c.need.every((t, i) => G.hasTech(D.TECHS[t].user, t))).map(([k, c]) => Object.assign({ id: k }, c));
  G.knownCombos = () => Object.entries(D.COMBOS).filter(([k, c]) => c.users.every(u => G.party.members[u]) && c.need.every(t => G.hasTech(D.TECHS[t].user, t))).map(([k, c]) => Object.assign({ id: k }, c));
  // add experience to all active, living members; returns [{id, lv, techs:[names]}]
  G.gainExp = function (amount, ids) {
    const ups = [];
    // benched members travel with the party and learn alongside them
    const bench = Object.keys(G.party.members).filter(id => !G.party.active.includes(id));
    for (const id of (ids || G.party.active).concat(bench)) {
      const m = G.party.members[id]; if (!m) continue;
      const before = G.knownCombos().map(c => c.id);
      m.exp += amount;
      let lv0 = m.lv;
      while (m.lv < 50 && m.exp >= G.expAt(m.lv + 1)) {
        const s0 = G.stats(id); m.lv++; const s1 = G.stats(id);
        m.hp += s1.maxhp - s0.maxhp; m.mp += s1.maxmp - s0.maxmp;
      }
      if (m.lv > lv0) {
        const techs = Object.values(D.TECHS).filter(t => t.user === id && t.lv > lv0 && t.lv <= m.lv).map(t => t.name);
        const combos = G.knownCombos().filter(c => !before.includes(c.id)).map(c => c.name);
        ups.push({ id, lv: m.lv, techs, combos });
      }
    }
    return ups;
  };
  G.healAll = () => { for (const id in G.party.members) { const m = G.party.members[id], s = G.stats(id); m.hp = s.maxhp; m.mp = s.maxmp; m.st = {}; } };
  G.memberName = id => (D.PARTY[id] || {}).name || id;
  G.lettersHeld = () => Object.keys(G.party.letters).filter(k => G.party.letters[k] && !G.party.delivered[k]);
  G.deliveredCount = () => Object.keys(G.party.delivered).filter(k => G.party.delivered[k]).length;
})();
