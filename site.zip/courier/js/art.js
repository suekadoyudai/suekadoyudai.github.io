'use strict';
// Pixel-art raster toolkit. Everything visual in the game is drawn by code at 1x and scaled 2x.
(function () {
  const hexCache = new Map();
  function rgb(hex) {
    let v = hexCache.get(hex); if (v) return v;
    let h = hex.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join('');
    v = [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
    hexCache.set(hex, v); return v;
  }
  const hex = (r, g, b) => '#' + [r, g, b].map(x => G.clamp(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
  function mix(a, b, t) { const A = rgb(a), B = rgb(b); return hex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t); }
  function shade(c, amt) { if (!c) { console.error('shade undefined', new Error().stack.split('\n')[2]); return '#ff00ff'; } return amt >= 0 ? mix(c, '#fff8e8', amt) : mix(c, '#140c24', -amt); }
  const pack = c => { const [r, g, b] = rgb(c); return (255 << 24 | b << 16 | g << 8 | r) >>> 0; };
  const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map(v => (v + 0.5) / 16);
  const bayer = (x, y) => BAYER[(y & 3) * 4 + (x & 3)];

  class Spr {
    constructor(w, h) { this.w = w; this.h = h; this.d = new Uint32Array(w * h); }
    px(x, y, c) { x |= 0; y |= 0; if (x < 0 || y < 0 || x >= this.w || y >= this.h) return; this.d[y * this.w + x] = c ? pack(c) : 0; }
    get(x, y) { if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0; return this.d[y * this.w + x]; }
    rect(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.px(x + i, y + j, c); return this; }
    hline(x0, x1, y, c) { for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) this.px(x, y, c); }
    vline(x, y0, y1, c) { for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) this.px(x, y, c); }
    line(x0, y0, x1, y1, c) {
      x0 |= 0; y0 |= 0; x1 |= 0; y1 |= 0;
      const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let e = dx + dy;
      for (; ;) { this.px(x0, y0, c); if (x0 === x1 && y0 === y1) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } }
    }
    // ellipse with 3-tone lighting from the upper left and ordered-dither transitions
    ell(cx, cy, rx, ry, col, opt = {}) {
      const lit = opt.lit != null ? opt.lit : 0.32, dark = opt.dark != null ? opt.dark : -0.32, flat = opt.flat;
      const L = opt.light || [-0.55, -0.75];
      const cHi = flat ? col : shade(col, lit), cLo = flat ? col : shade(col, dark);
      for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++) for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const nx = (x + 0.5 - cx) / rx, ny = (y + 0.5 - cy) / ry, r2 = nx * nx + ny * ny;
        if (r2 > 1) continue;
        if (flat) { this.px(x, y, col); continue; }
        const nz = Math.sqrt(Math.max(0, 1 - r2));
        const ln = Math.hypot(L[0], L[1], 0.6);
        const dot = (nx * L[0] + ny * L[1] + nz * 0.6) / ln;
        const b = bayer(x, y) * 0.22 - 0.11;
        const v = dot + b;
        this.px(x, y, v > 0.78 ? cHi : v < 0.28 ? cLo : col);
      }
      return this;
    }
    // filled polygon (scanline), optional vertical gradient shading
    poly(pts, col, opt = {}) {
      let minY = Infinity, maxY = -Infinity; for (const p of pts) { minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]); }
      const cHi = shade(col, 0.28), cLo = shade(col, -0.3);
      for (let y = Math.floor(minY); y <= Math.ceil(maxY); y++) {
        const xs = [];
        for (let i = 0; i < pts.length; i++) {
          const a = pts[i], b = pts[(i + 1) % pts.length];
          if ((a[1] <= y + 0.5 && b[1] > y + 0.5) || (b[1] <= y + 0.5 && a[1] > y + 0.5)) xs.push(a[0] + (y + 0.5 - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
        }
        xs.sort((a, b) => a - b);
        for (let k = 0; k + 1 < xs.length; k += 2) for (let x = Math.round(xs[k]); x < Math.round(xs[k + 1]); x++) {
          let c = col;
          if (opt.grad) { const t = (y - minY) / Math.max(1, maxY - minY) + bayer(x, y) * 0.2 - 0.1; c = t < 0.25 ? cHi : t > 0.72 ? cLo : col; }
          if (opt.side) { const t = (x - xs[k]) / Math.max(1, xs[k + 1] - xs[k]) + bayer(x, y) * 0.2 - 0.1; c = t < 0.25 ? cHi : t > 0.75 ? cLo : col; }
          this.px(x, y, c);
        }
      }
      return this;
    }
    // shade an existing region: darken pixels on the lower-right edge of each opaque run
    rim(dark = '#000', amt = 0.25) {
      const out = new Uint32Array(this.d);
      for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
        const v = this.get(x, y); if (!v) continue;
        if (!this.get(x + 1, y) || !this.get(x, y + 1)) {
          const r = v & 255, g = (v >> 8) & 255, b = (v >> 16) & 255;
          out[y * this.w + x] = pack(mix(hex(r, g, b), dark, amt));
        }
      }
      this.d = out; return this;
    }
    // automatic 1px outline around every opaque shape
    outline(c = '#1b1229', diag = false) {
      const o = pack(c), out = new Uint32Array(this.d);
      for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
        if (this.get(x, y)) continue;
        if (this.get(x - 1, y) || this.get(x + 1, y) || this.get(x, y - 1) || this.get(x, y + 1) ||
          (diag && (this.get(x - 1, y - 1) || this.get(x + 1, y - 1) || this.get(x - 1, y + 1) || this.get(x + 1, y + 1)))) out[y * this.w + x] = o;
      }
      this.d = out; return this;
    }
    // inner outline: color pixels that border a different color group darker (selective outline)
    stamp(src, ox, oy) { for (let y = 0; y < src.h; y++) for (let x = 0; x < src.w; x++) { const v = src.d[y * src.w + x]; if (v) { const X = ox + x, Y = oy + y; if (X >= 0 && Y >= 0 && X < this.w && Y < this.h) this.d[Y * this.w + X] = v; } } return this; }
    canvas() {
      const c = document.createElement('canvas'); c.width = this.w; c.height = this.h;
      const g = c.getContext('2d'), im = g.createImageData(this.w, this.h);
      new Uint32Array(im.data.buffer).set(this.d); g.putImageData(im, 0, 0);
      return c;
    }
    // parse a string template: rows of chars mapped through a palette
    tpl(rows, pal, ox = 0, oy = 0) {
      rows.forEach((row, y) => { for (let x = 0; x < row.length; x++) { const ch = row[x]; if (ch === '.' || ch === ' ') continue; const c = pal[ch]; if (c) this.px(ox + x, oy + y, c); } });
      return this;
    }
  }

  function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.imageSmoothingEnabled = false; return [c, g]; }
  function flipH(src) { const [c, g] = canvas(src.width, src.height); g.translate(src.width, 0); g.scale(-1, 1); g.drawImage(src, 0, 0); return c; }
  function recolor(src, fn) {
    const [c, g] = canvas(src.width, src.height); g.drawImage(src, 0, 0);
    const im = g.getImageData(0, 0, c.width, c.height), d = im.data;
    for (let i = 0; i < d.length; i += 4) { if (!d[i + 3]) continue; const r = fn(d[i], d[i + 1], d[i + 2]); d[i] = r[0]; d[i + 1] = r[1]; d[i + 2] = r[2]; }
    g.putImageData(im, 0, 0); return c;
  }
  const silhouette = (src, col) => { const [r, gg, b] = rgb(col); return recolor(src, () => [r, gg, b]); };
  const statue = (src, tint = '#9fb4c8') => { const T = rgb(tint); return recolor(src, (r, g, b) => { const l = (r * 0.3 + g * 0.59 + b * 0.11) / 255; return [T[0] * (0.35 + l * 0.8), T[1] * (0.35 + l * 0.8), T[2] * (0.35 + l * 0.85)]; }); };
  const rotate90 = src => { const [c, g] = canvas(src.height, src.width); g.translate(src.height, 0); g.rotate(Math.PI / 2); g.drawImage(src, 0, 0); return c; };

  G.art = { Spr, rgb, hex, mix, shade, bayer, canvas, flipH, recolor, silhouette, statue, rotate90, pack };
})();
