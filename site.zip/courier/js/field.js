'use strict';
// Field: maps, movement, interaction, lighting
(function () {
  const { Spr, shade, mix, canvas } = G.art;
  const F = G.field = { map: null, actors: [], cam: { x: 0, y: 0 }, trail: [], banner: null, particles: [], decor: [], lock: 0 };
  const DIRS = { down: [0, 1], up: [0, -1], left: [-1, 0], right: [1, 0] };
  F.DIRS = DIRS;

  // ---------- conditions ----------
  G.cond = s => {
    if (!s) return true;
    return s.split('&').every(t => {
      t = t.trim(); const neg = t[0] === '!'; if (neg) t = t.slice(1);
      const m = /^(\w+)\s*(>=|<=|>|<|==)\s*(-?\d+)$/.exec(t); let v;
      if (m) { const a = +(G.flags[m[1]] || 0), b = +m[3]; v = m[2] === '>=' ? a >= b : m[2] === '<=' ? a <= b : m[2] === '>' ? a > b : m[2] === '<' ? a < b : a === b; }
      else v = !!G.flags[t];
      return neg ? !v : v;
    });
  };

  // ---------- stamps: collision ----------
  function stampCollision(st, solid, walk) {
    const S = (x, y) => { if (solid[y] && x >= 0 && x < solid[y].length) solid[y][x] = 1; };
    if (st.type === 'house') {
      for (let j = 0; j < st.h; j++) for (let i = 0; i < st.w; i++) S(st.x + i, st.y + j);
      if (st.door != null) walk.push([st.x + st.door, st.y + st.h - 1]);
    } else if (st.type === 'stall') { for (let i = 0; i < st.w; i++) { S(st.x + i, st.y); S(st.x + i, st.y + 1); } }
    else if (st.type === 'fountain') { for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) S(st.x + i, st.y + j); }
    else if (st.type === 'lighthouse' || st.type === 'beacon') { for (let j = 1; j < 5; j++) for (let i = 0; i < 3; i++) S(st.x + i, st.y + j); if (st.type === 'lighthouse') walk.push([st.x + 1, st.y + 4]); }
    else if (st.type === 'tent') { for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) S(st.x + i, st.y + j); }
    else if (st.type === 'fencerow') { for (let x = st.x0; x <= st.x1; x++) S(x, st.y); }
    else if (st.type === 'biglens') { for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) S(st.x + i, st.y + j); }
    else if (st.type === 'biggear') { for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) S(st.x + i, st.y + j); }
  }
  F.buildCollision = function (def) {
    const h = def.grid.length, w = def.grid[0].length;
    const solid = [], names = [];
    for (let y = 0; y < h; y++) {
      solid.push([]); names.push([]);
      for (let x = 0; x < w; x++) {
        const ch = def.grid[y][x]; let n = G.LEG[ch] || (ch === ' ' ? 'void' : 'grass');
        const t = G.TILEDEF[n === 'tree' ? 'grass' : n];
        names[y].push(n);
        solid[y].push((n === 'tree' || (t && t.solid)) ? 1 : 0);
      }
    }
    const walk = [];
    for (const st of def.stamps || []) stampCollision(st, solid, walk);
    for (const [x, y] of walk) if (solid[y]) solid[y][x] = 0;
    // warps are always walkable
    for (const wp of def.warps || []) for (let j = 0; j < (wp.h || 1); j++) for (let i = 0; i < (wp.w || 1); i++) if (solid[wp.y + j]) solid[wp.y + j][wp.x + i] = 0;
    return { w, h, solid, names };
  };

  // ---------- stamp drawing ----------
  const ROOF = { red: '#b5503f', teal: '#3e8f8a', brown: '#8a5a36', slate: '#4a5a7a', stone: '#8d887f', thatch: '#c8a050', gold: '#e2b04a', white: '#f2eee4', ruin: '#6a6e74', tower: '#5a6470' };
  const WALL = { plaster: ['#efe4cb', '#d5c6a6'], wood: ['#a07048', '#7a5434'], stone: ['#b0a898', '#8a8274'], marble: ['#f6f0e4', '#d8ccb0'], metal: ['#8a929c', '#646c76'], ruin: ['#a8a29a', '#7e786e'] };
  function drawHouse(st, theme) {
    const W = st.w * 16, Hh = st.h * 16, s = new Spr(W, Hh);
    const wallRows = st.tall ? 3 : 2, roofH = (st.h - wallRows) * 16 + 6;
    const wk = st.wall || (theme === 'sky' ? 'marble' : theme === 'future' ? 'ruin' : 'plaster');
    const [wc, wd] = WALL[wk];
    // walls
    const wy = roofH - 6;
    s.rect(0, wy, W, Hh - wy, wc);
    if (wk === 'wood') for (let y = wy; y < Hh; y += 4) { s.hline(0, W - 1, y, wd); }
    else if (wk === 'stone' || wk === 'ruin') for (let y = wy; y < Hh; y += 5) { s.hline(0, W - 1, y, wd); for (let x = (y / 5 % 2) * 6; x < W; x += 12) s.vline(x, y, y + 4, wd); }
    else if (wk === 'metal') for (let x = 0; x < W; x += 8) { s.vline(x, wy, Hh - 1, wd); s.vline(x + 1, wy, Hh - 1, shade(wc, 0.2)); }
    else { for (let x = 0; x < W; x += 16) s.vline(x, wy, Hh - 1, shade(wc, -0.06)); }
    s.hline(0, W - 1, Hh - 1, shade(wd, -0.3)); s.hline(0, W - 1, Hh - 2, wd);
    s.rect(0, wy, 2, Hh - wy, shade(wc, 0.1)); s.rect(W - 2, wy, 2, Hh - wy, wd);
    // windows
    const doorX = st.door != null ? st.door * 16 : -99;
    const winY = Hh - 26;
    st._windows = [];
    for (let tx = 0; tx < st.w; tx++) {
      const x = tx * 16 + 3;
      if (Math.abs(tx * 16 - doorX) < 16 || tx === 0 && st.w > 4 || (tx === st.w - 1 && st.w > 4)) continue;
      if (tx % 2 === (st.door % 2) && st.w > 3) continue;
      if (st.roof === 'ruin') { s.rect(x, winY, 10, 9, '#1a1a22'); s.line(x, winY + 8, x + 9, winY, wd); continue; }
      s.rect(x - 1, winY - 1, 12, 11, shade(wd, -0.35)); s.rect(x, winY, 10, 9, '#3a5a80'); s.rect(x, winY, 10, 2, '#5a88b8'); s.vline(x + 5, winY, winY + 8, shade(wd, -0.2)); s.hline(x, x + 9, winY + 4, shade(wd, -0.2)); s.px(x + 1, winY + 1, '#d8eefc');
      s.rect(x - 1, winY + 9, 12, 2, shade(wc, 0.15));
      if (theme !== 'future') { s.rect(x, winY + 11, 10, 2, '#8a5a36'); s.px(x + 2, winY + 10, '#f08aa0'); s.px(x + 6, winY + 10, '#f2e05c'); }
      st._windows.push([st.x * 16 + x + 5, st.y * 16 + winY + 4]);
    }
    // door
    if (st.door != null) {
      const dx = doorX + 3, dy = Hh - 15;
      if (st.roof === 'ruin') { s.rect(dx - 1, dy - 1, 12, 15, '#1a1a22'); }
      else {
        s.rect(dx - 2, dy - 2, 14, 16, shade(wd, -0.35)); s.rect(dx, dy, 10, 14, st.wall === 'metal' ? '#4a5260' : '#7a4a2a'); s.rect(dx, dy, 10, 2, st.wall === 'metal' ? '#6a7480' : '#9a6a3c');
        s.vline(dx + 5, dy + 2, dy + 13, st.wall === 'metal' ? '#3a424e' : '#5a3418'); s.px(dx + 7, dy + 8, '#e2b04a');
      }
    }
    // roof
    const rc = ROOF[st.roof] || ROOF.red, rd = shade(rc, -0.3), rl = shade(rc, 0.25);
    if (st.tall) {
      s.rect(4, 0, W - 8, roofH, '#5a6470'); for (let y = 2; y < roofH; y += 6) { s.hline(4, W - 5, y, '#6e7884'); s.rect(8, y + 2, W - 16, 2, '#3a5a70'); }
      s.rect(W / 2 - 6, 2, 12, 8, '#2a3440'); s.ell(W / 2, 6, 4, 3, '#57c4e6', { flat: 1 });
      s.rect(0, roofH - 4, W, 4, '#3a424c');
    } else {
      s.rect(0, 0, W, roofH, rc);
      for (let y = 3; y < roofH - 2; y += 4) { s.hline(0, W - 1, y, rd); for (let x = (y % 8 ? 0 : 4); x < W; x += 8) s.vline(x, y - 3, y - 1, shade(rc, -0.12)); }
      if (st.roof === 'thatch') for (let x = 1; x < W; x += 3) s.vline(x, 1, roofH - 3, shade(rc, (x % 2) ? 0.12 : -0.1));
      s.rect(0, 0, W, 2, rl); s.rect(0, 0, 2, roofH, shade(rc, 0.12)); s.rect(W - 2, 0, 2, roofH, rd);
      s.rect(0, roofH - 3, W, 3, shade(rd, -0.15)); s.hline(0, W - 1, roofH - 3, rd);
      if (st.roof === 'ruin') { const r = G.rng(st.x * 31 + st.y); for (let k = 0; k < 3; k++) { const x = 4 + Math.floor(r() * (W - 14)), y = 3 + Math.floor(r() * (roofH - 10)); s.rect(x, y, 8, 5, '#1a1a22'); s.rect(x + 1, y + 1, 3, 2, '#4a4e54'); } }
      if (st.roof === 'gold') { for (let x = 6; x < W; x += 12) s.ell(x, roofH / 2, 2, 2, '#fff0b0', { flat: 1 }); }
      if (st.chimney) { const cx = W - 16; s.rect(cx, -0, 6, 8, '#8a6a5a'); s.rect(cx - 1, 0, 8, 2, '#5a4a40'); }
      if (st.bell) { s.rect(W / 2 - 5, 0, 10, roofH - 4, shade(wc, -0.05)); s.rect(W / 2 - 3, 3, 6, 6, '#2a2a32'); s.ell(W / 2, 6, 2.5, 2.5, '#e2b04a'); s.poly([[W / 2 - 6, 0], [W / 2, -6], [W / 2 + 6, 0]], rd); }
    }
    // sign
    if (st.sign && st.door != null) {
      const sx = doorX + 14, sy = Hh - 28;
      s.rect(sx, sy, 12, 9, '#6a4628'); s.rect(sx + 1, sy + 1, 10, 7, '#e8d8b0');
      const ic = { post: () => { s.rect(sx + 2, sy + 2, 8, 5, '#ffffff'); s.line(sx + 2, sy + 2, sx + 5, sy + 4, '#c9473d'); s.line(sx + 9, sy + 2, sx + 6, sy + 4, '#c9473d'); },
        inn: () => { s.rect(sx + 2, sy + 4, 8, 3, '#3765b0'); s.rect(sx + 2, sy + 3, 3, 2, '#ffffff'); },
        lens: () => { s.ell(sx + 6, sy + 4.5, 3, 3, '#5aa8f0'); s.px(sx + 5, sy + 3, '#ffffff'); },
        museum: () => { s.poly([[sx + 2, sy + 4], [sx + 6, sy + 1], [sx + 10, sy + 4]], '#8a7a5a'); s.vline(sx + 3, sy + 4, sy + 7, '#8a7a5a'); s.vline(sx + 6, sy + 4, sy + 7, '#8a7a5a'); s.vline(sx + 9, sy + 4, sy + 7, '#8a7a5a'); },
        church: () => { s.ell(sx + 6, sy + 4, 2.5, 3, '#e2b04a'); }, palace: () => { s.rect(sx + 3, sy + 3, 6, 4, '#e2b04a'); s.px(sx + 3, sy + 2, '#e2b04a'); s.px(sx + 6, sy + 2, '#e2b04a'); s.px(sx + 8, sy + 2, '#e2b04a'); } };
      (ic[st.sign] || (() => { }))();
    }
    s.outline('#1b1229');
    return s.canvas();
  }
  function drawStamp(st, theme, gnd, over) {
    const X = st.x * 16, Y = st.y * 16;
    if (st.type === 'house') { const c = drawHouse(st, theme); gnd.drawImage(c, X, Y); return; }
    if (st.type === 'stall') {
      const s = new Spr(st.w * 16 + 4, 14);
      s.rect(0, 2, st.w * 16 + 4, 9, st.awning); for (let x = 0; x < st.w * 16 + 4; x += 6) s.rect(x, 2, 3, 9, '#efe6d2');
      for (let x = 0; x < st.w * 16 + 4; x += 6) s.ell(x + 3, 11, 3, 2, x % 12 ? st.awning : '#efe6d2', { flat: 1 });
      s.outline('#1b1229'); over.drawImage(s.canvas(), X - 2, Y - 12);
      const c = new Spr(st.w * 16, 16); c.rect(0, 3, st.w * 16, 13, '#8a5a36'); c.rect(0, 3, st.w * 16, 4, '#b08050');
      for (let i = 0; i < st.w; i++) { const k = ['#e05a6a', '#7ab8ff', '#f2e05c', '#5ab868'][(st.x + i) % 4]; c.ell(i * 16 + 5, 4, 2.5, 2, k); c.ell(i * 16 + 11, 4, 2, 2, '#efe6d2'); }
      c.outline('#1b1229'); gnd.drawImage(c.canvas(), X, Y + 16);
      const p = new Spr(2, 26); p.rect(0, 0, 2, 26, '#5a3a24'); gnd.drawImage(p.canvas(), X - 1, Y - 2); gnd.drawImage(p.canvas(), X + st.w * 16 - 1, Y - 2);
      return;
    }
    if (st.type === 'fountain') {
      const s = new Spr(32, 32); const stone = theme === 'future' ? '#8c949c' : '#c8c0b0';
      s.ell(16, 18, 15, 12, stone); s.ell(16, 17, 12, 9, st.dry ? '#5a6068' : '#3577b0', { flat: 1 }); if (!st.dry) { s.ell(13, 15, 4, 2, '#7ab8e8', { flat: 1 }); }
      s.rect(14, 4, 4, 14, stone); s.ell(16, 5, 5, 2.5, shade(stone, 0.15));
      if (st.dry) { s.line(10, 20, 22, 14, '#3a3e44'); }
      s.outline('#1b1229'); gnd.drawImage(s.canvas(), X, Y);
      if (!st.dry) F.decor.push({ kind: 'fountain', x: X + 16, y: Y + 4 });
      return;
    }
    if (st.type === 'lighthouse' || st.type === 'beacon') {
      const lh = st.type === 'lighthouse';
      const s = new Spr(48, 96);
      if (lh) {
        s.poly([[10, 26], [38, 26], [42, 94], [6, 94]], '#f2ece0', { side: 1 });
        for (let y = 38; y < 94; y += 18) s.poly([[8 + (y - 26) * 0.06, y], [40 - (y - 26) * 0.06, y], [40.5 - (y - 26) * 0.06, y + 8], [7.5 + (y - 26) * 0.06, y + 8]], '#c9473d', { side: 1 });
        s.rect(6, 20, 36, 6, '#3a3a48'); s.rect(4, 20, 40, 2, '#5a5a68');
        s.rect(12, 6, 24, 14, '#1a2238'); s.rect(14, 8, 20, 10, G.flags.lit ? '#fff4c0' : '#5a7ab0'); s.vline(20, 8, 17, '#2a3248'); s.vline(28, 8, 17, '#2a3248');
        s.poly([[10, 6], [24, -0], [38, 6]], '#3a3a48'); s.rect(23, 0, 2, 2, '#e2b04a');
        s.rect(20, 80, 8, 14, '#5a3a24'); s.rect(21, 81, 6, 12, '#7a4a2a');
        s.rect(18, 50, 6, 8, '#1a2238'); s.rect(19, 51, 4, 6, '#5a88b8');
      } else {
        s.poly([[8, 30], [40, 30], [44, 94], [4, 94]], '#9c9688', { side: 1 });
        for (let y = 34; y < 94; y += 6) { s.hline(6, 42, y, '#7c766a'); for (let x = (y % 12 ? 6 : 12); x < 42; x += 12) s.vline(x, y - 5, y, '#7c766a'); }
        s.rect(2, 22, 44, 8, '#7c766a'); s.rect(2, 22, 44, 2, '#b8b2a2'); for (let x = 2; x < 46; x += 8) s.rect(x, 16, 5, 6, '#8c8678');
        s.rect(20, 76, 8, 18, '#2a2420');
      }
      s.outline('#1b1229');
      const c = s.canvas();
      // lower part (collision rows) goes to the ground layer, upper part over characters
      const baseTop = (st.y + 1) * 16; const imgY = (st.y + 5) * 16 - 96 + 0;
      const split = baseTop - imgY;
      gnd.drawImage(c, 0, split, 48, 96 - split, X, baseTop, 48, 96 - split);
      over.drawImage(c, 0, 0, 48, split, X, imgY, 48, split);
      if (lh) F.decor.push({ kind: 'lighthouse', x: X + 24, y: imgY + 13 }); else F.decor.push({ kind: 'beacon', x: X + 24, y: imgY + 16 });
      return;
    }
    if (st.type === 'tent') {
      const s = new Spr(32, 30);
      s.poly([[16, 0], [31, 28], [1, 28]], '#c8b080', { side: 1 }); s.poly([[16, 6], [21, 28], [11, 28]], '#3a2a20'); s.line(16, 0, 16, 28, '#8a7050');
      s.outline('#1b1229'); gnd.drawImage(s.canvas(), X, Y + 2); return;
    }
    if (st.type === 'boat') {
      const s = new Spr(64, 28);
      s.poly([[2, 10], [62, 10], [54, 24], [10, 24]], '#8a5a36', { grad: 1 }); s.hline(2, 61, 10, '#c08a52'); s.hline(6, 58, 14, '#6a4628');
      s.vline(30, 0, 10, '#5a3a24'); s.poly([[31, 0], [46, 8], [31, 9]], '#efe6d2'); s.outline('#1b1229');
      gnd.drawImage(s.canvas(), X, Y); return;
    }
    if (st.type === 'garland') {
      for (let x = st.x0; x < st.x1; x += 2) F.decor.push({ kind: 'lantern', x: x * 16 + 8, y: st.y * 16 - 10 + Math.sin(x) * 2, c: ['#ffb060', '#ff7a6a', '#ffe08a'][x % 3] });
      F.decor.push({ kind: 'garland', x0: st.x0 * 16 + 8, x1: st.x1 * 16 - 8, y: st.y * 16 - 12 });
      return;
    }
    if (st.type === 'fencerow') { for (let x = st.x0; x <= st.x1; x++) gnd.drawImage(G.tiles.get(theme, 'fence', x, st.y), x * 16, st.y * 16); return; }
    if (st.type === 'biglens') {
      const s = new Spr(32, 32); s.rect(6, 18, 20, 14, '#6a6a78'); s.rect(6, 18, 20, 3, '#8a8a98');
      s.ell(16, 13, 13, 12, '#9ad8f0', { lit: 0.4 }); s.ell(16, 13, 9, 8, '#c8eefc', { flat: 1 }); s.ell(12, 9, 3, 2, '#ffffff', { flat: 1 });
      s.outline('#1b1229'); gnd.drawImage(s.canvas(), X, Y); F.decor.push({ kind: 'lens', x: X + 16, y: Y + 13 }); return;
    }
    if (st.type === 'cave') { const s = new Spr(40, 28); s.ell(20, 22, 16, 18, '#2a1a14'); s.ell(20, 24, 12, 14, '#0a0604', { flat: 1 }); s.outline('#1b1229'); gnd.drawImage(s.canvas(), X - 12, Y - 10); return; }
    if (st.type === 'ladder') { const s = new Spr(32, 24); for (let y = 0; y < 24; y += 4) s.hline(4, 27, y, '#8a929a'); s.vline(4, 0, 23, '#5a6268'); s.vline(27, 0, 23, '#5a6268'); gnd.drawImage(s.canvas(), X, Y - 8); return; }
    if (st.type === 'bigclock') {
      const s = new Spr(96, 48); s.rect(0, 0, 96, 48, '#2a3038'); s.ell(48, 24, 22, 22, '#e8e2d2'); s.ell(48, 24, 19, 19, '#f8f4ea', { flat: 1 });
      for (let k = 0; k < 12; k++) { const a = k / 12 * Math.PI * 2; s.rect(Math.round(48 + Math.cos(a) * 16), Math.round(24 + Math.sin(a) * 16), 2, 2, '#2a2a32'); }
      s.line(48, 24, 48, 10, '#2a2a32'); s.line(48, 24, 58, 30, '#c9473d');
      for (let x = 4; x < 96; x += 10) { s.ell(x, 6, 4, 4, '#6a7280'); s.ell(x + 5, 42, 4, 4, '#6a7280'); }
      s.outline('#1b1229'); gnd.drawImage(s.canvas(), X, Y); return;
    }
    if (st.type === 'biggear') {
      const s = new Spr(64, 64);
      for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2; s.rect(Math.round(32 + Math.cos(a) * 28) - 3, Math.round(32 + Math.sin(a) * 28) - 3, 7, 7, '#c8a050'); }
      s.ell(32, 32, 26, 26, '#e2b04a'); s.ell(32, 32, 18, 18, '#c8a050', { flat: 1 }); s.ell(32, 32, 7, 7, '#8a6a30');
      for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; s.line(32, 32, 32 + Math.cos(a) * 18, 32 + Math.sin(a) * 18, '#8a6a30'); }
      s.outline('#1b1229'); gnd.drawImage(s.canvas(), X, Y); return;
    }
    if (st.type === 'clockface') {
      gnd.save(); gnd.globalAlpha = 0.45; gnd.strokeStyle = '#f0c860'; gnd.lineWidth = 1;
      const cx = X + 96, cy = Y + 96;
      for (const r of [88, 80]) { gnd.beginPath(); gnd.arc(cx, cy, r, 0, Math.PI * 2); gnd.stroke(); }
      for (let k = 0; k < 12; k++) { const a = k / 12 * Math.PI * 2; gnd.fillStyle = '#f0c860'; gnd.fillRect(Math.round(cx + Math.cos(a) * 72) - 2, Math.round(cy + Math.sin(a) * 72) - 2, 4, 4); }
      gnd.restore(); F.decor.push({ kind: 'hands', x: cx, y: cy }); return;
    }
  }

  // ---------- map loading ----------
  F.glowSprite = (() => { const m = new Map(); return (col, r) => { const k = col + r; let c = m.get(k); if (!c) { [c] = canvas(r * 2, r * 2); const g = c.getContext('2d'); const gr = g.createRadialGradient(r, r, 0, r, r, r); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, r * 2, r * 2); m.set(k, c); } return c; }; })();

  F.load = function (id) {
    const def = G.MAPS[id]; if (!def) throw new Error('no map ' + id);
    const col = F.buildCollision(def);
    const theme = def.theme, W = col.w * 16, H = col.h * 16;
    F.decor = [];
    const frames = [];
    let animated = false;
    for (let y = 0; y < col.h; y++) for (let x = 0; x < col.w; x++) { const t = G.TILEDEF[col.names[y][x]]; if (t && t.frames > 1) animated = true; }
    const nf = animated ? 4 : 1;
    const glows = [];
    const [overC, overG] = canvas(W, H);
    for (let f = 0; f < nf; f++) {
      const [c, g] = canvas(W, H);
      for (let y = 0; y < col.h; y++) for (let x = 0; x < col.w; x++) {
        let n = col.names[y][x];
        const base = n === 'tree' ? (def.treeGround || (theme === 'cave' ? 'stonefloor' : 'grass')) : n;
        const td = G.TILEDEF[base];
        if (td && td.obj) { // objects sit on the surrounding ground
          const under = def.objGround || (theme === 'house' || def.indoor ? 'floor' : theme === 'cave' ? 'stonefloor' : theme === 'future' && y > 0 && col.names[y - 1][x] === 'cobble' ? 'cobble' : theme === 'deep' ? 'seafloor' : theme === 'sky' ? 'grass' : 'grass');
          g.drawImage(G.tiles.get(theme, under, x, y, f), x * 16, y * 16);
        }
        const img = G.tiles.get(theme, base, x, y, f); if (img) g.drawImage(img, x * 16, y * 16);
        if (f === 0 && td && td.glow) glows.push({ x: x * 16 + 8, y: y * 16 + (base === 'lamp' ? 3 : 8), c: td.glow, r: base === 'lamp' ? 40 : 22, tile: base });
        // shoreline foam where water meets land
        if (td && td.water && base === 'water') {
          const land = (dx, dy) => { const nn = col.names[y + dy] && col.names[y + dy][x + dx]; return nn && !G.TILEDEF[nn] ? false : nn && !(G.TILEDEF[nn].water) && nn !== 'bridge' && nn !== 'hbridge'; };
          g.fillStyle = theme === 'cave' ? '#ffd060' : '#d8f0fa';
          if (land(0, -1)) { g.fillRect(x * 16, y * 16, 16, 1); for (let i = (f * 3) % 4; i < 16; i += 4) g.fillRect(x * 16 + i, y * 16 + 1, 2, 1); }
          if (land(-1, 0)) g.fillRect(x * 16, y * 16, 1, 16);
          if (land(1, 0)) g.fillRect(x * 16 + 15, y * 16, 1, 16);
        }
      }
      if (f === 0) {
        for (const st of def.stamps || []) drawStamp(st, theme, g, overG);
        F._stampsDrawn = true;
      } else {
        // re-draw stamps on the other animation frames (ground part only)
        const [dummyC, dummyG] = canvas(W, H);
        const saveDecor = F.decor; F.decor = [];
        for (const st of def.stamps || []) drawStamp(st, theme, g, dummyG);
        F.decor = saveDecor;
      }
      // trees: trunks on ground, canopies on top
      for (let y = 0; y < col.h; y++) for (let x = 0; x < col.w; x++) if (col.names[y][x] === 'tree') {
        g.globalAlpha = 0.25; g.fillStyle = '#000'; g.beginPath(); g.ellipse(x * 16 + 8, y * 16 + 13, 9, 3, 0, 0, Math.PI * 2); g.fill(); g.globalAlpha = 1;
        g.drawImage(G.SPR.trunk(theme), x * 16, y * 16);
        if (f === 0) overG.drawImage(G.SPR.canopy(theme, (x * 7 + y * 3) % 5), x * 16 - 8, y * 16 - 26);
      }
      frames.push(c);
    }
    // windows glow at night
    for (const st of def.stamps || []) if (st._windows) for (const [wx, wy] of st._windows) glows.push({ x: wx, y: wy, c: '#ffd88a', r: 18, window: 1 });
    F.map = { id, def, ...col, theme, frames, over: overC, W, H, glows, objects: [], npcs: [], foes: [] };
    // objects
    for (const o of def.objects || []) {
      const ob = Object.assign({}, o);
      if (ob.type === 'chest') ob.open = !!G.flags['chest_' + ob.id];
      F.map.objects.push(ob);
    }
    F.refreshObjects();
    // actors
    F.actors = F.actors.filter(a => a.party);
    for (const n of def.npcs || []) {
      if (n.cond && !G.cond(n.cond)) continue;
      const a = F.makeActor(n.id, n.ch, n.x, n.y, n.dir || 'down');
      Object.assign(a, { npc: n, home: [n.x, n.y], wander: n.wander || 0, statue: n.statue, tint: n.tint, wt: 60 + G.ri(0, 120) });
      F.actors.push(a);
    }
    // encounters
    for (const [i, e] of (def.encounters || []).entries()) {
      if (e.cond && !G.cond(e.cond)) continue;
      if (e.chance && G.rand() > e.chance) continue;
      for (const [fid, dx, dy] of e.foes) {
        const ed = G.DATA.ENEMIES[fid]; if (!ed) continue;
        const a = F.makeActor('foe' + i + '_' + fid + dx, null, e.x + dx, e.y + dy, 'down');
        Object.assign(a, { foe: fid, enc: i, ed, home: [e.x + dx, e.y + dy], wt: G.ri(20, 90), wander: ed.roam ? 1 : 0, fly: ed.fly, boss: e.boss });
        F.actors.push(a); F.map.foes.push(a);
      }
    }
    F.particles = []; F.initParticles(def.particles);
    return F.map;
  };
  F.refreshObjects = function () {
    const m = F.map; if (!m) return;
    // reset dynamic collision from base
    m.dyn = m.solid.map(r => r.slice());
    for (const o of m.objects) {
      if (o.type === 'gate') { o.open = (o.flags || [o.flag]).every(f => G.flags[f]); if (!o.open) for (let i = 0; i < (o.w || 1); i++) m.dyn[o.y][o.x + i] = 1; }
      else if (o.type === 'bridge') { o.open = !!G.flags[o.flag]; if (o.open) for (let j = 0; j < o.h; j++) for (let i = 0; i < o.w; i++) if (m.dyn[o.y + j]) m.dyn[o.y + j][o.x + i] = 0; }
      else if (['chest', 'save', 'switch', 'post', 'campfire', 'sign', 'pile'].includes(o.type)) m.dyn[o.y][o.x] = 1;
      else if (o.type === 'door') m.dyn[o.y][o.x] = 1;
    }
  };

  // ---------- actors ----------
  F.makeActor = function (id, ch, tx, ty, dir) {
    return { id, ch, x: tx * 16, y: ty * 16, tx, ty, dir, moving: 0, anim: 0, step: 0, path: [], speed: 2, visible: true, z: 0, alpha: 1 };
  };
  F.find = id => F.actors.find(a => a.id === id);
  F.leader = () => F.actors.find(a => a.party && a.slot === 0);
  F.blocked = function (tx, ty, self, ignoreActors) {
    const m = F.map; if (!m) return true;
    if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return true;
    if (m.dyn[ty][tx]) return true;
    if (ignoreActors) return false;
    for (const a of F.actors) {
      if (a === self || !a.visible || a.party || a.foe) continue;
      if (a.tx === tx && a.ty === ty) return true;
      if (a.moving && a.ntx === tx && a.nty === ty) return true;
    }
    return false;
  };
  function startMove(a, dir, force) {
    const [dx, dy] = DIRS[dir]; a.dir = dir;
    const nx = a.tx + dx, ny = a.ty + dy;
    if (!force && F.blocked(nx, ny, a)) return false;
    a.ntx = nx; a.nty = ny; a.moving = 16; return true;
  }
  F.startMove = startMove;
  function stepActor(a) {
    if (!a.moving) return false;
    const sp = a.speed;
    const [dx, dy] = [Math.sign(a.ntx - a.tx), Math.sign(a.nty - a.ty)];
    const d = Math.min(sp, a.moving);
    a.x += dx * d; a.y += dy * d; a.moving -= d; a.anim += d;
    if (a.moving <= 0) { a.moving = 0; a.tx = a.ntx; a.ty = a.nty; a.x = a.tx * 16; a.y = a.ty * 16; return true; }
    return false;
  }

  // ---------- party in the field ----------
  F.syncParty = function () {
    const ids = G.party ? G.party.active : [];
    F.actors = F.actors.filter(a => !a.party || ids.includes(a.id));
    const L = F.actors.find(a => a.party && a.slot === 0);
    ids.forEach((id, i) => {
      let a = F.find(id);
      if (!a) { a = F.makeActor(id, id, L ? L.tx : 0, L ? L.ty : 0, L ? L.dir : 'down'); a.party = 1; if (L) { a.x = L.x; a.y = L.y; } F.actors.push(a); }
      a.slot = i; a.party = 1; a.ch = id;
    });
  };
  F.placeParty = function (tx, ty, dir) {
    F.syncParty();
    for (const a of F.actors) if (a.party) { a.tx = tx; a.ty = ty; a.x = tx * 16; a.y = ty * 16; a.dir = dir; a.moving = 0; a.visible = true; a.z = 0; a.path = []; }
    // lay the trail out behind the leader so followers stand in a line, not on top of each other
    const [dx, dy] = DIRS[dir] || [0, 1];
    const pts = [[tx, ty]];
    for (let k = 1; k <= 3; k++) { const [px, py] = pts[pts.length - 1]; const nx = px - dx, ny = py - dy; pts.push(F.map && !F.blocked(nx, ny, null, true) ? [nx, ny] : [px, py]); }
    F.trail = [];
    for (let k = 3; k >= 0; k--) for (let i = 0; i < 9; i++) { const [a, b] = pts[k], [c, d] = pts[Math.max(0, k - 1)]; const t = k === 0 ? 0 : i / 9; F.trail.push({ x: (a + (c - a) * t) * 16, y: (b + (d - b) * t) * 16, dir }); }
    for (let i = 0; i < 4; i++) F.trail.push({ x: tx * 16, y: ty * 16, dir });
    for (const a of F.actors) if (a.party && a.slot > 0) { const q = F.trail[Math.max(0, F.trail.length - 1 - a.slot * 9)]; a.x = q.x; a.y = q.y; a.tx = Math.round(q.x / 16); a.ty = Math.round(q.y / 16); }
    F.snapCam();
  };
  function updateFollowers(L) {
    const fol = F.actors.filter(a => a.party && a.slot > 0 && !a.scripted);
    for (const a of fol) {
      const idx = F.trail.length - 1 - a.slot * 9;
      const p = F.trail[Math.max(0, idx)]; if (!p) continue;
      const moved = Math.abs(a.x - p.x) + Math.abs(a.y - p.y);
      if (moved > 0) a.anim += Math.min(4, moved);
      a.x = p.x; a.y = p.y; a.dir = p.dir; a.tx = Math.round(a.x / 16); a.ty = Math.round(a.y / 16);
      a.walking = moved > 0;
    }
  }

  // ---------- update ----------
  F.update = function () {
    const m = F.map; if (!m) return;
    const L = F.leader();
    const canControl = !G.cutscene && !G.overlays.length && !F.lock && G.mode === 'field' && L && !L.scripted;
    if (L && !L.scripted) {
      if (L.moving) {
        L.speed = (G.held('run') !== G.cfg.autorun) ? 4 : 2;
        const done = stepActor(L);
        F.trail.push({ x: L.x, y: L.y, dir: L.dir }); if (F.trail.length > 64) F.trail.shift();
        if (done) { if (F.onArrive(L)) return; }
      }
      if (!L.moving && canControl) {
        let dir = null;
        for (const d of ['up', 'down', 'left', 'right']) if (G.held(d)) { dir = d; if (G.pressed(d)) break; }
        if (dir) {
          if (!startMove(L, dir)) { L.dir = dir; L.anim = 0; }
          else { L.speed = (G.held('run') !== G.cfg.autorun) ? 4 : 2; stepActor(L); F.trail.push({ x: L.x, y: L.y, dir: L.dir }); }
        } else L.anim = 0;
        if (G.pressed('ok')) F.interact(L);
        else if (G.pressed('menu') && !L.moving) { G.openMenu && G.openMenu(); }
      }
      updateFollowers(L);
    }
    // scripted / npc actors
    for (const a of F.actors) {
      if (a.party && !a.scripted) continue;
      if (a.path.length && !a.moving) {
        const d = a.path.shift();
        if (d === 'wait') { a.waitT = 8; } else startMove(a, d, true);
      }
      if (a.waitT) a.waitT--;
      if (a.moving) stepActor(a); else if (!a.path.length) a.anim = a.npc && a.npc.still ? 0 : a.anim;
      if (a.npc && a.wander && !a.moving && !G.cutscene && !a.talking && --a.wt <= 0) {
        a.wt = G.ri(70, 200);
        const ds = ['up', 'down', 'left', 'right'], d = ds[G.ri(0, 3)], [dx, dy] = DIRS[d];
        const nx = a.tx + dx, ny = a.ty + dy;
        const Lp = F.leader();
        if (Math.abs(nx - a.home[0]) <= a.wander && Math.abs(ny - a.home[1]) <= a.wander && !F.blocked(nx, ny, a) && !(Lp && ((Lp.tx === nx && Lp.ty === ny) || (Lp.ntx === nx && Lp.nty === ny && Lp.moving)))) { a.speed = 1; startMove(a, d); }
        else a.dir = d;
      }
      if (a.foe) updateFoe(a, L);
    }
    F.updateCam();
    F.updateParticles();
    if (F.banner) { F.banner.t++; if (F.banner.t > 200) F.banner = null; }
  };
  function updateFoe(a, L) {
    a.anim++;
    if (G.mode !== 'field' || G.cutscene || F.lock || !L) return;
    const dx = L.x - a.x, dy = L.y - a.y, dist = Math.hypot(dx, dy);
    // contact (bosses notice the party from a little farther away)
    if (dist < (a.boss ? 36 : 13) && !G.overlays.length && !L.moving) { F.lock = 1; G.battle.startFromField(a.enc); return; }
    if (a.boss) return;
    if (a.moving) return;
    if (--a.wt > 0) return;
    a.wt = G.ri(30, 80);
    if (dist < 64) { // chase
      const d = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
      const [mx, my] = DIRS[d];
      if (!F.blocked(a.tx + mx, a.ty + my, a, true) && Math.abs(a.tx + mx - a.home[0]) <= 3 && Math.abs(a.ty + my - a.home[1]) <= 3) { a.speed = 1; startMove(a, d, true); }
    } else if (a.wander) {
      const ds = ['up', 'down', 'left', 'right'], d = ds[G.ri(0, 3)], [mx, my] = DIRS[d];
      if (!F.blocked(a.tx + mx, a.ty + my, a, true) && Math.abs(a.tx + mx - a.home[0]) <= 1 && Math.abs(a.ty + my - a.home[1]) <= 1) { a.speed = 1; startMove(a, d, true); }
    }
  }
  F.onArrive = function (L) {
    const m = F.map;
    for (const w of m.def.warps || []) {
      if (L.tx >= w.x && L.tx < w.x + (w.w || 1) && L.ty >= w.y && L.ty < w.y + (w.h || 1)) {
        if (w.cond && !G.cond(w.cond)) { if (w.fail && G.SCRIPTS[w.fail]) G.runScript(w.fail); return false; }
        F.warp(w.to, w.tx + (w.w ? L.tx - w.x : 0) * (w.keepX ? 1 : 0), w.ty + (w.h ? L.ty - w.y : 0) * (w.keepY ? 1 : 0), w.dir || L.dir);
        return true;
      }
    }
    for (const t of m.def.triggers || []) {
      if (L.tx >= t.x && L.tx < t.x + (t.w || 1) && L.ty >= t.y && L.ty < t.y + (t.h || 1) && G.cond(t.cond)) { G.runScript(t.script, t); return true; }
    }
    if (G.STEP_HOOK) G.STEP_HOOK(m.id, L.tx, L.ty);
    return false;
  };
  F.warp = async function (to, tx, ty, dir, opt = {}) {
    F.lock++;
    if (!opt.instant) { G.se('door'); await G.fadeTo(1, 0.1); }
    const prev = F.map && F.map.id;
    F.load(to);
    F.placeParty(tx, ty, dir);
    const def = F.map.def;
    if (def.music !== undefined && !opt.keepMusic) { if (def.music) G.bgm(G.musicFor ? G.musicFor(def) : def.music); }
    if (def.name && (!prev || G.MAPS[prev].name !== def.name) && !opt.nobanner) F.banner = { text: def.name, era: def.era, t: 0 };
    G.flags.map = to; G.flags.mx = tx; G.flags.my = ty;
    if (G.SCRIPTS && G.SCRIPTS['setup_' + to]) G.SCRIPTS['setup_' + to]();
    await G.wait(2);
    if (!opt.instant && !opt.stayDark) await G.fadeTo(0, 0.1);
    F.lock--;
    if (G.onMapEnter) await G.onMapEnter(to);
  };

  // ---------- interaction ----------
  F.interact = function (L) {
    const [dx, dy] = DIRS[L.dir];
    let tx = L.tx + dx, ty = L.ty + dy;
    const tryAt = (x, y) => {
      const a = F.actors.find(a => !a.party && !a.foe && a.visible && a.tx === x && a.ty === y && a.npc);
      if (a) { talkTo(a, L); return true; }
      const o = F.map.objects.find(o => o.x <= x && x < o.x + (o.w || 1) && o.y === y);
      if (o) { useObject(o, L); return true; }
      return false;
    };
    if (tryAt(tx, ty)) return;
    const n = F.map.names[ty] && F.map.names[ty][tx];
    if (n === 'counter' || n === 'desk' || n === 'stall' || (F.map.dyn[ty] && F.map.dyn[ty][tx] && F.stallAt(tx, ty))) { if (tryAt(tx + dx, ty + dy)) return; }
  };
  F.stallAt = (x, y) => (F.map.def.stamps || []).some(s => s.type === 'stall' && x >= s.x && x < s.x + s.w && y === s.y + 1);
  async function talkTo(a, L) {
    const opp = { up: 'down', down: 'up', left: 'right', right: 'left' }[L.dir];
    const old = a.dir; if (!a.statue && !a.npc.still) a.dir = opp;
    a.talking = 1;
    await G.runScript(a.npc.talk, a);
    a.talking = 0; if (a.npc.keepDir) a.dir = old;
  }
  async function useObject(o, L) {
    G.cutscene++;
    try {
      if (o.type === 'chest') {
        if (o.open) { await G.say(null, '空っぽだ。'); }
        else {
          o.open = true; G.flags['chest_' + o.id] = 1; G.se('chest');
          if (o.gold) { G.party.gold += o.gold; await G.say(null, `${o.gold}G を手に入れた！`); }
          else { G.addItem(o.item, o.n || 1); await G.say(null, `${G.DATA.ITEMS[o.item].name}${(o.n || 1) > 1 ? ' ×' + o.n : ''} を手に入れた！`, { se: 'item' }); }
          if (o.script && G.SCRIPTS[o.script]) await G.SCRIPTS[o.script](o);
        }
      } else if (o.type === 'save') { await G.savePointMenu(); }
      else if (o.type === 'post') { await G.runScript('post_' + o.era, o); }
      else if (o.type === 'switch') {
        if (G.flags[o.flag]) await G.say(null, 'レバーはもう下りている。');
        else { G.flags[o.flag] = 1; G.se('switch'); await G.wait(10); G.se(F.map.theme === 'future' ? 'splash' : 'gear'); F.refreshObjects(); G.doShake(8); await G.say(null, F.map.theme === 'future' ? 'どこかで水門が動く音がした。' : F.map.theme === 'sky' ? '歯車が回り、どこかで道がつながった。' : 'どこかで重い扉が動く音がした。'); }
      } else if (o.type === 'door' || o.type === 'sign') { await G.say(null, o.text); }
      else if (o.type === 'campfire') { await G.say(null, 'たき火がぱちぱち燃えている。'); }
      else if (o.type === 'gate') { await G.say(null, '固く閉ざされている。どこかに仕掛けがありそうだ。'); }
      else if (o.script && G.SCRIPTS[o.script]) { await G.SCRIPTS[o.script](o); }
    } finally { G.cutscene--; }
  }

  // ---------- camera ----------
  F.updateCam = function () {
    if (F.camLock) return;
    const L = F.leader(); if (!L || !F.map) return;
    const tx = L.x + 8 - W / 4, ty = L.y + 8 - H / 4;
    F.cam.x = F.clampX(tx); F.cam.y = F.clampY(ty);
  };
  F.clampX = x => F.map.W <= W / 2 ? (F.map.W - W / 2) / 2 : G.clamp(x, 0, F.map.W - W / 2);
  F.clampY = y => F.map.H <= H / 2 ? (F.map.H - H / 2) / 2 : G.clamp(y, 0, F.map.H - H / 2);
  F.snapCam = () => { F.camLock = null; F.updateCam(); };
  F.panCam = async (x, y, frames = 40) => { // pan so that world point (x,y) is centered
    F.camLock = 1; const sx = F.cam.x, sy = F.cam.y, ex = F.clampX(x - W / 4), ey = F.clampY(y - H / 4);
    for (let i = 1; i <= frames; i++) { const t = G.ease(i / frames); F.cam.x = G.lerp(sx, ex, t); F.cam.y = G.lerp(sy, ey, t); await G.wait(1); }
  };

  // ---------- particles ----------
  F.initParticles = function (kind) {
    F.pkind = kind; F.particles = [];
    const r = G.rng(7);
    if (kind === 'frozenrain') for (let i = 0; i < 260; i++) F.particles.push({ x: r() * F.map.W, y: r() * F.map.H, l: 3 + Math.floor(r() * 4), ph: r() * 6 });
    if (kind === 'leaves') for (let i = 0; i < 26; i++) F.particles.push({ x: r() * W / 2, y: r() * H / 2, vx: 0.2 + r() * 0.3, vy: 0.25 + r() * 0.3, ph: r() * 6, c: ['#e09040', '#c0662f', '#e8c040'][i % 3] });
    if (kind === 'embers') for (let i = 0; i < 40; i++) F.particles.push({ x: r() * W / 2, y: r() * H / 2, vy: -(0.2 + r() * 0.5), ph: r() * 6 });
    if (kind === 'letters') for (let i = 0; i < 14; i++) F.particles.push({ x: r() * W / 2, y: r() * H / 2, vx: 0.1 + r() * 0.15, vy: -0.05 - r() * 0.1, ph: r() * 6 });
    if (kind === 'clouds') for (let i = 0; i < 7; i++) F.particles.push({ x: r() * W / 2, y: r() * H / 2, vx: 0.08 + r() * 0.12, w: 30 + r() * 40 });
    if (kind === 'bubbles') for (let i = 0; i < 34; i++) F.particles.push({ x: r() * W / 2, y: r() * H / 2, vy: -(0.15 + r() * 0.35), ph: r() * 6, s: r() < 0.3 ? 2 : 1 });
  };
  F.updateParticles = function () {
    const k = F.pkind, w = W / 2, h = H / 2;
    for (const p of F.particles) {
      if (k === 'leaves') { p.x += p.vx + Math.sin(G.frame / 30 + p.ph) * 0.3; p.y += p.vy; }
      else if (k === 'embers' || k === 'bubbles') { p.y += p.vy; p.x += Math.sin(G.frame / 25 + p.ph) * 0.2; }
      else if (k === 'letters') { p.x += p.vx; p.y += p.vy + Math.sin(G.frame / 50 + p.ph) * 0.08; }
      else if (k === 'clouds') { p.x += p.vx; }
      if (k !== 'frozenrain') { if (p.x > w + 20) p.x -= w + 40; if (p.x < -20) p.x += w + 40; if (p.y > h + 10) p.y -= h + 20; if (p.y < -10) p.y += h + 20; }
    }
  };
  function drawParticles(c) {
    const k = F.pkind;
    if (k === 'frozenrain') {
      c.fillStyle = 'rgba(220,240,255,0.75)';
      for (const p of F.particles) { const x = Math.round(p.x - F.cam.x), y = Math.round(p.y - F.cam.y); if (x < -2 || y < -8 || x > W / 2 || y > H / 2) continue; c.globalAlpha = 0.45 + Math.sin(G.frame / 40 + p.ph) * 0.2; c.fillRect(x, y, 1, p.l); }
      c.globalAlpha = 1; return;
    }
    for (const p of F.particles) {
      const x = Math.round(p.x), y = Math.round(p.y);
      if (k === 'leaves') { c.fillStyle = p.c; c.fillRect(x, y, 2, 1); c.fillRect(x + (Math.sin(G.frame / 10 + p.ph) > 0 ? 1 : 0), y + 1, 1, 1); }
      else if (k === 'embers') { c.globalAlpha = 0.5 + Math.sin(G.frame / 8 + p.ph) * 0.4; c.fillStyle = '#ffb040'; c.fillRect(x, y, 1, 1); c.globalAlpha = 1; }
      else if (k === 'bubbles') { c.globalAlpha = 0.6; c.strokeStyle = '#bff0ff'; c.lineWidth = 1; if (p.s > 1) c.strokeRect(x + 0.5, y + 0.5, 2, 2); else { c.fillStyle = '#bff0ff'; c.fillRect(x, y, 1, 1); } c.globalAlpha = 1; }
      else if (k === 'letters') { c.globalAlpha = 0.7; c.fillStyle = '#efe6d2'; c.fillRect(x, y, 6, 4); c.fillStyle = '#a89878'; c.fillRect(x + 1, y + 1, 4, 1); c.fillStyle = (p.ph > 3) ? '#c9473d' : '#3765b0'; c.fillRect(x + 4, y, 1, 1); c.globalAlpha = 1; }
      else if (k === 'clouds') { c.globalAlpha = 0.35; c.fillStyle = '#ffffff'; c.beginPath(); c.ellipse(x, y, p.w / 2, p.w / 6, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1; }
    }
  }

  // ---------- rendering ----------
  F.spriteOf = function (a) {
    if (a.foe) {
      const ed = a.ed; return G.SPR.monster(ed.spr, ed.pal, Math.floor(a.anim / 14) % 2);
    }
    const fr = G.SPR.frames(a.ch); if (!fr) return null;
    if (a.pose && fr[a.pose]) return fr[a.pose];
    if (a.statue) return fr.statue ? fr.statue[a.dir] : fr[a.dir][0];
    const moving = a.moving || a.walking || (a.party && a.slot > 0 && a.walking);
    const seq = fr[a.dir] || fr.down;
    if (!moving && !a.forceAnim) return seq[0];
    const k = Math.floor(a.anim / 8) % 4;
    return seq[[1, 0, 2, 0][k]];
  };
  F.drawActor = function (c, a, ox = 0, oy = 0) {
    if (!a.visible) return;
    const img = F.spriteOf(a); if (!img) return;
    const x = Math.round(a.x + 8 - img.width / 2 + ox), base = Math.round(a.y + 15 + oy);
    // shadow
    c.globalAlpha = 0.28 * a.alpha; c.fillStyle = '#000'; c.beginPath(); c.ellipse(a.x + 8 + ox, base - 1, Math.min(8, img.width / 2.6), 2.5, 0, 0, Math.PI * 2); c.fill();
    c.globalAlpha = a.alpha;
    const bob = (a.ch === 'pip' || (a.foe && a.fly)) ? Math.round(Math.sin((G.frame + (a.tx * 7)) / 12) * 1.5) - 4 : 0;
    let y = base - img.height - Math.round(a.z) + bob;
    if (a.flashT && a.flashT-- % 4 < 2) { c.drawImage(G.art.silhouette(img, '#ffffff'), x, y); }
    else c.drawImage(img, x, y);
    if (a.tint) { c.globalCompositeOperation = 'source-atop'; c.globalAlpha = 0; c.globalCompositeOperation = 'source-over'; }
    c.globalAlpha = 1;
    if (a.emote) { drawEmote(c, a.emote, a.x + 8 + ox, y - 4); }
  };
  function drawEmote(c, e, x, y) {
    c.fillStyle = '#fff'; c.strokeStyle = '#1b1229'; c.lineWidth = 1;
    c.beginPath(); c.roundRect ? c.roundRect(x - 6, y - 12, 12, 11, 3) : c.rect(x - 6, y - 12, 12, 11); c.fill(); c.stroke();
    c.font = '10px ' + G.FONT; c.textAlign = 'center'; c.textBaseline = 'top'; c.fillStyle = e === '!' ? '#c9473d' : '#3765b0'; c.fillText(e, x, y - 12); c.textAlign = 'left';
  }
  F.render = function () {
    const m = F.map; if (!m) return;
    const c = ctx;
    const sx = (G.shake ? (G.rand() * 4 - 2) : 0);
    const camx = Math.round(F.cam.x * 2) / 2 + sx, camy = Math.round(F.cam.y * 2) / 2;
    c.save();
    c.fillStyle = m.theme === 'sky' ? '#9ccaf0' : '#05060c'; c.fillRect(0, 0, W, H);
    c.setTransform(2, 0, 0, 2, -camx * 2, -camy * 2);
    c.imageSmoothingEnabled = false;
    const fi = m.frames.length > 1 ? Math.floor(G.frame / 16) % m.frames.length : 0;
    c.drawImage(m.frames[fi], 0, 0);
    drawObjects(c, m);
    drawDecor(c, 'under');
    // entities
    const list = F.actors.filter(a => a.visible);
    for (const o of m.objects) if (o.type === 'post' || o.type === 'save' || o.type === 'chest' || o.type === 'campfire') list.push({ obj: o, y: o.y * 16, x: o.x * 16 });
    if (G.battle && G.battle.active) for (const b of G.battle.drawables()) list.push(b);
    list.sort((a, b) => (a.y + (a.zsort || 0) + (a.party && a.slot === 0 ? 0.5 : 0)) - (b.y + (b.zsort || 0) + (b.party && b.slot === 0 ? 0.5 : 0)));
    for (const a of list) { if (a.obj) drawObjSprite(c, a.obj); else if (a.battler) G.battle.drawBattler(c, a); else F.drawActor(c, a); }
    c.drawImage(m.over, 0, 0);
    drawDecor(c, 'over');
    if (G.battle && G.battle.active) G.battle.drawWorldFx(c);
    c.setTransform(2, 0, 0, 2, 0, 0);
    // weather
    if (F.pkind === 'frozenrain') { c.save(); drawParticles(c); c.restore(); }
    else drawParticles(c);
    c.setTransform(1, 0, 0, 1, 0, 0);
    drawLighting(c, m, camx, camy);
    if (G.battle && G.battle.active) G.battle.drawScreenFx(c);
    c.restore();
    drawBanner(c);
    if (G.flags.race && G.drawRaceHud) G.drawRaceHud();
  };
  function drawObjects(c, m) {
    for (const o of m.objects) {
      if (o.type === 'gate') for (let i = 0; i < (o.w || 1); i++) c.drawImage(G.SPR.gate(o.open, o.theme || m.theme), (o.x + i) * 16, o.y * 16);
      else if (o.type === 'bridge' && o.open) {
        for (let j = 0; j < o.h; j++) for (let i = 0; i < o.w; i++) {
          const t = o.cloud ? G.tiles.get('sky', 'cloud', o.x + i, o.y + j) : G.tiles.get(m.theme, (o.dir === 'h' ? 'hbridge' : 'bridge'), o.x + i, o.y + j);
          if (o.cloud) c.drawImage(t, (o.x + i) * 16, (o.y + j) * 16);
          else { c.drawImage(G.tiles.get('future', 'metalfloor', o.x + i, o.y + j), (o.x + i) * 16, (o.y + j) * 16); }
        }
      } else if (o.type === 'switch') c.drawImage(G.SPR.switchTile(!!G.flags[o.flag]), o.x * 16, o.y * 16);
    }
  }
  function drawObjSprite(c, o) {
    if (o.type === 'chest') c.drawImage(G.SPR.chest(o.open, F.map.theme), o.x * 16, o.y * 16);
    else if (o.type === 'save') { const img = G.SPR.savepoint(Math.floor(G.frame / 8)); c.drawImage(img, o.x * 16, o.y * 16 - 8); }
    else if (o.type === 'post') {
      const glow = G.flags.riftOpen === F.map.id || (G.flags.p >= 8 && o.era !== 'final') || (o.era === 'final' && G.flags.p >= 15);
      const img = G.SPR.post(glow); c.drawImage(img, o.x * 16, o.y * 16 - 10);
      if (o.label) { c.font = '8px ' + G.FONT; c.textAlign = 'center'; c.fillStyle = '#1b1229'; const lb = G.tr(o.label); c.fillText(lb, o.x * 16 + 9, o.y * 16 + 17); c.fillStyle = '#efe6d2'; c.fillText(lb, o.x * 16 + 8, o.y * 16 + 16); c.textAlign = 'left'; }
    } else if (o.type === 'campfire') {
      const X = o.x * 16 + 8, Y = o.y * 16 + 12;
      c.fillStyle = '#5a3a24'; c.fillRect(X - 6, Y, 12, 3);
      for (let i = 0; i < 6; i++) { const t = (G.frame / 6 + i * 1.7); c.fillStyle = i % 2 ? '#ffb040' : '#ff6a2a'; c.fillRect(X - 4 + (i * 1.6) | 0, Y - 2 - (t * 1.7 % 9) | 0, 2, 3); }
    }
  }
  function drawDecor(c, layer) {
    for (const d of F.decor) {
      if (layer === 'under' && d.kind === 'fountain') {
        for (let i = 0; i < 6; i++) { const t = ((G.frame + i * 11) % 40) / 40; const ang = i / 6 * Math.PI * 2; c.fillStyle = '#cfe9f5'; c.fillRect(Math.round(d.x + Math.cos(ang) * t * 9), Math.round(d.y + t * 10 - Math.sin(t * Math.PI) * 6), 1, 1); }
      }
      if (layer === 'over') {
        if (d.kind === 'garland') { c.strokeStyle = 'rgba(40,30,30,0.8)'; c.lineWidth = 0.5; c.beginPath(); for (let x = d.x0; x <= d.x1; x += 8) { const y = d.y + Math.sin(x / 32) * 3 + 2; x === d.x0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); }
        if (d.kind === 'lantern') { c.fillStyle = '#2a1a1a'; c.fillRect(d.x - 2, d.y, 4, 6); c.fillStyle = G.flags.eve ? d.c : shade(d.c, -0.2); c.fillRect(d.x - 1, d.y + 1, 2, 4); }
        if (d.kind === 'lighthouse' && G.flags.lit) {
          c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.35;
          const a = G.frame / 70; c.fillStyle = '#fff4c0';
          c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(d.x + Math.cos(a) * 260 - Math.sin(a) * 26, d.y + Math.sin(a) * 260 * 0.5 + Math.cos(a) * 13); c.lineTo(d.x + Math.cos(a) * 260 + Math.sin(a) * 26, d.y + Math.sin(a) * 260 * 0.5 - Math.cos(a) * 13); c.fill(); c.restore();
        }
        if (d.kind === 'beacon' && G.flags.beaconLit) {
          for (let i = 0; i < 10; i++) { const t = (G.frame / 5 + i * 2.3); c.fillStyle = i % 3 ? '#ffb040' : '#fff0a0'; c.fillRect(d.x - 10 + (i * 2.2) | 0, d.y - 4 - (t * 2 % 16) | 0, 2, 3); }
        }
        if (d.kind === 'lens') { c.save(); c.globalAlpha = 0.4 + Math.sin(G.frame / 20) * 0.2; c.fillStyle = '#ffffff'; c.fillRect(d.x - 7, d.y - 6, 2, 2); c.restore(); }
        if (d.kind === 'hands') {
          const a1 = G.flags.bossFinal ? G.frame / 120 : -Math.PI / 2 + 0.01, a2 = G.flags.bossFinal ? G.frame / 10 : -Math.PI / 2 - 0.4;
          c.save(); c.strokeStyle = 'rgba(240,200,96,0.7)'; c.lineWidth = 3; c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(d.x + Math.cos(a1) * 50, d.y + Math.sin(a1) * 50); c.stroke(); c.lineWidth = 2; c.beginPath(); c.moveTo(d.x, d.y); c.lineTo(d.x + Math.cos(a2) * 70, d.y + Math.sin(a2) * 70); c.stroke(); c.restore();
        }
      }
    }
    if (layer === 'over' && G.flags.riftOpen === F.map.id && G.flags.riftAt) {
      const [rx, ry] = G.flags.riftAt; drawRift(c, rx, ry, G.flags.riftSize || 1);
    }
  }
  function drawRift(c, x, y, s) {
    c.save(); c.translate(x, y);
    for (let k = 0; k < 3; k++) {
      c.rotate(G.frame / (40 + k * 13));
      c.strokeStyle = ['rgba(120,200,255,0.8)', 'rgba(200,140,255,0.6)', 'rgba(255,255,255,0.7)'][k]; c.lineWidth = 1;
      c.beginPath(); for (let t = 0; t < 30; t++) { const a = t * 0.5, r = t * 0.8 * s; t ? c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.7) : c.moveTo(0, 0); } c.stroke();
    }
    c.fillStyle = '#05060c'; c.beginPath(); c.ellipse(0, 0, 5 * s, 4 * s, 0, 0, Math.PI * 2); c.fill();
    c.restore();
  }
  F.drawRift = drawRift;
  const TINT = {
    evening: ['#d0603a', 0.62], night: ['#24307a', 0.7], frozen: ['#9ab8d8', 0.28], cave: ['#a05a3a', 0.38],
    dark: ['#3a4a6a', 0.5], deep: ['#1a5a7a', 0.45], dusk: ['#b07aa8', 0.3],
  };
  F.currentTint = function () {
    const m = F.map; if (!m) return null;
    if (m.def.tint) return m.def.tint;
    if (m.id === 'hasune' || m.id === 'cape' || m.id === 'haru_home' || m.id === 'post_office' || m.id === 'mio_shop') {
      if (G.flags.night) return 'night'; if (G.flags.eve) return 'evening';
    }
    if (m.theme === 'varn' && G.flags.p >= 4 && G.flags.p < 5) return 'dusk';
    return null;
  };
  function drawLighting(c, m, camx, camy) {
    const tk = F.currentTint(); if (!tk) return;
    const [col, a] = TINT[tk];
    c.save(); c.globalCompositeOperation = 'multiply'; c.globalAlpha = a; c.fillStyle = col; c.fillRect(0, 0, W, H); c.restore();
    c.save(); c.globalCompositeOperation = 'lighter';
    const night = tk === 'night' || tk === 'evening' || tk === 'cave' || tk === 'dark' || tk === 'deep' || tk === 'dusk';
    for (const g of m.glows) {
      if (g.window && !(tk === 'night' || tk === 'evening')) continue;
      if (g.tile === 'lamp' && !night) continue;
      const x = (g.x - camx) * 2, y = (g.y - camy) * 2; if (x < -100 || y < -100 || x > W + 100 || y > H + 100) continue;
      const r = g.r * 2 * (1 + Math.sin(G.frame / 23 + g.x) * 0.04);
      c.globalAlpha = g.window ? 0.35 : 0.5; c.drawImage(F.glowSprite(g.c, 64), x - r, y - r, r * 2, r * 2);
    }
    for (const d of F.decor) if (d.kind === 'lantern' && G.flags.eve) { const x = (d.x - camx) * 2, y = (d.y + 3 - camy) * 2; c.globalAlpha = 0.45; c.drawImage(F.glowSprite(d.c, 64), x - 22, y - 22, 44, 44); }
    for (const o of m.objects) if (o.type === 'save' || o.type === 'campfire') { const x = (o.x * 16 + 8 - camx) * 2, y = (o.y * 16 + 4 - camy) * 2; c.globalAlpha = 0.4; c.drawImage(F.glowSprite(o.type === 'save' ? '#57c4e6' : '#ff8a3a', 64), x - 50, y - 50, 100, 100); }
    const L = F.leader();
    if (L && (tk === 'cave' || tk === 'dark' || tk === 'deep')) { const x = (L.x + 8 - camx) * 2, y = (L.y + 4 - camy) * 2; c.globalAlpha = 0.18; c.drawImage(F.glowSprite('#ffe8c0', 64), x - 120, y - 120, 240, 240); }
    c.restore();
  }
  function drawBanner(c) {
    const b = F.banner; if (!b) return;
    const a = b.t < 20 ? b.t / 20 : b.t > 170 ? (200 - b.t) / 30 : 1;
    c.save(); c.globalAlpha = Math.max(0, a);
    const era = b.era && b.era !== '—' ? (b.era.startsWith('前') ? `紀元前${b.era.slice(1)}年` : `${b.era}年`) : '';
    const tw = Math.max(G.tw(b.text, 16), G.tw(era, 12)) + 48;
    const x = W / 2 - tw / 2, y = 26;
    G.ui.stampFrame(x, y, tw, era ? 50 : 34);
    if (era) G.text(era, W / 2, y + 7, '#e2b04a', 'center', 12);
    G.text(b.text, W / 2, y + (era ? 25 : 9), '#f3ead6', 'center', 16);
    c.restore();
  }
})();
