'use strict';
// Battle: fought right on the map where the party meets the enemy.
(function () {
  const D = G.DATA, U = G.ui, F = G.field;
  const B = G.battle = { active: false };
  let S = null;
  const ST_DUR = { poison: 900, sleep: 480, slow: 900, stop: 360, haste: 1200, guard: 1500, defdown: 1200 };
  const ST_NAME = { poison: 'インク染み', sleep: 'ねむり', slow: '鈍足', stop: 'とばり', haste: '加速', guard: '守り', defdown: '守り低下' };
  B.ST_NAME = ST_NAME;

  // ---------------- math (shared with tests) ----------------
  const rnd = (a, b) => a + G.rand() * (b - a);
  function attStats(b) {
    if (b.side === 'party') { const s = b.stats; return { atk: s.atk, mag: s.matk, hit: s.hit, spd: s.spd }; }
    return { atk: b.ed.atk, mag: b.ed.mag, hit: 95, spd: b.ed.spd };
  }
  function defStats(b) {
    let def, mdef, eva;
    if (b.side === 'party') { def = b.stats.def; mdef = b.stats.mdef; eva = b.stats.eva; }
    else { def = b.ed.def; mdef = b.ed.mdef; eva = 4; }
    if (b.st.guard) { def *= 1.5; mdef *= 1.3; }
    if (b.st.defdown) { def *= 0.6; mdef *= 0.8; }
    return { def, mdef, eva };
  }
  function elemMul(t, elem) {
    if (!elem || elem === 'none') return 1;
    if (t.side === 'foe') { const ed = t.ed; if (ed.resist && ed.resist[elem] != null) return ed.resist[elem]; if (ed.weak && ed.weak[elem]) return ed.weak[elem]; }
    return 1;
  }
  B.calc = function (a, t, tech) {
    const A = attStats(a), Dd = defStats(t);
    const kind = tech.kind, power = tech.power || 1;
    let dmg = 0, crit = false, miss = false;
    if (kind === 'phys') {
      if (G.rand() * 100 > A.hit - Dd.eva && !tech.sure) return { miss: true, dmg: 0 };
      dmg = A.atk * power * 40 / (40 + Dd.def) * rnd(0.9, 1.1);
      if (a.side === 'party' && G.rand() < 0.06) { dmg *= 1.8; crit = true; }
    } else if (kind === 'mag') {
      dmg = (A.mag * 1.8 + 8) * power * 40 / (40 + Dd.mdef) * rnd(0.92, 1.08);
    }
    const em = elemMul(t, tech.elem);
    dmg *= em;
    if (t.shield) dmg *= t.shield;
    if (a.st && a.st.weak) dmg *= 0.7;
    dmg = em === 0 ? 0 : Math.max(1, Math.round(dmg));
    return { dmg, crit, miss, weak: em > 1, resist: em < 1 && em > 0, immune: em === 0 };
  };
  B.healAmount = (a, power) => Math.round((attStats(a).mag * 1.6 + 10) * power * rnd(0.95, 1.05));

  // ---------------- battlers ----------------
  function partyBattler(id, x, y, dir) {
    const m = G.party.members[id], s = G.stats(id);
    return { battler: 1, side: 'party', id, name: G.memberName(id), x, y, hx: x, hy: y, z: 0, dir, atb: G.rand() * 40 + (m.hp > 0 ? 20 : 0), hp: m.hp, maxhp: s.maxhp, mp: m.mp, maxmp: s.maxmp, stats: s, st: Object.assign({}, m.st || {}), alive: m.hp > 0, anim: 0, alpha: 1, pose: m.hp > 0 ? null : 'ko', member: m };
  }
  function foeBattler(eid, x, y, opt = {}) {
    const ed = D.ENEMIES[eid]; const img = G.SPR.monster(ed.spr, ed.pal, 0);
    const hpMul = opt.hpMul || 1;
    return Object.assign({ battler: 1, side: 'foe', id: eid, name: ed.name, ed, x, y, hx: x, hy: y, z: 0, dir: 'down', atb: G.rand() * 50, hp: Math.round(ed.hp * hpMul), maxhp: Math.round(ed.hp * hpMul), st: {}, alive: true, anim: G.ri(0, 30), alpha: 1, w: img.width, h: img.height, turns: 0, ph: G.rand() * 6 }, opt);
  }
  const center = b => b.side === 'party' ? { x: b.x + 8, y: b.y + 4 - b.z } : { x: b.x + 8, y: b.y + 15 - b.h / 2 - b.z + (b.ed.fly ? -4 : 0) };
  B.center = center;
  const alive = list => list.filter(b => b.alive);
  B.state = () => S;

  // ---------------- start ----------------
  // opt: { foes:[{id,x,y,...}], party:[{x,y}], boss, bgm, canEscape, enc, hpMul, onFoeDeath }
  B.start = function (opt) {
    return new Promise(async res => {
      B.active = true; G.mode = 'battle'; F.lock++; F.banner = null;
      S = { opt, res, party: [], foes: [], queue: [], busy: false, fx: [], pops: [], phase: 'intro', menu: null, ready: [], msg: null, t: 0, flees: 0, deadFoes: [], drops: [] };
      const pa = F.actors.filter(a => a.party).sort((a, b) => a.slot - b.slot);
      pa.forEach((a, i) => { const b = partyBattler(a.id, a.x, a.y, a.dir); b.actor = a; S.party.push(b); a.visible = false; });
      for (const f of opt.foes) { const b = foeBattler(f.id, f.x, f.y, f); if (f.actor) { f.actor.visible = false; b.actor = f.actor; } S.foes.push(b); }
      // camera
      const pts = [...S.foes.map(b => ({ x: b.x, y: b.y - Math.max(0, b.h - 24) })), ...(opt.party || S.party.map(b => ({ x: b.x, y: b.y })))];
      const minx = Math.min(...pts.map(p => p.x)), maxx = Math.max(...pts.map(p => p.x)) + 16, miny = Math.min(...pts.map(p => p.y)) - 24, maxy = Math.max(...pts.map(p => p.y)) + 16;
      // the bottom 75px (world) are covered by the battle windows: center the rest, keeping tall bosses in view
      F.camLock = 1;
      const cx = (minx + maxx) / 2, cy = Math.min((miny + maxy) / 2 + 36, miny + (H / 2 - 75) / 2 + 38);
      const camT = { x: F.clampX(cx - W / 4), y: F.clampY(cy - H / 4) };
      G.se('encounter'); G.bgm(opt.bgm || (opt.boss ? 'boss' : 'battle'), { restart: true });
      fx({ life: 26, screen: 1, draw(c, t) { // radial streak wipe
        const k = t / 26; c.save(); c.globalAlpha = (1 - k) * 0.85; c.strokeStyle = '#ffffff'; c.lineWidth = 2;
        for (let i = 0; i < 28; i++) { const a = i / 28 * Math.PI * 2 + i * 0.3; const r0 = 60 + k * 420, r1 = r0 + 40 + (i % 3) * 30; c.beginPath(); c.moveTo(W / 2 + Math.cos(a) * r0, H / 2 + Math.sin(a) * r0); c.lineTo(W / 2 + Math.cos(a) * r1, H / 2 + Math.sin(a) * r1); c.stroke(); }
        c.globalAlpha = Math.max(0, 0.6 - k * 2); c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, H); c.restore(); } });
      // jump into position
      const sx = F.cam.x, sy = F.cam.y;
      const moves = S.party.map((b, i) => { const p = opt.party && opt.party[i]; return p ? jump(b, p.x, p.y, 22, 14) : null; });
      S.foes.forEach(b => { if (!b.actor) { b.alpha = 0; } });
      for (let i = 1; i <= 24; i++) { const t = G.ease(i / 24); F.cam.x = G.lerp(sx, camT.x, t); F.cam.y = G.lerp(sy, camT.y, t); S.foes.forEach(b => { if (!b.actor) b.alpha = t; }); await G.wait(1); }
      await Promise.all(moves.filter(Boolean));
      S.party.forEach(b => { b.hx = b.x; b.hy = b.y; faceTowardFoes(b); });
      S.foes.forEach(b => { b.hx = b.x; b.hy = b.y; });
      if (opt.boss) {
        const main = S.foes.find(f => f.main) || S.foes[0];
        S.bossBanner = { name: main.name, t: 0 };
        G.se('stamp'); await wait(80); S.bossBanner = null;
      }
      if (opt.intro) await opt.intro(S);
      if (!G.flags.tutBattle) {
        G.flags.tutBattle = 1;
        await G.say(null, G.QUEST ? '名前の横のゲージがたまった仲間から、行動を選べます。|技には「直線」「円」「全体」などの範囲があります。対象を選ぶとき、巻きこむ範囲が地面に光って見えます。敵がかたまっている所をねらいましょう。|（「決定」で決める、「もどる」でもどる。二人以上の準備がそろうと、連携技が使えることがあります。）' : '名前の横のゲージがたまった仲間から、行動を選べます。|技には「直線」「円」「全体」などの範囲があります。対象を選ぶとき、巻きこむ範囲が地面に光って見えます。敵がかたまっている所をねらいましょう。|（Zで決定、Xでもどる。二人以上の準備がそろうと、連携技が使えることがあります。）');
      }
      S.phase = 'main';
    });
  };
  function faceTowardFoes(b) {
    const fs = alive(S.foes); if (!fs.length) return;
    const cx = fs.reduce((a, f) => a + f.x, 0) / fs.length, cy = fs.reduce((a, f) => a + f.y, 0) / fs.length;
    const dx = cx - b.x, dy = cy - b.y;
    b.dir = Math.abs(dx) > Math.abs(dy) * 1.2 ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
  }
  // Seamless start from a field encounter
  B.startFromField = async function (encIndex) {
    const m = F.map, e = m.def.encounters[encIndex];
    const foes = F.actors.filter(a => a.foe && a.enc === encIndex);
    if (!foes.length) { F.lock = Math.max(0, F.lock - 1); return; }
    const L = F.leader();
    // party positions: given offsets, or placed on the leader's side of the group
    let ppos;
    if (e.party) ppos = e.party.map(([dx, dy]) => ({ x: (e.x + dx) * 16, y: (e.y + dy) * 16 }));
    else {
      // snap the approach to an axis, then line the party up in a row facing the enemies
      const cx = foes.reduce((a, f) => a + f.x, 0) / foes.length, cy = foes.reduce((a, f) => a + f.y, 0) / foes.length;
      const dx = L.x - cx, dy = L.y - cy;
      const horiz = Math.abs(dx) > Math.abs(dy) * 1.3;
      const n = G.party.active.length;
      const spread = n === 1 ? [0] : n === 2 ? [-1, 1] : [0, -2, 2];
      if (!horiz) {
        const below = dy >= 0;
        const edge = below ? Math.max(...foes.map(f => f.y)) : Math.min(...foes.map(f => f.y));
        const ry = edge + (below ? 3 : -3) * 16, rx = G.clamp(L.x, cx - 32, cx + 32);
        ppos = spread.map((k, i) => ({ x: rx + k * 16, y: ry + (i ? (below ? 8 : -8) : 0) }));
      } else {
        const right = dx >= 0;
        const edge = right ? Math.max(...foes.map(f => f.x)) : Math.min(...foes.map(f => f.x));
        const rx = edge + (right ? 3 : -3) * 16, ry = G.clamp(L.y, cy - 24, cy + 24);
        ppos = spread.map((k, i) => ({ x: rx + (i ? (right ? 10 : -10) : 0), y: ry + k * 14 }));
      }
      ppos = ppos.map(p => snapWalkable(p.x, p.y));
      // keep two members from landing on the same tile
      for (let i = 1; i < ppos.length; i++) for (let j = 0; j < i; j++) if (ppos[i].x === ppos[j].x && ppos[i].y === ppos[j].y) ppos[i] = { x: ppos[i].x + 16, y: ppos[i].y };
    }
    G.party.battles++;
    const res = await B.start({ foes: foes.map(a => ({ id: a.foe, x: a.x, y: a.y, actor: a, main: a.boss && a.foe === e.boss })), party: ppos, boss: e.boss, canEscape: !e.boss, enc: encIndex, bgm: e.boss ? 'boss' : 'battle' });
    if (res === 'lose') { await G.gameOver(); return; }
    if (res === 'win' || res === 'escape') {
      F.actors = F.actors.filter(a => !(a.foe && a.enc === encIndex));
      if (e.boss && res === 'win' && G.SCRIPTS['boss_' + e.boss]) await G.runScript('boss_' + e.boss);
    }
  };
  function snapWalkable(x, y) {
    const tx0 = Math.round(x / 16), ty0 = Math.round(y / 16);
    for (let r = 0; r < 4; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
      const tx = tx0 + dx, ty = ty0 + dy;
      if (!F.blocked(tx, ty, null, true)) return { x: tx * 16, y: ty * 16 };
    }
    return { x: tx0 * 16, y: ty0 * 16 };
  }
  B.spawnFoe = function (eid, x, y, opt = {}) { const b = foeBattler(eid, x, y, opt); b.alpha = 0; S.foes.push(b); return b; };

  // ---------------- movement helpers ----------------
  function moveTo(b, x, y, frames) { return new Promise(async r => { const sx = b.x, sy = b.y; b.moving = 1; for (let i = 1; i <= frames; i++) { const t = i / frames; b.x = G.lerp(sx, x, t); b.y = G.lerp(sy, y, t); b.anim += 1.5; await G.wait(1); } b.moving = 0; r(); }); }
  function jump(b, x, y, frames, h) { return new Promise(async r => { const sx = b.x, sy = b.y; for (let i = 1; i <= frames; i++) { const t = i / frames; b.x = G.lerp(sx, x, t); b.y = G.lerp(sy, y, t); b.z = Math.sin(t * Math.PI) * h; await G.wait(1); } b.z = 0; r(); }); }
  function faceTo(b, t) { const dx = t.x - b.x, dy = t.y - b.y; b.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'); }
  const wait = G.wait;

  // ---------------- effects ----------------
  function fx(o) { o.t = 0; S.fx.push(o); return o; }
  function pop(b, text, col = '#ffffff', size = 16) { const c = center(b); S.pops.push({ x: c.x, y: c.y - 6, text: String(text), col, t: 0, size }); }
  const ring = (x, y, r, col, life = 24, w = 2) => fx({ life, draw(c, t) { const k = t / life; c.globalAlpha = 1 - k; c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.ellipse(x, y, r * (0.3 + k * 0.7), r * (0.3 + k * 0.7) * 0.6, 0, 0, Math.PI * 2); c.stroke(); c.globalAlpha = 1; } });
  const sparks = (x, y, col, n = 12, sp = 2, life = 26, grav = 0.05) => { const ps = []; for (let i = 0; i < n; i++) { const a = G.rand() * Math.PI * 2, v = G.rand() * sp + 0.4; ps.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.4 }); } fx({ life, draw(c, t) { c.fillStyle = col; c.globalAlpha = 1 - t / life; for (const p of ps) { p.x += p.vx; p.y += p.vy; p.vy += grav; c.fillRect(Math.round(p.x), Math.round(p.y), 2, 2); } c.globalAlpha = 1; } }); };
  const slash = (x, y, col = '#ffffff', ang = -0.7) => fx({ life: 12, draw(c, t) { const k = t / 12; c.strokeStyle = col; c.globalAlpha = 1 - k; c.lineWidth = 3 - k * 2; c.beginPath(); c.moveTo(x - Math.cos(ang) * 14, y - Math.sin(ang) * 14); c.lineTo(x + Math.cos(ang) * 14 * (0.3 + k), y + Math.sin(ang) * 14 * (0.3 + k)); c.stroke(); c.globalAlpha = 1; } });
  const beam = (x1, y1, x2, y2, col, wdt = 6, life = 26) => fx({ life, draw(c, t) { const k = t / life; c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = (1 - k) * 0.9; c.strokeStyle = col; c.lineWidth = wdt * (1 - k * 0.5); c.lineCap = 'round'; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); c.strokeStyle = '#ffffff'; c.lineWidth = Math.max(1, wdt / 3); c.stroke(); c.restore(); } });
  const bolt = (x, y, col = '#d8e8ff', life = 18) => { const pts = []; let px = x, py = y - 90; while (py < y) { pts.push([px, py]); py += 8 + G.rand() * 6; px += (G.rand() - 0.5) * 12; } pts.push([x, y]); fx({ life, draw(c, t) { c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = t % 4 < 2 ? 1 : 0.4; c.strokeStyle = col; c.lineWidth = 2; c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.stroke(); c.restore(); } }); };
  const blob = (x, y, r, col, life = 22) => fx({ life, draw(c, t) { const k = t / life; c.globalAlpha = 1 - k; c.fillStyle = col; c.beginPath(); c.ellipse(x, y, r * (0.5 + k * 0.6), r * (0.5 + k * 0.6) * 0.7, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1; } });
  const glyph = (x, y, col, life = 30) => fx({ life, draw(c, t) { const k = t / life; c.save(); c.translate(x, y); c.scale(1, 0.5); c.rotate(t / 8); c.globalAlpha = 1 - k; c.strokeStyle = col; c.lineWidth = 1; c.beginPath(); c.arc(0, 0, 16, 0, Math.PI * 2); c.stroke(); for (let i = 0; i < 5; i++) { const a = i * Math.PI * 0.8; c.lineTo(Math.cos(a) * 16, Math.sin(a) * 16); } c.stroke(); c.restore(); } });
  const rise = (x, y, col, n = 10, life = 34) => { const ps = []; for (let i = 0; i < n; i++) ps.push({ x: x + (G.rand() - 0.5) * 18, y: y + 8 - G.rand() * 6, v: 0.4 + G.rand() * 0.6 }); fx({ life, draw(c, t) { c.fillStyle = col; c.globalAlpha = 1 - t / life; for (const p of ps) { p.y -= p.v; c.fillRect(Math.round(p.x), Math.round(p.y), 1, 2); } c.globalAlpha = 1; } }); };
  const fall = (x, y, col, h = 80, life = 14, size = 3) => fx({ life, draw(c, t) { const k = t / life; const yy = y - h * (1 - k); c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = col; c.fillRect(Math.round(x - size / 2), Math.round(yy), size, size); c.globalAlpha = 0.5; c.fillRect(Math.round(x - size / 2 + 1), Math.round(yy - 8), size - 2 || 1, 8); c.restore(); } });
  const wave = (col, life = 40) => fx({ life, screen: 1, draw(c, t) { const k = t / life; c.save(); c.globalAlpha = Math.sin(k * Math.PI) * 0.35; c.fillStyle = col; c.fillRect(0, 0, W, H); c.restore(); } });
  const spike = (x, y, col) => fx({ life: 26, draw(c, t) { const h = Math.min(1, t / 6) * 14 * (t > 18 ? (26 - t) / 8 : 1); c.fillStyle = col; c.beginPath(); c.moveTo(x - 5, y + 4); c.lineTo(x, y + 4 - h); c.lineTo(x + 5, y + 4); c.fill(); c.fillStyle = '#ffffff'; c.globalAlpha = 0.4; c.fillRect(x - 1, y + 4 - h + 2, 1, h - 4 > 0 ? h - 4 : 0); c.globalAlpha = 1; } });
  const swirl = (x, y, col, r = 18, life = 34) => fx({ life, draw(c, t) { c.save(); c.translate(x, y); c.globalAlpha = 1 - t / life; c.strokeStyle = col; c.lineWidth = 1.5; for (let k = 0; k < 3; k++) { c.beginPath(); for (let i = 0; i < 20; i++) { const a = i * 0.45 + t * 0.35 + k * 2.1, rr = i * r / 20; i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr * 0.6 - i * 0.6) : c.moveTo(0, 0); } c.stroke(); } c.restore(); } });

  // ---------------- targeting geometry ----------------
  function areaTargets(user, tech, target, pool) {
    const P = alive(pool);
    const a = tech.area;
    if (a === 'single' || a === 'ally') return target ? [target] : [];
    if (a === 'all' || a === 'allies') return P;
    if (a === 'self') return [user];
    if (a === 'circleT') { const c0 = center(target); return P.filter(b => { const c = center(b); return Math.hypot(c.x - c0.x, (c.y - c0.y) * 1.3) <= (tech.r || 30) + 4 || b === target; }); }
    if (a === 'circleS') { const c0 = center(user); return P.filter(b => { const c = center(b); return Math.hypot(c.x - c0.x, (c.y - c0.y) * 1.3) <= (tech.r || 40) + 4; }); }
    if (a === 'line') {
      const c0 = center(user), c1 = center(target); let dx = c1.x - c0.x, dy = c1.y - c0.y; const L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
      return P.filter(b => { const c = center(b); const px = c.x - c0.x, py = c.y - c0.y; const proj = px * dx + py * dy; const perp = Math.abs(px * dy - py * dx); return (proj > 0 && proj < L + 120 && perp < 13 + (b.w ? b.w / 5 : 4)) || b === target; });
    }
    return target ? [target] : [];
  }
  B.areaTargets = areaTargets;

  // ---------------- applying results ----------------
  async function hurt(t, r, opt = {}) {
    if (!t.alive && !opt.force) return;
    if (r.miss) { pop(t, 'MISS', '#c8c8d8'); G.se('miss'); return; }
    if (r.immune) { pop(t, '無効', '#a8a8c0'); return; }
    t.hp = Math.max(0, t.hp - r.dmg);
    t.flash = 10; if (t.st.sleep) { delete t.st.sleep; }
    pop(t, r.dmg, r.crit ? '#ffe068' : r.weak ? '#ffb0a0' : '#ffffff', r.crit ? 20 : 16);
    if (r.weak) setTimeout(() => S && pop(t, 'よわい！', '#ff9a8a', 12), 120);
    if (t.side === 'party') { t.pose = 'hurt'; t.kb = 6; }
    if (r.crit) { G.se('crit'); G.doShake(6); }
    if (t.hp <= 0) await kill(t);
    else if (t.side === 'party') setTimeout(() => { if (t.alive && t.pose === 'hurt') t.pose = null; }, 300);
  }
  async function kill(t) {
    t.alive = false; t.atb = 0; t.st = {};
    S.ready = S.ready.filter(b => b !== t);
    if (t.side === 'party') { t.pose = 'ko'; G.se('ko'); if (S.menu && S.menu.b === t) S.menu = null; }
    else {
      G.se('enemyDie'); S.deadFoes.push(t);
      const c = center(t); sparks(c.x, c.y, '#ffffff', 16, 1.6, 30, -0.02);
      for (let i = 0; i < 16; i++) { t.alpha = 1 - i / 16; t.dissolve = i; await wait(1); }
      t.alpha = 0;
      if (S.opt.onFoeDeath) await S.opt.onFoeDeath(t, S);
      if (t.main) for (const p of alive(S.foes)) { p.hp = 0; kill(p); }
    }
  }
  function heal(t, n) { if (!t.alive) return; t.hp = Math.min(t.maxhp, t.hp + n); pop(t, n, '#9af0b0'); }
  function addStatus(t, st, chance = 1) {
    if (!t.alive) return false;
    if (t.side === 'party' && t.stats.immune.includes(st)) { pop(t, '無効', '#a8a8c0', 12); return false; }
    if (t.side === 'foe' && t.ed.boss && ['stop', 'sleep'].includes(st)) { pop(t, '無効', '#a8a8c0', 12); return false; }
    if (G.rand() > chance) return false;
    t.st[st] = ST_DUR[st];
    if (st === 'haste') delete t.st.slow; if (st === 'slow') delete t.st.haste;
    pop(t, ST_NAME[st], ['haste', 'guard'].includes(st) ? '#9ad8ff' : '#d8a0ff', 12);
    if (st === 'poison') G.se('poison'); if (st === 'stop') G.se('freeze');
    return true;
  }

  // ---------------- technique animations ----------------
  // each returns after visuals; `hit()` applies the effect to all targets
  const ECOL = D.ELEMCOL;
  async function homeAll(list) { await Promise.all(list.map(b => (Math.abs(b.x - b.hx) + Math.abs(b.y - b.hy) > 1) ? moveTo(b, b.hx, b.hy, 10) : null)); list.forEach(b => { b.pose = b.alive ? null : 'ko'; }); }
  async function approach(a, t, frames = 12) { const c = { x: t.x, y: t.y }; const side = a.x < t.x ? -1 : 1; faceTo(a, t); await moveTo(a, t.x + side * (t.w ? Math.max(14, t.w / 2) : 14), t.y + 2, frames); faceTo(a, t); }
  const FX = {
    async basic(ctx) { const { a, tgts, hit } = ctx; const t = tgts[0]; if (a.side === 'party') { await approach(a, t); a.pose = a.x < t.x ? 'attackR' : 'attackL'; G.se('swing'); const c = center(t); slash(c.x, c.y, '#ffffff'); await wait(4); await hit(); await wait(10); await homeAll([a]); } else { await lunge(a, t); G.se('hit'); const c = center(t); slash(c.x, c.y, '#ff8a8a', 0.7); await hit(); await wait(8); } },
    async dash(ctx) { const { a, tgts, hit, target } = ctx; const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; const ex = a.x + dx / L * (L + 40), ey = a.y + dy / L * (L + 40); faceTo(a, target); a.pose = dx > 0 ? 'attackR' : 'attackL'; G.se('wind'); beam(c0.x, c0.y, c0.x + dx / L * (L + 40), c0.y + dy / L * (L + 40), ECOL.wind, 4, 20); await moveTo(a, ex, ey, 8); for (const t of tgts) { const c = center(t); slash(c.x, c.y, ECOL.wind); } await hit(); await wait(12); a.pose = null; await jump(a, a.hx, a.hy, 16, 12); },
    async whirl(ctx) { const { a, hit, target, tech } = ctx; const c1 = center(target); await jump(a, target.x, target.y - 4, 14, 22); const dirs = ['down', 'left', 'up', 'right']; G.se('wind'); for (let i = 0; i < 12; i++) { a.dir = dirs[i % 4]; if (i % 3 === 0) ring(c1.x, c1.y + 6, tech.r || 30, ECOL[tech.elem] || ECOL.wind, 20); await wait(2); } swirl(c1.x, c1.y, ECOL[tech.elem] || ECOL.wind, tech.r || 30); await hit(); await wait(8); await jump(a, a.hx, a.hy, 14, 16); },
    async multi(ctx) { const { a, hit, target } = ctx; await approach(a, target, 8); for (let i = 0; i < 3; i++) { a.pose = i % 2 ? 'attackL' : 'attackR'; G.se('swing'); const c = center(target); slash(c.x + (i - 1) * 4, c.y, i === 2 ? '#ffe068' : '#ffffff', -0.7 + i * 0.7); await hit(i); await wait(7); } await homeAll([a]); },
    async tornado(ctx) { const { a, tgts, hit } = ctx; a.pose = 'cast'; G.se('cast'); await wait(14); G.se('wind'); for (const t of tgts) { const c = center(t); swirl(c.x, c.y + 8, ECOL.wind, 22, 40); } await wait(20); await hit(); await wait(14); a.pose = null; },
    async heal(ctx) { const { a, tgts, hit } = ctx; a.pose = 'cast'; G.se('cast'); const c0 = center(a); glyph(c0.x, c0.y + 12, '#ffe68a'); await wait(16); G.se('heal'); for (const t of tgts) { const c = center(t); rise(c.x, c.y, '#9af0b0', 14); sparks(c.x, c.y, '#fff4c0', 8, 1, 24, -0.03); } await hit(); await wait(16); a.pose = null; },
    async revive(ctx) { const { a, tgts, hit } = ctx; a.pose = 'cast'; G.se('cast'); await wait(14); G.se('heal'); for (const t of tgts) { const c = center(t); beam(c.x, c.y - 90, c.x, c.y + 10, '#fff4c0', 10, 36); } await wait(14); await hit(); await wait(16); a.pose = null; },
    async beam(ctx) { const { a, hit, target, tech } = ctx; a.pose = 'cast'; G.se('cast'); faceTo(a, target); await wait(12); const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('light'); beam(c0.x, c0.y, c0.x + dx / L * (L + 120), c0.y + dy / L * (L + 120), ECOL[tech.elem] || ECOL.light, 7, 28); await wait(6); await hit(); await wait(18); a.pose = null; },
    async stars(ctx) { const { a, hit, target, tech } = ctx; a.pose = 'cast'; G.se('cast'); await wait(12); const c1 = center(target); ring(c1.x, c1.y + 8, tech.r, ECOL.light, 30); for (let i = 0; i < 12; i++) { fall(c1.x + (G.rand() - 0.5) * tech.r * 1.6, c1.y + (G.rand() - 0.5) * tech.r * 0.8, '#fff4a0', 90, 12); if (i % 3 === 0) G.se('light'); await wait(2); } await hit(); await wait(14); a.pose = null; },
    async meteor(ctx) { const { a, tgts, hit } = ctx; a.pose = 'cast'; G.se('cast'); await wait(16); wave('#20184a', 60); for (let i = 0; i < 18; i++) { const t = tgts[i % tgts.length]; if (!t) break; const c = center(t); fall(c.x + (G.rand() - 0.5) * 20, c.y + (G.rand() - 0.5) * 10, '#ffe68a', 140, 16, 4); if (i % 4 === 0) G.se('boom'); await wait(3); } G.doShake(14); await hit(); await wait(14); a.pose = null; },
    async heavy(ctx) { const { a, hit, target } = ctx; await approach(a, target, 10); await jump(a, a.x, a.y, 16, 22); a.pose = a.x < target.x ? 'attackR' : 'attackL'; G.se('crit'); G.doShake(6); const c = center(target); sparks(c.x, c.y, '#ffe068', 12, 2.4); await hit(); await wait(10); await homeAll([a]); },
    async quake(ctx) { const { a, hit, tech } = ctx; await jump(a, a.x, a.y, 16, 18); G.se('earth'); G.doShake(16); const c = center(a); ring(c.x, c.y + 10, tech.r || 40, ECOL.earth, 30, 3); for (let i = 0; i < 8; i++) { const ang = i / 8 * Math.PI * 2; spike(c.x + Math.cos(ang) * (tech.r || 40) * 0.7, c.y + 10 + Math.sin(ang) * (tech.r || 40) * 0.4, '#b88a5a'); } await hit(); await wait(16); },
    async spikes(ctx) { const { a, hit, target } = ctx; a.pose = 'cast'; faceTo(a, target); await wait(8); const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('earth'); for (let d = 16; d < L + 80; d += 12) { spike(c0.x + dx / L * d, c0.y + 12 + dy / L * d, '#b88a5a'); await wait(1); } G.doShake(8); await hit(); await wait(14); a.pose = null; },
    async bigquake(ctx) { const { a, tgts, hit } = ctx; await jump(a, a.x, a.y, 20, 28); G.se('earth'); G.se('boom'); G.doShake(26); for (const t of tgts) { const c = center(t); for (let k = 0; k < 3; k++) spike(c.x - 8 + k * 8, c.y + 10, '#b88a5a'); sparks(c.x, c.y + 6, '#c8a070', 10, 2); } await hit(); await wait(18); },
    async zap(ctx) { const { a, hit, target } = ctx; a.pose = 'cast'; G.se('cast'); await wait(10); const c = center(target); G.se('thunder'); bolt(c.x, c.y + 6); G.doFlash('#e8f0ff', 0.3, 0.06); await wait(4); await hit(); await wait(14); a.pose = null; },
    async scan(ctx) { const { a, target } = ctx; a.pose = 'cast'; G.se('cast'); const c = center(target); for (let i = 0; i < 3; i++) { ring(c.x, c.y, 18, '#7af0ff', 16, 1); await wait(6); } a.pose = null; const ed = target.ed; const weak = Object.entries(ed.weak || {}).filter(([k, v]) => v > 1).map(([k]) => D.ELEM[k]).join('・') || 'なし'; S.msg = { text: `${ed.name}　HP ${target.hp}/${target.maxhp}　弱点：${weak}`, t: 160 }; target.scanned = 1; await wait(30); },
    async net(ctx) { const { a, hit, target, tech } = ctx; a.pose = 'cast'; G.se('cast'); await wait(10); const c = center(target); G.se('thunder'); for (let i = 0; i < 6; i++) { const ang = i / 6 * Math.PI * 2; bolt(c.x + Math.cos(ang) * tech.r * 0.7, c.y + 8 + Math.sin(ang) * tech.r * 0.4, '#a8c8ff', 14); } ring(c.x, c.y + 8, tech.r, ECOL.thunder, 24); await wait(6); await hit(); await wait(12); a.pose = null; },
    async rail(ctx) { const { a, hit, target } = ctx; a.pose = 'cast'; G.se('cast'); faceTo(a, target); await wait(16); const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('thunder'); G.doFlash('#e8f0ff', 0.4); beam(c0.x, c0.y, c0.x + dx / L * (L + 160), c0.y + dy / L * (L + 160), '#a8c8ff', 10, 30); await wait(5); await hit(); await wait(20); a.pose = null; },
    async buff(ctx) { const { a, tgts, hit } = ctx; a.pose = 'cast'; G.se('cast'); await wait(12); G.se('heal'); for (const t of tgts) { const c = center(t); ring(c.x, c.y + 10, 14, '#9ad8ff', 24); rise(c.x, c.y, '#9ad8ff', 8); } await hit(); await wait(14); a.pose = null; },
    // ----- combos -----
    async lightwhirl(ctx) { const { users, hit, target, tech } = ctx; const [h, m] = users; m.pose = 'cast'; G.se('cast'); const c1 = center(target); const c0 = center(m); beam(c0.x, c0.y, c1.x, c1.y, ECOL.light, 5, 20); await wait(10); await jump(h, target.x, target.y - 4, 12, 22); G.se('wind'); G.se('light'); const dirs = ['down', 'left', 'up', 'right']; for (let i = 0; i < 16; i++) { h.dir = dirs[i % 4]; if (i % 4 === 0) ring(c1.x, c1.y + 6, tech.r, ECOL.light, 22, 3); await wait(2); } swirl(c1.x, c1.y, '#fff4a0', tech.r, 40); sparks(c1.x, c1.y, '#fff4a0', 24, 3); await hit(); await wait(12); m.pose = null; await jump(h, h.hx, h.hy, 14, 16); },
    async galespear(ctx) { const { users, hit, target } = ctx; const [h, s] = users; s.pose = 'cast'; faceTo(s, target); await wait(8); const c0 = center(s), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('earth'); for (let d = 16; d < L + 80; d += 10) { spike(c0.x + dx / L * d, c0.y + 12 + dy / L * d, '#b88a5a'); await wait(1); } G.se('wind'); h.pose = dx > 0 ? 'attackR' : 'attackL'; const hc = center(h); beam(hc.x, hc.y, c1.x + dx / L * 60, c1.y + dy / L * 60, ECOL.wind, 6, 20); await moveTo(h, target.x + dx / L * 40, target.y + dy / L * 40, 8); G.doShake(12); await hit(); await wait(12); s.pose = null; h.pose = null; await jump(h, h.hx, h.hy, 14, 14); },
    async raijin(ctx) { const { users, hit, target } = ctx; const [h, p] = users; p.pose = 'cast'; G.se('thunder'); const hc = center(h); bolt(hc.x, hc.y + 8, '#a8c8ff'); await wait(10); const c1 = center(target); const dx = c1.x - hc.x, dy = c1.y - hc.y, L = Math.hypot(dx, dy) || 1; h.pose = dx > 0 ? 'attackR' : 'attackL'; beam(hc.x, hc.y, hc.x + dx / L * (L + 60), hc.y + dy / L * (L + 60), '#a8c8ff', 7, 26); G.se('wind'); await moveTo(h, h.x + dx / L * (L + 40), h.y + dy / L * (L + 40), 7); for (const t of ctx.tgts) { const c = center(t); bolt(c.x, c.y, '#d8e8ff', 12); } G.doFlash('#e8f0ff', 0.3); await hit(); await wait(12); p.pose = null; h.pose = null; await jump(h, h.hx, h.hy, 14, 14); },
    async sanctuary(ctx) { const { users, tgts, hit } = ctx; users.forEach(u => u.pose = 'cast'); G.se('cast'); for (const u of users) { const c = center(u); glyph(c.x, c.y + 12, '#ffe68a', 40); } await wait(18); G.se('heal'); for (const t of tgts) { const c = center(t); beam(c.x, c.y - 70, c.x, c.y + 10, '#fff4c0', 8, 30); rise(c.x, c.y, '#9af0b0', 12); } await hit(); await wait(18); users.forEach(u => u.pose = null); },
    async prism(ctx) { const { users, tgts, hit } = ctx; users.forEach(u => u.pose = 'cast'); G.se('cast'); await wait(12); const cols = ['#ff7a7a', '#ffb060', '#ffe68a', '#9af0b0', '#7ab8ff', '#b08aff']; const c0 = center(users[0]); G.se('light'); for (let i = 0; i < tgts.length * 2; i++) { const t = tgts[i % tgts.length]; const c = center(t); beam(c0.x, c0.y, c.x, c.y, cols[i % cols.length], 5, 24); await wait(3); } G.se('thunder'); await hit(); await wait(16); users.forEach(u => u.pose = null); },
    async thunderquake(ctx) { const { users, hit, tech } = ctx; const [s, p] = users; p.pose = 'cast'; G.se('thunder'); const c = center(s); bolt(c.x, c.y + 10, '#a8c8ff'); await wait(8); await jump(s, s.x, s.y, 16, 20); G.se('earth'); G.doShake(18); for (let i = 0; i < 10; i++) { const ang = i / 10 * Math.PI * 2; bolt(c.x + Math.cos(ang) * tech.r * 0.8, c.y + 10 + Math.sin(ang) * tech.r * 0.45, '#a8c8ff', 16); } ring(c.x, c.y + 10, tech.r, ECOL.thunder, 30, 3); await hit(); await wait(14); p.pose = null; },
    async postmark(ctx) { const { users, tgts, hit } = ctx; users.forEach(u => u.pose = 'cast'); G.se('cast'); G.bgmDuck && G.bgmDuck(); await wait(10); wave('#ffe68a', 50); for (const u of users) { const c = center(u); glyph(c.x, c.y + 12, '#ffe68a', 50); } G.se('stamp'); await wait(24); for (const t of tgts) { const c = center(t); fx({ life: 36, draw(cx, tt) { const k = Math.min(1, tt / 10); cx.save(); cx.translate(c.x, c.y); cx.globalAlpha = tt > 26 ? (36 - tt) / 10 : 1; cx.strokeStyle = '#c9473d'; cx.lineWidth = 2; cx.beginPath(); cx.arc(0, 0, 20 + (1 - k) * 30, 0, Math.PI * 2); cx.stroke(); cx.beginPath(); cx.arc(0, 0, 14 + (1 - k) * 20, 0, Math.PI * 2); cx.stroke(); for (let i = -1; i <= 1; i++) { cx.beginPath(); cx.moveTo(-26, i * 6); cx.lineTo(26, i * 6); cx.stroke(); } cx.restore(); } }); } G.se('stamp'); G.doShake(16); G.doFlash('#fff4c0', 0.6); await wait(8); await hit(); await wait(20); users.forEach(u => u.pose = null); },
    async expressmeteor(ctx) { const { users, tgts, hit } = ctx; users.forEach(u => u.pose = 'cast'); G.se('cast'); wave('#10082a', 80); await wait(16); for (let i = 0; i < 30; i++) { const t = tgts[i % tgts.length]; const c = center(t); fall(c.x + (G.rand() - 0.5) * 30, c.y + (G.rand() - 0.5) * 14, i % 2 ? '#ffe68a' : '#a8c8ff', 160, 12, 5); if (i % 5 === 0) G.se('boom'); await wait(2); } G.doShake(24); G.doFlash('#ffffff', 0.7); await hit(); await wait(20); users.forEach(u => u.pose = null); },
    // ----- enemy techs -----
    async ink(ctx) { const { a, hit, target, tech } = ctx; await lunge(a, target, 6); const c = center(target); G.se('splash'); blob(c.x, c.y + 6, tech.r || 26, 'rgba(30,40,90,0.75)', 26); for (let i = 0; i < 8; i++) sparks(c.x, c.y, '#2a3a8a', 2, 2); await hit(); await wait(10); },
    async fireline(ctx) { const { a, hit, target } = ctx; const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('fire'); for (let d = 10; d < L + 60; d += 8) { blob(c0.x + dx / L * d, c0.y + dy / L * d, 8, 'rgba(255,120,40,0.8)', 18); await wait(1); } await hit(); await wait(10); },
    async fireball(ctx) { const { a, hit, target } = ctx; const c0 = center(a), c1 = center(target); G.se('fire'); for (let i = 0; i <= 12; i++) { const t = i / 12; blob(G.lerp(c0.x, c1.x, t), G.lerp(c0.y, c1.y, t) - Math.sin(t * Math.PI) * 16, 5, 'rgba(255,140,40,0.9)', 8); await wait(1); } sparks(c1.x, c1.y, '#ffb040', 12, 2); await hit(); await wait(8); },
    async spores(ctx) { const { a, hit, target, tech } = ctx; G.se('poison'); const c = center(target); for (let i = 0; i < 18; i++) { blob(c.x + (G.rand() - 0.5) * tech.r * 2, c.y + (G.rand() - 0.5) * tech.r, 3, 'rgba(255,230,120,0.8)', 30); await wait(1); } await hit(); await wait(10); },
    async spin(ctx) { const { a, hit, tech } = ctx; const c = center(a); G.se('gear'); for (let i = 0; i < 3; i++) { ring(c.x, c.y + 8, tech.r, '#c8c8d0', 18); await wait(5); } await hit(); await wait(8); },
    async still(ctx) { const { a, hit, target } = ctx; await lunge(a, target, 8); const c = center(target); G.se('freeze'); ring(c.x, c.y, 20, '#e8e8f8', 30); await hit(); await wait(10); },
    async stillwave(ctx) { const { hit } = ctx; G.se('dark'); wave('#d8d8f0', 50); for (const t of alive(S.party)) { const c = center(t); ring(c.x, c.y + 8, 22, '#e8e8f8', 36); } await wait(20); await hit(); await wait(12); },
    async laser(ctx) { const { a, hit, target } = ctx; const c0 = center(a), c1 = center(target); const dx = c1.x - c0.x, dy = c1.y - c0.y, L = Math.hypot(dx, dy) || 1; G.se('cast'); await wait(8); G.se('thunder'); beam(c0.x, c0.y, c0.x + dx / L * (L + 100), c0.y + dy / L * (L + 100), '#ff6a5a', 4, 22); await hit(); await wait(12); },
    async mist(ctx) { const { hit } = ctx; G.se('ice'); wave('#c8e0ff', 50); for (const t of alive(S.party)) { const c = center(t); blob(c.x, c.y, 20, 'rgba(220,240,255,0.5)', 40); } await wait(16); await hit(); await wait(10); },
    async swing(ctx) { const { a, hit, target } = ctx; const c0 = center(a), c1 = center(target); G.se('swing'); beam(c0.x, c0.y, c1.x + (c1.x - c0.x) * 0.5, c1.y + (c1.y - c0.y) * 0.5, '#e2b04a', 5, 18); await hit(); await wait(10); },
    async bubble(ctx) { const { a, hit, target, tech } = ctx; const c = center(target); G.se('splash'); for (let i = 0; i < 10; i++) { ring(c.x + (G.rand() - 0.5) * tech.r * 1.4, c.y + (G.rand() - 0.5) * tech.r * 0.7, 6, '#bff0ff', 20, 1); await wait(2); } await hit(); await wait(8); },
    async wax(ctx) { const { a, hit, target, tech } = ctx; const c = center(target); G.se('fire'); for (let i = 0; i < 8; i++) { fall(c.x + (G.rand() - 0.5) * tech.r * 1.5, c.y + (G.rand() - 0.5) * tech.r * 0.6, '#d84a3a', 70, 12, 4); await wait(2); } blob(c.x, c.y + 8, tech.r, 'rgba(200,60,50,0.6)', 30); await hit(); await wait(10); },
    async swirl(ctx) { const { a, hit } = ctx; G.se('dark'); const c = center(a); swirl(c.x, c.y, '#ffd060', 60, 40); for (const t of alive(S.party)) { const cc = center(t); swirl(cc.x, cc.y, '#ffb0a0', 16, 30); } await wait(16); await hit(); await wait(10); },
    async ash(ctx) { const { hit } = ctx; G.se('fire'); wave('#ff8a40', 40); for (const t of alive(S.party)) { const c = center(t); for (let i = 0; i < 3; i++) blob(c.x + (G.rand() - 0.5) * 16, c.y, 10, 'rgba(90,80,80,0.7)', 30); } await wait(14); await hit(); await wait(10); },
    async chime(ctx) { const { a, hit } = ctx; G.se('letter'); G.se('thunder'); const c = center(a); for (let i = 0; i < 3; i++) { ring(c.x, c.y, 60 + i * 30, '#e2b04a', 30, 2); await wait(6); } for (const t of alive(S.party)) { const cc = center(t); bolt(cc.x, cc.y + 6); } G.doFlash('#ffe8a0', 0.4); await hit(); await wait(12); },
    async erase(ctx) { const { a, hit, target } = ctx; const c = center(target); G.se('dark'); fx({ life: 40, draw(cx, t) { cx.globalAlpha = Math.sin(t / 40 * Math.PI); cx.fillStyle = '#f4f0e8'; cx.fillRect(c.x - 14, c.y - 18, 28, 36); cx.globalAlpha = 1; } }); await wait(20); await hit(); await wait(14); },
    async unsaid(ctx) { const { a, hit } = ctx; G.se('dark'); wave('#05060c', 70); for (let i = 0; i < 20; i++) { const t = alive(S.party)[i % Math.max(1, alive(S.party).length)]; if (!t) break; const c = center(t); fall(c.x + (G.rand() - 0.5) * 30, c.y, '#efe6d2', 90, 16, 4); await wait(2); } await hit(); await wait(16); },
    async alarm(ctx) { const { a, hit } = ctx; G.se('buzz'); const c = center(a); ring(c.x, c.y, 24, '#ff4040', 20); await wait(10); ring(c.x, c.y, 24, '#ff4040', 20); await hit(); await wait(10); },
    async bite(ctx) { const { a, hit, target } = ctx; await lunge(a, target); G.se('hit'); const c = center(target); slash(c.x - 4, c.y, '#ffffff', 0.9); slash(c.x + 4, c.y, '#ffffff', -0.9); await hit(); await wait(8); },
    async slash(ctx) { const { a, hit, target } = ctx; await lunge(a, target); G.se('swing'); const c = center(target); slash(c.x, c.y, '#ffd0d0', -0.5); await hit(); await wait(8); },
    async swoop(ctx) { const { a, hit, target } = ctx; const sx = a.x, sy = a.y; await jump(a, target.x, target.y - 6, 12, 18); G.se('hit'); await hit(); await jump(a, sx, sy, 12, 18); },
  };
  async function lunge(a, t, frames = 8) { const sx = a.x, sy = a.y; const dx = t.x - a.x, dy = t.y - a.y, L = Math.hypot(dx, dy) || 1; const d = Math.min(L - 18, 40); if (d > 0) await moveTo(a, a.x + dx / L * d, a.y + dy / L * d, frames); await wait(2); setTimeout(() => { }, 0); a._ret = [sx, sy]; }
  async function retFoe(a) { if (a._ret) { await moveTo(a, a._ret[0], a._ret[1], 10); a._ret = null; } }

  // ---------------- executing actions ----------------
  async function execute(act) {
    const a = act.actor;
    if (!a.alive && act.kind !== 'combo') return;
    if (act.kind === 'combo' && act.users.some(u => !u.alive)) { act.users.forEach(u => { u.queued = 0; }); return; }
    S.current = act;
    if (act.kind === 'attack') {
      let t = act.target; if (!t || !t.alive) t = pickAlive(a.side === 'party' ? S.foes : S.party, a); if (!t) return;
      await FX.basic({ a, tgts: [t], target: t, hit: async () => { await hurt(t, B.calc(a, t, { kind: 'phys', power: 1 })); counter(t, a, 'phys'); } });
    } else if (act.kind === 'tech' || act.kind === 'combo') {
      const tech = act.tech, users = act.users || [a];
      for (const u of users) { const cost = act.kind === 'combo' ? tech.mp[u.id] : tech.mp; u.mp = Math.max(0, u.mp - cost); }
      S.label = { text: tech.name, t: 70, combo: act.kind === 'combo' };
      if (act.kind === 'combo') { S.cutin = { users: users.map(u => u.id), name: tech.name, t: 0 }; G.se('ok'); await wait(46); S.cutin = null; }
      const pool = ['heal', 'revive', 'buff', 'cure'].includes(tech.kind) ? S.party : S.foes;
      let target = act.target;
      if (tech.area === 'single' || tech.area === 'line' || tech.area === 'circleT') { if (!target || !target.alive) target = pickAlive(S.foes, a); if (!target) return; }
      if (tech.kind === 'revive') { if (!target || target.alive) { pop(a, '効果なし', '#a8a8c0'); return; } }
      else if ((tech.area === 'ally') && (!target || !target.alive)) { target = pickAlive(S.party, a, true); }
      const tgts = tech.kind === 'revive' ? [target] : areaTargets(users[0], tech, target, pool);
      const hit = async (hitIdx = 0) => {
        if (tech.kind === 'phys' || tech.kind === 'mag') {
          const ps = tgts.map((t, i) => (async () => { await wait(i * 2); const r = B.calc(users.length > 1 ? bestAttacker(users, tech) : a, t, tech); if (!t.alive) return; await hurt(t, r); if (!r.miss && tech.debuff) addStatus(t, tech.debuff, tech.chance || 1); if (!r.miss) counter(t, a, tech.kind); })());
          await Promise.all(ps);
        } else if (tech.kind === 'heal') {
          for (const t of tgts) { heal(t, B.healAmount(users.length > 1 ? users[0] : a, tech.power)); if (tech.cure) cureBad(t); if (tech.status) addStatus(t, tech.status); }
        } else if (tech.kind === 'revive') { const t = tgts[0]; t.alive = true; t.hp = Math.max(1, Math.round(t.maxhp * tech.power)); t.pose = null; t.atb = 0; pop(t, t.hp, '#9af0b0'); }
        else if (tech.kind === 'buff') { for (const t of tgts) addStatus(t, tech.status); }
        else if (tech.kind === 'cure') { for (const t of tgts) cureBad(t, true); }
      };
      const fxName = tech.fx in FX ? tech.fx : 'basic';
      await FX[fxName]({ a, users, tgts, target, tech, hit });
      if (tech.hits) { } // handled inside multi
      await homeAll(users);
    } else if (act.kind === 'item') {
      const it = D.ITEMS[act.item]; G.removeItem(act.item, 1);
      S.label = { text: it.name, t: 60 };
      const tgts = it.target === 'allies' ? alive(S.party) : [act.target];
      a.pose = 'cast'; G.se('cast'); await wait(10); G.se('heal');
      for (const t of tgts) {
        const c = center(t); rise(c.x, c.y, '#9af0b0', 12);
        const e = it.eff;
        if (e.revive && !t.alive) { t.alive = true; t.hp = Math.max(1, Math.round(t.maxhp * e.revive)); t.pose = null; t.atb = 0; pop(t, t.hp, '#9af0b0'); if (e.mp) { t.mp = t.maxmp; } continue; }
        if (!t.alive) { pop(t, '効果なし', '#a8a8c0', 12); continue; }
        if (e.hp) heal(t, Math.min(e.hp, t.maxhp - t.hp));
        if (e.mp) { const n = Math.min(e.mp, t.maxmp - t.mp); t.mp += n; setTimeout(() => S && pop(t, n, '#9ad8ff'), 150); }
        if (e.cure) cureBad(t, true);
      }
      await wait(16); a.pose = null;
    } else if (act.kind === 'flee') {
      await doFlee(a);
    } else if (act.kind === 'enemy') {
      await enemyAct(a, act);
    }
    S.current = null;
  }
  function bestAttacker(users, tech) { // combos use the strongest relevant stat of the group
    let best = users[0], v = -1;
    for (const u of users) { const s = attStats(u); const x = tech.kind === 'phys' ? s.atk : s.mag; if (x > v) { v = x; best = u; } }
    return { ...best, side: 'party', stats: Object.assign({}, best.stats, { atk: Math.round(best.stats.atk * 1.1), matk: Math.round(best.stats.matk * 1.1) }), st: best.st };
  }
  function cureBad(t, show) { let any = false; for (const k of ['poison', 'sleep', 'slow', 'stop', 'defdown']) if (t.st[k]) { delete t.st[k]; any = true; } if (any && show) pop(t, '回復', '#9af0b0', 12); }
  function pickAlive(list, a, lowest) { const al = alive(list); if (!al.length) return null; if (lowest) return al.sort((x, y) => x.hp / x.maxhp - y.hp / y.maxhp)[0]; return al[G.ri(0, al.length - 1)]; }
  function counter(t, a, kind) {
    if (t.side !== 'foe' || !t.alive || !t.ed.boss) return;
    if (t.ed.ai === 'geargolem' && kind === 'phys' && G.rand() < 0.22 && !S.queue.some(q => q.actor === t)) S.queue.push({ kind: 'enemy', actor: t, tech: 'punch', target: a.side === 'party' ? a : null, counter: 1 });
  }
  async function doFlee(a) {
    S.flees++;
    const ps = alive(S.party), fs = alive(S.foes);
    const sp = ps.reduce((s, b) => s + b.stats.spd, 0) / ps.length, fsp = fs.reduce((s, b) => s + b.ed.spd, 0) / Math.max(1, fs.length);
    const chance = G.clamp(0.45 + (sp - fsp) * 0.04 + S.flees * 0.15, 0.2, 0.95);
    G.se('run');
    for (const b of ps) b.dir = { left: 'right', right: 'left', up: 'down', down: 'up' }[b.dir];
    await wait(16);
    if (G.rand() < chance) { S.phase = 'escape'; S.msg = { text: 'うまく逃げきった！', t: 80 }; await Promise.all(ps.map(b => moveTo(b, b.x + (b.x - fs[0].x) * 0.3, b.y + (b.y - fs[0].y) * 0.3, 18))); await finish('escape'); }
    else { S.msg = { text: '逃げられなかった！', t: 80 }; ps.forEach(b => faceTowardFoes(b)); }
  }

  // ---------------- enemy AI ----------------
  function wpick(list) { const tot = list.reduce((s, x) => s + x[1], 0); let r = G.rand() * tot; for (const [k, w] of list) { if ((r -= w) <= 0) return k; } return list[0][0]; }
  function enemyChoose(e) {
    e.turns++;
    const ai = e.ed.ai;
    let tech = wpick(e.ed.acts);
    if (ai === 'waxseal') { tech = e.turns % 4 === 0 ? 'swirl' : (e.hp < e.maxhp / 2 && G.rand() < 0.5) ? 'waxdrip' : wpick([['attack', 3], ['waxdrip', 2]]); }
    if (ai === 'ashgram') { const claws = alive(S.foes).filter(f => f.ed.ai === 'ashclaw').length; tech = e.turns % 3 === 0 ? 'ashbreath' : claws ? 'bite' : wpick([['devour', 1], ['bite', 2], ['ashbreath', 1]]); }
    if (ai === 'geargolem') { if (e.hp < e.maxhp * 0.4 && !e.overclocked) { e.overclocked = 1; tech = 'overclock'; } else tech = e.turns % 4 === 0 ? 'chime' : wpick([['attack', 2], ['punch', 2]]); }
    if (ai === 'queen') { tech = e.turns % 3 === 0 ? 'stillwave' : wpick([['attack', 2], ['stoptouch', 1], ['stillwave', 1]]); if (!alive(S.foes).some(f => f.ed.ai === 'pendulum')) { e.noPend = (e.noPend || 0) + 1; if (e.noPend >= 6) { e.noPend = 0; tech = 'summon_pend'; } } }
    if (ai === 'shijima1') tech = e.turns % 3 === 0 ? 'stillwave' : wpick([['attack', 2], ['erase', 1], ['stillwave', 1]]);
    if (ai === 'core') tech = e.turns % 2 ? 'stillwave' : 'erase';
    if (ai === 'seal') tech = e.id === 'seal_r' ? (alive(S.foes).some(f => f.ed.ai === 'core' && f.hp < f.maxhp) && e.turns % 3 === 0 ? 'sealheal' : 'sealbeam') : 'sealbeam';
    if (ai === 'nushi') tech = e.turns % 5 === 0 ? 'returnto' : e.hp < e.maxhp * 0.5 && e.turns % 3 === 0 ? 'stampslam' : wpick([['attack', 2], ['stillwave', 1], ['erase', 1], ['stampslam', 1]]);
    if (ai === 'shijima3') tech = e.turns % 4 === 0 ? 'unsaid' : wpick([['attack', 2], ['stillwave', 2], ['erase', 1]]);
    return tech;
  }
  async function enemyAct(e, act) {
    const tid = act.tech;
    if (tid === 'summon_pend') { S.label = { text: '影の振り子', t: 60 }; G.se('dark'); for (const s of [-1, 1]) { const p = B.spawnFoe('pendulum', e.x + s * 72, e.y + 16, { part: 1 }); for (let i = 0; i < 12; i++) { p.alpha = i / 12; await wait(1); } p.alpha = 1; } updateShields(); return; }
    const tech = D.ETECH[tid];
    if (tech.name) S.label = { text: tech.name, t: 60, enemy: 1 };
    let target = act.target && act.target.alive ? act.target : pickAlive(S.party, e);
    if (tech.kind === 'flee') { G.se('run'); for (let i = 0; i < 20; i++) { e.alpha = 1 - i / 20; e.x += 3; await wait(1); } e.alive = false; e.fled = 1; return; }
    if (tech.kind === 'self') { await (FX[tech.fx] || FX.buff)({ a: e, users: [e], tgts: [e], target: e, tech, hit: async () => addStatus(e, tech.status) }); return; }
    if (tech.kind === 'healboss') { const core = alive(S.foes).find(f => f.ed.ai === 'core') || e; G.se('heal'); const c = center(core); rise(c.x, c.y, '#9af0b0', 16); await wait(14); const n = Math.round(core.maxhp * 0.08); core.hp = Math.min(core.maxhp, core.hp + n); pop(core, n, '#9af0b0'); await wait(10); return; }
    if (!target) return;
    const tgts = areaTargets(e, tech, target, S.party);
    const hit = async () => {
      await Promise.all(tgts.map((t, i) => (async () => {
        await wait(i * 2);
        if (tech.kind === 'status') { addStatus(t, tech.status, tech.chance || 1); return; }
        const r = B.calc(e, t, tech); await hurt(t, r);
        if (!r.miss && tech.status) addStatus(t, tech.status, tech.chance || 1);
      })()));
    };
    const fxn = tech.fx && FX[tech.fx] ? tech.fx : 'basic';
    if (fxn === 'basic') await FX.basic({ a: e, tgts, target, hit });
    else await FX[fxn]({ a: e, tgts, target, tech, hit, users: [e] });
    await retFoe(e);
    // some enemies hop to a new spot after acting
    if (e.ed.hop && e.alive && G.rand() < 0.6) { const nx = e.hx + G.ri(-1, 1) * 14, ny = e.hy + G.ri(-1, 1) * 10; await jump(e, nx, ny, 12, 8); e.hx = e.x; e.hy = e.y; }
  }
  function updateShields() {
    if (!S) return;
    for (const f of S.foes) {
      if (!f.alive) continue;
      if (f.ed.ai === 'ashgram') f.shield = alive(S.foes).some(x => x.ed.ai === 'ashclaw') ? 0.5 : null;
      if (f.ed.ai === 'queen') f.shield = alive(S.foes).some(x => x.ed.ai === 'pendulum') ? 0.2 : null;
      if (f.ed.ai === 'core') f.shield = alive(S.foes).some(x => x.ed.ai === 'seal') ? 0.3 : null;
    }
  }

  // ---------------- per-frame ----------------
  const SPEED = [0.6, 0.8, 1.0, 1.25, 1.5];
  B.update = function () {
    if (!S) return;
    S.t++;
    for (const b of [...S.party, ...S.foes]) { b.anim++; if (b.flash) b.flash--; if (b.kb) b.kb--; }
    for (const f of S.fx) f.t++; S.fx = S.fx.filter(f => f.t < f.life);
    for (const p of S.pops) p.t++; S.pops = S.pops.filter(p => p.t < 50);
    if (S.label) { S.label.t--; if (S.label.t <= 0) S.label = null; }
    if (S.msg) { S.msg.t--; if (S.msg.t <= 0) S.msg = null; }
    if (S.phase !== 'main') return;
    updateShields();
    const submenu = S.menu && S.menu.level !== 'top';
    const paused = S.busy || (G.cfg.battle === 'wait' && submenu) || G.overlays.length;
    if (!paused) tickTime();
    if (!S.busy && S.queue.length) runNext();
    menuUpdate();
  };
  function tickTime() {
    const k = SPEED[(G.cfg.bspeed || 3) - 1] || 1;
    for (const b of [...S.party, ...S.foes]) {
      if (!b.alive) continue;
      // statuses
      for (const st in b.st) {
        b.st[st]--; if (b.st[st] <= 0) delete b.st[st];
      }
      if (b.st.poison && S.t % 120 === 0) { const n = Math.max(1, Math.round(b.maxhp * 0.04)); if (b.hp > n) { b.hp -= n; pop(b, n, '#c88aff', 12); } }
      if (b.st.stop || b.st.sleep) continue;
      const spd = b.side === 'party' ? b.stats.spd : b.ed.spd;
      let rate = (spd + 12) * 0.021 * k;
      if (b.st.haste) rate *= 1.5; if (b.st.slow) rate *= 0.6;
      if (b.queued) continue;
      if (b.atb < 100) { b.atb = Math.min(100, b.atb + rate); if (b.atb >= 100) onReady(b); }
    }
  }
  function onReady(b) {
    if (b.side === 'party') { if (!S.ready.includes(b)) { S.ready.push(b); G.se('ready'); } }
    else { b.queued = 1; S.queue.push({ kind: 'enemy', actor: b, tech: enemyChoose(b) }); }
  }
  async function runNext() {
    const act = S.queue.shift();
    S.busy = true;
    const actors = act.users || [act.actor];
    try { await execute(act); } catch (e) { console.error(e); }
    for (const u of actors) { u.queued = 0; if (!act.counter) u.atb = 0; }
    // make sure stopped or asleep members leave the ready list
    S.ready = S.ready.filter(b => b.alive && b.atb >= 100 && !b.queued);
    S.busy = false;
    await checkEnd();
  }
  async function checkEnd() {
    if (S.phase !== 'main') return;
    if (!alive(S.party).length) { S.phase = 'lose'; await lose(); return; }
    if (!S.foes.some(f => f.alive)) { S.phase = 'win'; await win(); }
  }

  // ---------------- command menu ----------------
  const CMDS = ['たたかう', 'わざ', 'どうぐ', 'にげる'];
  function menuUpdate() {
    if (S.phase !== 'main') return;
    S.ready = S.ready.filter(b => b.alive && !b.queued && !b.st.stop && !b.st.sleep);
    if (!S.menu || !S.ready.includes(S.menu.b)) {
      const b = S.ready[0];
      S.menu = b ? { b, level: 'top', i: S.lastCmd && S.lastCmd[b.id] || 0 } : null;
    }
    const M = S.menu; if (!M || G.overlays.length) return;
    const b = M.b;
    if (G.autoplay && M.level === 'top') { const act = autoAct(b); if (act) { enqueue(act); return; } }
    if (M.level === 'top') {
      if (G.repeat('up')) { M.i = (M.i + 3) % 4; G.se('cursor'); }
      if (G.repeat('down')) { M.i = (M.i + 1) % 4; G.se('cursor'); }
      if (G.pressed('cancel') && S.ready.length > 1) { S.ready.push(S.ready.shift()); S.menu = null; G.se('cursor'); return; }
      if (G.pressed('ok')) {
        S.lastCmd = S.lastCmd || {}; S.lastCmd[b.id] = M.i;
        if (M.i === 0) { G.se('ok'); openTarget(M, { area: 'single' }, 'foe', t => enqueue({ kind: 'attack', actor: b, target: t })); }
        else if (M.i === 1) { G.se('ok'); openTechs(M); }
        else if (M.i === 2) { G.se('ok'); openItems(M); }
        else if (M.i === 3) { if (S.opt.canEscape === false) { G.se('buzz'); S.msg = { text: 'この戦いからは逃げられない！', t: 80 }; } else { G.se('ok'); enqueue({ kind: 'flee', actor: b }); } }
      }
    } else if (M.level === 'list') {
      M.list.nav();
      const row = M.list.cur;
      if (G.pressed('cancel')) { G.se('cancel'); M.level = 'top'; return; }
      if (G.pressed('ok') && row) {
        if (row.disabled) { G.se('buzz'); return; }
        G.se('ok'); row.pick();
      }
    } else if (M.level === 'target') {
      const T = M.tgt;
      const n = T.cands.length;
      if (!n) { M.level = M.back; return; }
      if (G.repeat('left') || G.repeat('up')) { T.i = (T.i + n - 1) % n; G.se('cursor'); }
      if (G.repeat('right') || G.repeat('down')) { T.i = (T.i + 1) % n; G.se('cursor'); }
      if (G.pressed('cancel')) { G.se('cancel'); M.level = M.back; return; }
      if (G.pressed('ok')) { G.se('ok'); T.done(T.cands[T.i]); }
    }
  }
  function openTarget(M, tech, side, done) {
    const area = tech.area;
    if (['all', 'allies', 'self', 'circleS'].includes(area)) {
      M.back = M.level; M.level = 'target';
      const cands = [null];
      M.tgt = { cands, i: 0, tech, side, done, whole: true };
      return;
    }
    let cands;
    if (side === 'foe') cands = alive(S.foes).sort((a, b) => a.x - b.x);
    else cands = (tech.kind === 'revive' || tech.ko) ? S.party.filter(b => !b.alive) : (tech.anyAlly ? S.party.slice() : alive(S.party));
    if (!cands.length) { G.se('buzz'); return; }
    M.back = M.level; M.level = 'target';
    let i = 0; if (side === 'party' && tech.kind === 'heal') { let low = 2; cands.forEach((c, k) => { if (c.hp / c.maxhp < low) { low = c.hp / c.maxhp; i = k; } }); }
    if (S.tgtMemory && S.tgtMemory.alive && cands.includes(S.tgtMemory) && side === 'foe') i = cands.indexOf(S.tgtMemory);
    M.tgt = { cands, i, tech, side, done };
  }
  function enqueue(act) {
    const users = act.users || [act.actor];
    for (const u of users) { u.queued = 1; }
    if (act.target && act.target.side === 'foe') S.tgtMemory = act.target;
    S.queue.push(act);
    S.ready = S.ready.filter(b => !users.includes(b));
    S.menu = null;
  }
  function openTechs(M) {
    const b = M.b, rows = [];
    const ready = new Set(S.ready.concat([b]).filter(x => x.alive && !x.queued));
    for (const t of G.techsOf(b.id)) {
      const ok = b.mp >= t.mp && (t.kind !== 'revive' || S.party.some(x => !x.alive));
      rows.push({ label: t.name, right: t.mp, disabled: !ok, tech: t, desc: t.desc, pick: () => pickTech(M, t, [b]) });
    }
    const ids = S.party.map(x => x.id);
    for (const c of G.combosFor(ids)) {
      if (!c.users.includes(b.id)) continue;
      const us = c.users.map(id => S.party.find(x => x.id === id));
      const ok = us.every(u => u && u.alive && ready.has(u) && u.mp >= c.mp[u.id]);
      const partners = c.users.filter(id => id !== b.id).map(G.memberName).join('・');
      rows.push({ label: c.name, right: '連', disabled: !ok, tech: c, color: ok ? '#ffe08a' : null, desc: `${c.desc}（${partners}と）${ok ? '' : '　— 全員の行動準備ができると使える'}`, pick: () => pickTech(M, c, us) });
    }
    M.level = 'list'; M.kind = 'tech';
    M.list = new U.List({ rows, x: 16, y: H - 142 - 178 + 14, w: W - 32, vis: 5, cols: 2, empty: 'まだ技を覚えていない' });
  }
  function pickTech(M, t, users) {
    const enemySide = t.kind === 'phys' || t.kind === 'mag' || t.kind === 'scan';
    const done = target => enqueue(users.length > 1 ? { kind: 'combo', actor: users[0], users, tech: t, target } : { kind: 'tech', actor: users[0], tech: t, target });
    openTarget(M, Object.assign({}, t, { caster: users[0] }), enemySide ? 'foe' : 'party', done);
  }
  function openItems(M) {
    const rows = Object.entries(G.party.items).filter(([k, n]) => D.ITEMS[k] && D.ITEMS[k].kind === 'use' && D.ITEMS[k].target !== 'field' && n > 0).map(([k, n]) => {
      const it = D.ITEMS[k];
      return { label: it.name, right: n, icon: it.icon, desc: it.desc, pick: () => openTarget(M, { area: it.target === 'allies' ? 'allies' : 'ally', kind: 'item', ko: it.ko && !it.eff.hp, anyAlly: !(it.ko && !it.eff.hp) }, 'party', t => enqueue({ kind: 'item', actor: M.b, item: k, target: t })) };
    });
    M.level = 'list'; M.kind = 'item';
    M.list = new U.List({ rows, x: 16, y: H - 142 - 178 + 14, w: W - 32, vis: 5, cols: 2, empty: '使える道具がない' });
  }

  // ---------------- end of battle ----------------
  async function win() {
    G.bgm(S.opt.noFanfare ? null : 'victory', { restart: true });
    for (const b of alive(S.party)) { b.dir = 'down'; b.pose = 'cast'; jump(b, b.x, b.y, 16, 8); }
    await wait(40);
    for (const b of alive(S.party)) b.pose = null;
    const defeated = S.deadFoes.filter(f => !f.fled);
    const exp = defeated.reduce((s, f) => s + (f.ed.exp || 0), 0), gold = defeated.reduce((s, f) => s + (f.ed.g || 0), 0);
    const drops = [];
    for (const f of defeated) if (f.ed.drop && G.rand() < f.ed.drop[1]) drops.push(f.ed.drop[0]);
    syncBack();
    const ups = G.gainExp(exp, alive(S.party).map(b => b.id));
    G.party.gold += gold;
    drops.forEach(d => G.addItem(d, 1));
    await results(exp, gold, drops, ups);
    await finish('win');
  }
  async function lose() {
    S.msg = { text: '全滅してしまった……', t: 9999 };
    G.bgm('gameover', { restart: true });
    await wait(120);
    await finish('lose');
  }
  function syncBack() {
    for (const b of S.party) { const m = b.member; m.hp = b.alive ? Math.max(1, b.hp) : 0; m.mp = b.mp; const keep = {}; for (const k of ['poison']) if (b.st[k]) keep[k] = b.st[k]; m.st = b.alive ? keep : {}; }
  }
  function results(exp, gold, drops, ups) {
    return new Promise(res => {
      const lines = [`経験値 ${exp}　　${gold} G`];
      if (drops.length) lines.push(drops.map(d => D.ITEMS[d].name).join('、') + ' を手に入れた！');
      for (const u of ups) {
        lines.push(`${G.memberName(u.id)}はレベル${u.lv}になった！`);
        for (const t of u.techs) lines.push(`　${G.memberName(u.id)}は「${t}」を覚えた！`);
        for (const c of u.combos) lines.push(`　連携技「${c}」が使えるようになった！`);
      }
      if (ups.length) G.se('levelup');
      const h = 36 + lines.length * 26, w = 440, x = (W - w) / 2, y = 60;
      let t = 0;
      const o = { kind: 'results', update() { t++; if (t > 30 && (G.pressed('ok') || G.pressed('cancel'))) { G.consume('ok'); G.pop(o); res(); } }, draw() { U.win(x, y, w, h, { title: '勝利' }); lines.forEach((l, i) => G.text(l, x + 22, y + 18 + i * 26, i === 0 ? U.COL.TEXT : l.startsWith('　') ? '#ffe08a' : U.COL.TEXT)); } };
      if (exp === 0 && gold === 0 && !drops.length && !ups.length) { res(); return; }
      G.push(o);
    });
  }
  async function finish(result) {
    if (result !== 'win') syncBack();
    if (result === 'win' || result === 'escape') {
      // regroup on the leader's battle position
      const lb = S.party[0];
      const p = snapWalkable(lb.x, lb.y);
      for (const b of S.party) if (b !== lb) jump(b, lb.x, lb.y, 14, 10);
      await wait(16);
      F.placeParty(p.x / 16, p.y / 16, 'down');
      for (const f of S.foes) if (f.actor) f.actor.visible = false;
      if (result === 'escape') F.actors = F.actors.filter(a => !(a.foe && a.enc === S.opt.enc));
    }
    const res = S.res;
    B.active = false; G.mode = 'field'; F.camLock = null; F.lock = 0;
    S = null;
    if (result !== 'lose' && F.map && F.map.def.music && !G.flags.noMapMusic) G.bgm(G.musicFor ? G.musicFor(F.map.def) : F.map.def.music);
    res(result);
  }

  // ---------------- drawing ----------------
  B.drawables = () => S ? [...S.party, ...S.foes.filter(f => f.alpha > 0)] : [];
  B.drawBattler = function (c, b) {
    if (b.side === 'party') {
      const fr = G.SPR.frames(b.id); if (!fr) return;
      let img;
      if (!b.alive) img = fr.ko;
      else if (b.pose && fr[b.pose]) img = fr[b.pose];
      else { const seq = fr[b.dir] || fr.down; img = b.moving ? seq[[1, 0, 2, 0][Math.floor(b.anim / 6) % 4]] : seq[0]; }
      if (b.st.stop && b.alive) img = fr.statue ? fr.statue[b.dir] || img : img;
      const kb = b.kb ? Math.sin(b.kb) * 2 : 0;
      const x = Math.round(b.x + 8 - img.width / 2 + kb), base = Math.round(b.y + 15);
      c.globalAlpha = 0.3; c.fillStyle = '#000'; c.beginPath(); c.ellipse(b.x + 8, base - 1, 7, 2.5, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1;
      const y = base - img.height - Math.round(b.z) + (b.id === 'pip' ? Math.round(Math.sin(G.frame / 12) * 1.5) - 4 : 0) + (!b.alive ? 6 : 0);
      if (b.flash && b.flash % 4 < 2) c.drawImage(G.art.silhouette(img, '#ffffff'), x, y); else c.drawImage(img, x, y);
      if (b.st.poison) { c.fillStyle = '#b07ad8'; c.fillRect(x + 3 + (G.frame >> 3) % 8, y - 2 - (G.frame >> 2) % 6, 2, 2); }
      if (b.st.sleep) G.text('Zz', x + 12, y - 8, '#ffffff', 'left', 8, null);
      if (b.st.haste && G.frame % 6 < 3) { c.fillStyle = 'rgba(160,220,255,0.7)'; c.fillRect(x - 3, y + 10, 3, 1); c.fillRect(x - 5, y + 14, 4, 1); }
      if (b.st.guard) { c.strokeStyle = 'rgba(154,216,255,0.5)'; c.lineWidth = 1; c.strokeRect(x - 1.5, y - 1.5, img.width + 3, img.height + 3); }
    } else {
      const img = G.SPR.monster(b.ed.spr, b.ed.pal, Math.floor(b.anim / 16) % 2);
      const fly = b.ed.fly ? Math.round(Math.sin(G.frame / 14 + b.ph) * 2) - 6 : 0;
      const x = Math.round(b.x + 8 - img.width / 2), base = Math.round(b.y + 15);
      c.globalAlpha = 0.28 * b.alpha; c.fillStyle = '#000'; c.beginPath(); c.ellipse(b.x + 8, base - 1, Math.min(22, img.width / 2.4), Math.min(6, img.width / 8), 0, 0, Math.PI * 2); c.fill();
      c.globalAlpha = b.alpha;
      const y = base - img.height - Math.round(b.z) + fly;
      if (b.dissolve) { const k = b.dissolve; for (let r = 0; r < img.height; r += 2) { const off = ((r * 7 + k * 3) % 5 - 2) * k * 0.4; c.drawImage(img, 0, r, img.width, 2, x + off, y + r, img.width, 2); } }
      else if (b.flash && b.flash % 4 < 2) c.drawImage(G.art.silhouette(img, '#ffffff'), x, y);
      else c.drawImage(img, x, y);
      if (b.alive && b.hp < b.maxhp && !b.ed.boss) { const bw = Math.max(14, Math.min(28, img.width - 4)), bx = Math.round(b.x + 8 - bw / 2), by = base + 2; c.globalAlpha = 0.85; c.fillStyle = '#0b0f1e'; c.fillRect(bx - 1, by - 1, bw + 2, 4); c.fillStyle = b.hp < b.maxhp / 3 ? '#ff7a6a' : '#e8c05a'; c.fillRect(bx, by, Math.max(1, Math.round(bw * b.hp / b.maxhp)), 2); c.globalAlpha = b.alpha; }
      if (b.shield && b.alive) { c.globalAlpha = 0.25 + Math.sin(G.frame / 10) * 0.1; c.strokeStyle = '#c8b8ff'; c.lineWidth = 1; c.beginPath(); c.ellipse(b.x + 8, base - img.height / 2, img.width / 2 + 4, img.height / 2 + 4, 0, 0, Math.PI * 2); c.stroke(); }
      if (b.st.slow && b.alive) { c.globalAlpha = 0.6; G.text('…', x + img.width, y, '#d8a0ff', 'left', 8, null); }
      if (b.st.defdown && b.alive) { c.globalAlpha = 0.8; c.fillStyle = '#ff8a8a'; c.fillRect(x + img.width - 2, y + 2, 1, 3); c.fillRect(x + img.width - 3, y + 4, 3, 1); }
      c.globalAlpha = 1;
    }
  };
  B.drawWorldFx = function (c) {
    if (!S) return;
    for (const f of S.fx) if (!f.screen) { c.save(); f.draw(c, f.t); c.restore(); }
    // targeting preview
    const M = S.menu;
    if (M && M.level === 'target') {
      const T = M.tgt, tech = T.tech;
      const tg = T.cands[T.i];
      const pool = T.side === 'foe' ? S.foes : S.party;
      const user = tech.caster || M.b;
      let aff = T.whole ? (tech.area === 'circleS' ? areaTargets(user, tech, null, S.foes) : tech.area === 'self' ? [user] : alive(pool)) : tg ? areaTargets(user, tech, tg, pool) : [];
      if (tech.kind === 'revive' || tech.ko) aff = tg ? [tg] : [];
      c.save();
      const a = 0.35 + Math.sin(G.frame / 8) * 0.15;
      c.strokeStyle = `rgba(226,176,74,${a + 0.2})`; c.fillStyle = `rgba(226,176,74,${a * 0.35})`; c.lineWidth = 1;
      if (tech.area === 'circleT' && tg) { const p = center(tg); c.beginPath(); c.ellipse(p.x, p.y + 6, tech.r, tech.r / 1.3, 0, 0, Math.PI * 2); c.fill(); c.stroke(); }
      if (tech.area === 'circleS') { const p = center(user); c.beginPath(); c.ellipse(p.x, p.y + 6, tech.r, tech.r / 1.3, 0, 0, Math.PI * 2); c.fill(); c.stroke(); }
      if (tech.area === 'line' && tg) { const p0 = center(user), p1 = center(tg); const dx = p1.x - p0.x, dy = p1.y - p0.y, L = Math.hypot(dx, dy) || 1; c.lineWidth = 22; c.lineCap = 'round'; c.strokeStyle = `rgba(226,176,74,${a * 0.5})`; c.beginPath(); c.moveTo(p0.x, p0.y); c.lineTo(p0.x + dx / L * (L + 120), p0.y + dy / L * (L + 120)); c.stroke(); }
      c.restore();
      for (const b of aff) { const p = center(b); const top = b.side === 'foe' ? b.y + 15 - b.h - 4 : b.y - 12; drawArrow(c, p.x, top + Math.sin(G.frame / 6) * 2, b === tg || T.whole); }
    }
  };
  function drawArrow(c, x, y, main) { c.fillStyle = main ? '#ffe08a' : '#e2b04a'; c.strokeStyle = '#1b1229'; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 4, y - 6); c.lineTo(x + 4, y - 6); c.lineTo(x, y); c.closePath(); c.fill(); c.stroke(); }
  B.drawScreenFx = function (c) {
    if (!S) return;
    for (const f of S.fx) if (f.screen) f.draw(c, f.t);
    const cam = F.cam;
    for (const p of S.pops) {
      const k = p.t; const yoff = k < 8 ? -k * 1.5 : k < 14 ? -12 + (k - 8) : -6;
      c.globalAlpha = p.t > 40 ? (50 - p.t) / 10 : 1;
      G.text(p.text, (p.x - cam.x) * 2, (p.y - cam.y) * 2 + yoff * 2 - 20, p.col, 'center', p.size || 16, '#0b0f1e');
      c.globalAlpha = 1;
    }
  };
  // UI panels (screen space)
  B.drawUI = function () {
    if (!S) return;
    if (S.bossBanner) {
      const t = ++S.bossBanner.t, k = Math.min(1, t / 14), out = t > 64 ? (t - 64) / 16 : 0;
      ctx.save(); ctx.globalAlpha = 1 - out;
      ctx.fillStyle = 'rgba(5,6,12,0.75)'; ctx.fillRect(0, 150, W, 70 * k);
      ctx.fillStyle = '#c9473d'; ctx.fillRect(0, 150, W * k, 2); ctx.fillRect(W * (1 - k), 218, W * k, 2);
      G.text('— 立ちはだかる —', W / 2, 160, '#e2b04a', 'center', 12);
      G.text(S.bossBanner.name, W / 2 + (1 - k) * 200, 180, '#f3ead6', 'center', 24);
      ctx.restore();
    }
    if (S.cutin) {
      const t = ++S.cutin.t, n = S.cutin.users.length, k = G.ease(Math.min(1, t / 12)), out = t > 38 ? (t - 38) / 8 : 0;
      ctx.save(); ctx.globalAlpha = 1 - out;
      const h = 120, y = 120;
      ctx.fillStyle = 'rgba(10,12,30,0.88)'; ctx.fillRect(0, y, W, h * k);
      for (let i = 0; i < W; i += 16) { ctx.fillStyle = (i / 16) % 2 ? '#c9473d' : '#3765b0'; ctx.fillRect(i, y, 8, 3); ctx.fillRect(i + 8, y + h - 3, 8, 3); }
      S.cutin.users.forEach((id, i) => {
        const img = G.portrait(G.memberName(id), 'firm'); if (!img) return;
        const x = W / 2 - n * 56 + i * 112 + (1 - k) * (i % 2 ? 300 : -300);
        ctx.drawImage(img, x, y + 12, 96, 96);
      });
      G.text(S.cutin.name, W / 2, y + h + 8, '#ffe08a', 'center', 20);
      ctx.restore();
    }
    const top = H - 142;
    // party window
    U.win(12, top, 400, 130);
    S.party.forEach((b, i) => {
      const y = top + 12 + i * 38;
      const cur = S.menu && S.menu.b === b;
      if (cur) { ctx.fillStyle = 'rgba(226,176,74,0.16)'; ctx.fillRect(16, y - 3, 392, 34); }
      const col = !b.alive ? '#ff8a8a' : b.hp < b.maxhp / 4 ? '#ffe08a' : U.COL.TEXT;
      G.text(b.name, 30, y + 4, col);
      if (b.st.poison) U.icon('potion', 92, y + 6, 1);
      G.text(String(b.hp), 196, y + 4, col, 'right'); G.text('/' + b.maxhp, 200, y + 6, '#a8a0c0', 'left', 12);
      U.bar(130, y + 24, 110, 4, b.hp, b.maxhp, b.hp < b.maxhp / 4 ? '#e8c05a' : '#7ee0a0');
      G.text(String(b.mp), 290, y + 4, '#9ad8ff', 'right'); G.text('MP', 252, y + 7, '#7a90b8', 'left', 10);
      const full = b.atb >= 100;
      U.bar(304, y + 10, 92, 10, b.atb, 100, full ? (G.frame % 20 < 10 ? '#ffe08a' : '#e2b04a') : (b.st.stop ? '#a8a8c8' : '#5a8ad8'));
      if (b.st.stop) G.text('とばり', 350, y + 22, '#c8c8e0', 'center', 10);
    });
    // command window
    const M = S.menu;
    if (M && S.phase === 'main') {
      U.win(424, top, 204, 130, { title: M.b.name });
      CMDS.forEach((s, i) => G.text(s, 466, top + 14 + i * 28, i === 3 && S.opt.canEscape === false ? '#6f6a86' : U.COL.TEXT));
      if (M.level === 'top') U.cursor(440, top + 18 + M.i * 28);
      if (S.ready.length > 1 && M.level === 'top') G.text('×で交代', 612, top + 112, '#8f8aa6', 'right', 10);
      if (M.level === 'list') {
        U.win(12, top - 190, W - 24, 178, { title: M.kind === 'tech' ? 'わざ' : 'どうぐ' });
        M.list.draw();
        const row = M.list.cur;
        if (row) helpBox(row.desc);
      }
      if (M.level === 'target') {
        const T = M.tgt, tg = T.cands[T.i];
        const name = T.whole ? (T.tech.area === 'circleS' ? '自分のまわりの敵' : T.side === 'foe' ? '敵全体' : T.tech.area === 'self' ? '自分' : '味方全員') : tg ? (tg.name + (tg.side === 'foe' && tg.scanned ? `　HP ${tg.hp}` : '')) : '';
        helpBox(name);
      }
    }
    if (S.label) {
      const w = G.tw(S.label.text) + 60, x = (W - w) / 2;
      U.win(x, 14, w, 40, { mail: !!S.label.combo });
      G.text(S.label.text, W / 2, 26, S.label.enemy ? '#ffb0a0' : S.label.combo ? '#ffe08a' : U.COL.TEXT, 'center');
    } else if (S.msg) { const w = G.tw(S.msg.text) + 60, x = (W - w) / 2; U.win(x, 14, w, 40); G.text(S.msg.text, W / 2, 26, U.COL.TEXT, 'center'); }
  };
  function helpBox(t) { if (!t) return; U.win(12, 14, W - 24, 40); G.text(t, 28, 26, U.COL.TEXT, 'left', t.length > 38 ? 13 : 16); }

  // simple tactical AI used by automated playtests
  function autoAct(b) {
    const foes = alive(S.foes), al = alive(S.party), dead = S.party.filter(x => !x.alive);
    if (!foes.length) return null;
    const low = al.filter(x => x.hp < x.maxhp * 0.45).sort((x, y) => x.hp / x.maxhp - y.hp / y.maxhp)[0];
    const techs = G.techsOf(b.id);
    const can = t => b.mp >= t.mp;
    if (dead.length) { const rv = techs.find(t => t.kind === 'revive' && can(t)); if (rv) return { kind: 'tech', actor: b, tech: rv, target: dead[0] }; if (G.hasItem('revive')) return { kind: 'item', actor: b, item: 'revive', target: dead[0] }; }
    if (low) {
      const healAll = techs.find(t => t.kind === 'heal' && t.area === 'allies' && can(t));
      if (healAll && al.filter(x => x.hp < x.maxhp * 0.6).length >= 2) return { kind: 'tech', actor: b, tech: healAll };
      const h = techs.find(t => t.kind === 'heal' && can(t)); if (h) return { kind: 'tech', actor: b, tech: h, target: low };
      for (const it of ['hisalve', 'salve']) if (G.hasItem(it) && low.hp < low.maxhp * 0.3) return { kind: 'item', actor: b, item: it, target: low };
    }
    if (b.mp < b.maxmp * 0.25 && G.hasItem('dew') && b.id === 'mio') return { kind: 'item', actor: b, item: 'dew', target: b };
    // combos with ready partners
    const readyIds = new Set(S.ready.map(x => x.id).concat([b.id]));
    for (const c of G.combosFor(S.party.map(x => x.id)).filter(c => c.kind !== 'heal' && c.users.includes(b.id)).reverse()) {
      const us = c.users.map(id => S.party.find(x => x.id === id));
      if (us.every(u => u && u.alive && readyIds.has(u.id) && !u.queued && u.mp >= c.mp[u.id]) && G.rand() < 0.7) { const tg = foes.sort((x, y) => y.hp - x.hp)[0]; return { kind: 'combo', actor: us[0], users: us, tech: c, target: tg }; }
    }
    const atk = techs.filter(t => (t.kind === 'phys' || t.kind === 'mag') && can(t) && b.mp - t.mp >= b.maxmp * 0.2).sort((x, y) => y.power * (y.area === 'all' ? foes.length : 1) - x.power * (x.area === 'all' ? foes.length : 1));
    const main = foes.find(f => f.main) ; const tgt = foes.filter(f => !f.shield).sort((x, y) => x.hp - y.hp)[0] || foes[0];
    if (atk.length && (foes.length > 1 || tgt.ed.boss) && G.rand() < 0.6) return { kind: 'tech', actor: b, tech: atk[0], target: tgt };
    return { kind: 'attack', actor: b, target: tgt };
  }
  // exported for tests
  B._enemyChoose = enemyChoose;
})();
