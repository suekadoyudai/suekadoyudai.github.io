'use strict';
// On-screen controls for Meta Quest (and touch screens).
// Each button holds an action in the same input table the keyboard uses, so every screen works unchanged.
// They sit in the empty space beside the 4:3 picture; on narrow windows they float over its edges.
(function () {
  const I = G.input;
  const LABEL = {
    ok: ['決定', 'OK'], cancel: ['もどる', 'Back'], menu: ['メニュー', 'Menu'], run: ['走る', 'Run'], pgdn: ['早送り', 'Skip'],
    up: ['▲', '▲'], down: ['▼', '▼'], left: ['◀', '◀'], right: ['▶', '▶'],
  };
  const css = `
  #pad{position:fixed;inset:0;pointer-events:none;display:none;z-index:5;font-family:"DotGothic16",sans-serif;user-select:none;-webkit-user-select:none}
  body.pad #pad{display:block}
  #pad .grp{position:absolute;bottom:6vh;display:grid;gap:1.2vh;pointer-events:none}
  #pad .dpad{left:2vh;grid-template-columns:repeat(3,8.5vh);grid-template-rows:repeat(3,8.5vh)}
  #pad .acts{right:2vh;grid-template-columns:repeat(2,11.5vh);grid-auto-rows:8.5vh}
  #pad button{pointer-events:auto;touch-action:none;border:0.35vh solid #8a86b8;border-radius:1.6vh;background:rgba(20,26,51,.78);color:#f3ead6;
    font:inherit;font-size:2.7vh;line-height:1;padding:0;cursor:pointer;outline:none}
  #pad button.big{grid-column:span 2;font-size:3.6vh;border-color:#e2b04a}
  #pad button.on{background:rgba(226,176,74,.85);color:#141a33}
  #pad button:focus-visible{box-shadow:0 0 0 .4vh #fff}`;
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  const pad = document.createElement('div'); pad.id = 'pad'; pad.setAttribute('aria-hidden', 'true');
  const dp = document.createElement('div'); dp.className = 'grp dpad';
  const ac = document.createElement('div'); ac.className = 'grp acts';
  const btns = [];
  function mk(a, parent, cls, col, row) {
    const b = document.createElement('button'); b.type = 'button'; b.dataset.a = a; if (cls) b.className = cls;
    if (col) { b.style.gridColumn = col; b.style.gridRow = row; }
    let held = false;
    const on = e => {
      e.preventDefault(); e.stopPropagation();
      held = true; I.kb[a] = true; I.tap[a] = true; I.anyKey = true; I.lastDevice = 'pad-screen'; b.classList.add('on');
      try { b.setPointerCapture(e.pointerId); } catch (x) { }
      G.audio && G.audio.unlock();
    };
    const off = () => { if (!held) return; held = false; I.kb[a] = false; b.classList.remove('on'); };
    b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off);
    b.addEventListener('lostpointercapture', off); b.addEventListener('contextmenu', e => e.preventDefault());
    parent.appendChild(b); btns.push(b); return b;
  }
  mk('up', dp, '', '2', '1'); mk('left', dp, '', '1', '2'); mk('right', dp, '', '3', '2'); mk('down', dp, '', '2', '3');
  mk('ok', ac, 'big'); mk('cancel', ac); mk('menu', ac); mk('run', ac); mk('pgdn', ac);
  pad.append(dp, ac); document.body.appendChild(pad);
  let lang = null;
  function relabel() { lang = G.lang; for (const b of btns) b.textContent = LABEL[b.dataset.a][G.lang === 'ja' ? 0 : 1]; }
  relabel();
  setInterval(() => { if (G.lang !== lang) relabel(); }, 250);
  const show = v => { if (document.body.classList.contains('pad') !== v) document.body.classList.toggle('pad', v); };
  if (G.QUEST) show(true);
  // touch screens: show on the first touch; hide again when a keyboard or gamepad is used (except on Quest)
  addEventListener('pointerdown', e => { if (e.pointerType === 'touch') show(true); }, { capture: true });
  addEventListener('keydown', () => { if (!G.QUEST) show(false); });
  // the canvas keeps the cursor visible on Quest so the pointer can always reach the buttons
  if (G.QUEST) { const k = new MutationObserver(() => { if (document.body.classList.contains('nocursor')) document.body.classList.remove('nocursor'); }); k.observe(document.body, { attributes: true, attributeFilter: ['class'] }); }
  // leave room for the buttons: on a 16:9 window the 4:3 picture is shrunk a little so they sit beside it
  function fitPad() {
    const cv = G.cv; if (!cv) return;
    if (!document.body.classList.contains('pad')) { G.fitCanvas(); return; }
    const side = innerHeight * 0.27, full = Math.min(innerWidth / W, innerHeight / H);
    const s = Math.max(Math.min((innerWidth - side * 2) / W, innerHeight / H), full * 0.8);
    cv.style.width = Math.floor(W * s) + 'px'; cv.style.height = Math.floor(H * s) + 'px';
  }
  addEventListener('resize', () => setTimeout(fitPad, 0)); setTimeout(fitPad, 0);
  new MutationObserver(() => setTimeout(fitPad, 0)).observe(document.body, { attributes: true, attributeFilter: ['class'] });
})();
