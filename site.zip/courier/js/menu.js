'use strict';
// Menus and screens
(function () {
  const D = G.DATA, U = G.ui, C = U.COL;
  const fmtTime = f => { const s = Math.floor(f / 60), h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60; return `${h}:${String(m).padStart(2, '0')}`; };
  G.fmtTime = fmtTime;
  const eraLabel = e => !e || e === '—' ? '時の外' : e.startsWith('前') ? `紀元前${e.slice(1)}年` : `${e}年`;
  G.eraLabel = eraLabel;
  const SLOT = { weapon: '武器', armor: '体', helm: '頭', acc: '飾り' };

  function drawMember(id, x, y, opt = {}) {
    const m = G.party.members[id], s = G.stats(id);
    const fr = G.SPR.frames(id); const img = m.hp > 0 ? fr.down[Math.floor(G.frame / 16) % 3 === 1 && opt.active ? 1 : 0] : fr.ko;
    ctx.drawImage(img, x, y + (m.hp > 0 ? 0 : 12), img.width * 2, img.height * 2);
    G.text(G.memberName(id), x + 50, y + 2, opt.dim ? C.DIM : C.TEXT);
    G.text('Lv ' + m.lv, x + 130, y + 2, C.GOLD);
    G.text(`HP ${m.hp}/${s.maxhp}`, x + 50, y + 24, m.hp === 0 ? C.BAD : C.TEXT, 'left', 14);
    G.text(`MP ${m.mp}/${s.maxmp}`, x + 170, y + 24, '#9ad8ff', 'left', 14);
    U.bar(x + 50, y + 44, 110, 4, m.hp, s.maxhp, '#7ee0a0'); U.bar(x + 170, y + 44, 70, 4, m.mp, s.maxmp, '#7ab8ff');
  }

  // ---------------- field menu ----------------
  const ITEMS_MAIN = ['どうぐ', 'わざ', 'そうび', 'ステータス', '手紙', 'ならびかえ', 'せってい', 'タイトルへ'];
  G.openMenu = function () {
    if (G.overlays.length || G.mode !== 'field') return;
    G.se('ok');
    const st = { i: 0, sub: null };
    const o = {
      update() {
        if (st.sub) { st.sub.update(); return; }
        if (G.repeat('up')) { st.i = (st.i + ITEMS_MAIN.length - 1) % ITEMS_MAIN.length; G.se('cursor'); }
        if (G.repeat('down')) { st.i = (st.i + 1) % ITEMS_MAIN.length; G.se('cursor'); }
        if (G.pressed('cancel') || G.pressed('menu')) { G.se('cancel'); G.consumeAll(); G.pop(o); return; }
        if (G.pressed('ok')) {
          G.se('ok');
          const close = () => { st.sub = null; };
          const subs = [itemMenu, techMenu, equipMenu, statusMenu, letterMenu, orderMenu, configMenu, quitMenu];
          st.sub = subs[st.i](close, () => G.pop(o));
        }
      },
      draw() {
        ctx.fillStyle = 'rgba(5,6,12,0.55)'; ctx.fillRect(0, 0, W, H);
        if (st.sub && st.sub.full) { st.sub.draw(); return; }
        U.win(16, 16, 170, ITEMS_MAIN.length * 30 + 22, { mail: true });
        ITEMS_MAIN.forEach((s, i) => G.text(s, 54, 30 + i * 30, C.TEXT));
        if (!st.sub) U.cursor(26, 34 + st.i * 30);
        U.win(16, H - 112, 170, 96);
        G.text(`${G.party.gold} G`, 170, H - 98, C.GOLD, 'right');
        G.text(fmtTime(G.party.time), 170, H - 72, C.TEXT, 'right');
        const md = G.field.map && G.field.map.def;
        G.text(eraLabel(md && md.era), 34, H - 46, C.DIM, 'left', 12);
        G.text(md ? md.name : '', 34, H - 30, C.TEXT, 'left', 12);
        U.win(204, 16, W - 220, H - 32);
        const ids = G.party.active.concat(Object.keys(G.party.members).filter(k => !G.party.active.includes(k)));
        ids.forEach((id, k) => {
          const y = 34 + k * 98;
          drawMember(id, 224, y, { active: G.party.active.includes(id), dim: !G.party.active.includes(id) });
          if (!G.party.active.includes(id)) G.text('控え', W - 40, y + 2, C.DIM, 'right', 12);
          if (st.sub && st.sub.pickMember && st.sub.mi === k) U.cursor(212, y + 30);
        });
        if (st.sub) st.sub.draw();
      },
    };
    G.push(o);
  };
  const allMembers = () => G.party.active.concat(Object.keys(G.party.members).filter(k => !G.party.active.includes(k)));

  // ---------------- items ----------------
  function itemMenu(close) {
    const rows = () => Object.entries(G.party.items).filter(([k, n]) => n > 0 && D.ITEMS[k]).sort((a, b) => kindOrder(a[0]) - kindOrder(b[0])).map(([k, n]) => ({ label: D.ITEMS[k].name, right: D.ITEMS[k].kind === 'key' ? '' : n, icon: D.ITEMS[k].icon, id: k, disabled: D.ITEMS[k].kind !== 'use' }));
    const list = new U.List({ rows: rows(), x: 16, y: 74, w: W - 32, vis: 10, cols: 2, empty: '何も持っていない' });
    const st = { full: true, list, pick: null };
    st.update = () => {
      if (st.pick) { st.pick.update(); return; }
      list.nav();
      if (G.pressed('cancel')) { G.se('cancel'); close(); return; }
      if (G.pressed('ok') && list.cur) {
        const it = D.ITEMS[list.cur.id];
        if (it.kind !== 'use') { G.se('buzz'); return; }
        G.se('ok');
        if (it.target === 'field') { useBlanket(list.cur.id).then(() => { list.rows = rows(); }); return; }
        st.pick = memberPicker(async id => {
          const ok = useItemField(list.cur.id, id);
          if (!ok) G.se('buzz'); else G.se('heal');
          list.rows = rows(); if (!list.cur) list.i = Math.max(0, list.rows.length - 1);
          if (!list.rows.find(r => r.id === (list.cur && list.cur.id)) || !G.hasItem(list.cur.id)) st.pick = null;
        }, () => { st.pick = null; }, D.ITEMS[list.cur.id].target === 'allies');
      }
    };
    st.draw = () => {
      U.win(16, 16, W - 32, 44, { title: 'どうぐ' });
      const cur = list.cur && D.ITEMS[list.cur.id];
      G.text(cur ? cur.desc : '', 32, 30, C.TEXT, 'left', 14);
      U.win(16, 66, W - 32, H - 82);
      list.draw(!st.pick);
      if (st.pick) st.pick.draw();
    };
    return st;
  }
  const kindOrder = k => ({ use: 0, weapon: 1, armor: 2, helm: 3, acc: 4, key: 5 })[D.ITEMS[k].kind] * 100 + Object.keys(D.ITEMS).indexOf(k) / 1000;
  function useItemField(itemId, id) {
    const it = D.ITEMS[itemId]; const e = it.eff;
    const targets = it.target === 'allies' ? G.party.active : [id];
    let used = false;
    for (const tid of targets) {
      const m = G.party.members[tid], s = G.stats(tid);
      if (e.revive && m.hp === 0) { m.hp = Math.max(1, Math.round(s.maxhp * e.revive)); used = true; if (e.mp) m.mp = s.maxmp; continue; }
      if (m.hp === 0) continue;
      if (e.hp && m.hp < s.maxhp) { m.hp = Math.min(s.maxhp, m.hp + e.hp); used = true; }
      if (e.mp && m.mp < s.maxmp) { m.mp = Math.min(s.maxmp, m.mp + e.mp); used = true; }
      if (e.cure && m.st && Object.keys(m.st).length) { m.st = {}; used = true; }
    }
    if (used) G.removeItem(itemId, 1);
    return used;
  }
  async function useBlanket(id) {
    const near = G.field.map.objects.some(o => o.type === 'save' && Math.abs(o.x - G.field.leader().tx) + Math.abs(o.y - G.field.leader().ty) <= 2);
    if (!near) { await G.say(null, 'ポストのそばでないと、ゆっくり休めない。'); return; }
    G.removeItem(id, 1); await restScene();
  }
  async function restScene() {
    await G.fadeTo(1, 0.05); G.se('heal'); G.healAll(); await G.wait(50); await G.fadeTo(0, 0.05);
    await G.say(null, 'みんなの体力が回復した。');
  }
  G.restScene = restScene;
  // pick a party member (or all) in the right-hand party panel
  function memberPicker(onPick, onCancel, all) {
    const ids = allMembers();
    const st = { pickMember: true, mi: 0 };
    st.update = () => {
      if (!all) { if (G.repeat('up')) { st.mi = (st.mi + ids.length - 1) % ids.length; G.se('cursor'); } if (G.repeat('down')) { st.mi = (st.mi + 1) % ids.length; G.se('cursor'); } }
      if (G.pressed('cancel')) { G.se('cancel'); onCancel(); return; }
      if (G.pressed('ok')) onPick(ids[st.mi]);
    };
    st.draw = () => {
      U.win(W - 300, 90, 284, ids.length * 64 + 20);
      ids.forEach((id, k) => {
        const m = G.party.members[id], s = G.stats(id), y = 104 + k * 64;
        const fr = G.SPR.frames(id); ctx.drawImage(m.hp > 0 ? fr.down[0] : fr.ko, W - 270, y, 32, 48);
        G.text(G.memberName(id), W - 226, y + 2, C.TEXT); G.text(`HP ${m.hp}/${s.maxhp}`, W - 226, y + 24, m.hp ? C.TEXT : C.BAD, 'left', 14); G.text(`MP ${m.mp}`, W - 100, y + 24, '#9ad8ff', 'left', 14);
        if (all || k === st.mi) U.cursor(W - 296, y + 18);
      });
    };
    return st;
  }

  // ---------------- techs (field healing) ----------------
  function techMenu(close) {
    const ids = allMembers();
    const st = { pickMember: true, mi: 0, stage: 'member', list: null, pick: null };
    st.update = () => {
      if (st.pick) { st.pick.update(); return; }
      if (st.stage === 'member') {
        if (G.repeat('up')) { st.mi = (st.mi + ids.length - 1) % ids.length; G.se('cursor'); }
        if (G.repeat('down')) { st.mi = (st.mi + 1) % ids.length; G.se('cursor'); }
        if (G.pressed('cancel')) { G.se('cancel'); close(); return; }
        if (G.pressed('ok')) { G.se('ok'); st.stage = 'list'; st.full = true; build(); }
        return;
      }
      st.list.nav();
      if (G.pressed('cancel')) { G.se('cancel'); st.stage = 'member'; st.full = false; return; }
      if (G.pressed('ok') && st.list.cur) {
        const t = st.list.cur.tech; const uid = ids[st.mi]; const m = G.party.members[uid];
        if (!t.field || m.mp < t.mp || m.hp === 0) { G.se('buzz'); return; }
        G.se('ok');
        st.pick = memberPicker(tid => {
          const tm = G.party.members[tid], ts = G.stats(tid);
          if (m.mp < t.mp) { G.se('buzz'); return; }
          const targets = t.area === 'allies' ? G.party.active : [tid];
          let used = false;
          for (const x of targets) {
            const mm = G.party.members[x], ss = G.stats(x);
            if (t.kind === 'revive') { if (mm.hp === 0) { mm.hp = Math.round(ss.maxhp * t.power); used = true; } }
            else if (mm.hp > 0 && t.kind === 'heal' && mm.hp < ss.maxhp) { const pseudo = { side: 'party', stats: G.stats(uid), st: {} }; mm.hp = Math.min(ss.maxhp, mm.hp + G.battle.healAmount(pseudo, t.power)); used = true; }
            else if (mm.hp > 0 && t.kind === 'cure' && Object.keys(mm.st || {}).length) { mm.st = {}; used = true; }
          }
          if (used) { m.mp -= t.mp; G.se('heal'); } else G.se('buzz');
          build();
        }, () => { st.pick = null; }, t.area === 'allies');
      }
    };
    function build() {
      const uid = ids[st.mi];
      const rows = G.techsOf(uid).map(t => ({ label: t.name, right: t.mp, tech: Object.assign({ field: ['heal', 'revive', 'cure'].includes(t.kind) }, t), disabled: !['heal', 'revive', 'cure'].includes(t.kind) }));
      for (const c of G.knownCombos()) if (c.users.includes(uid)) rows.push({ label: c.name, right: '連', tech: c, disabled: true, combo: 1 });
      if (st.list) st.list.rows = rows; else st.list = new U.List({ rows, x: 16, y: 74, w: W - 32, vis: 10, cols: 2, empty: 'まだ技を覚えていない' });
    }
    st.draw = () => {
      if (st.stage === 'member') { U.win(16, H - 170, 170, 46); G.text('だれの技？', 34, H - 156, C.TEXT); return; }
      const uid = ids[st.mi], m = G.party.members[uid];
      U.win(16, 16, W - 32, 44, { title: G.memberName(uid) + '　MP ' + m.mp });
      const cur = st.list.cur;
      if (cur) { const t = cur.tech; const extra = cur.combo ? `（${t.users.map(G.memberName).join('・')}）` : ''; G.text((t.desc || '') + extra, 32, 30, C.TEXT, 'left', (t.desc || '').length > 36 ? 12 : 14); }
      U.win(16, 66, W - 32, H - 82); st.list.draw(!st.pick);
      G.text('戦闘の外で使えるのは回復の技だけ。連携技は戦闘で、仲間全員の準備ができたときに使える。', 32, H - 40, C.DIM, 'left', 12);
      if (st.pick) st.pick.draw();
    };
    return st;
  }

  // ---------------- equipment ----------------
  function equipMenu(close) {
    const ids = allMembers();
    const st = { pickMember: true, mi: 0, stage: 'member', si: 0, list: null };
    const slots = ['weapon', 'armor', 'helm', 'acc'];
    st.update = () => {
      if (st.stage === 'member') {
        if (G.repeat('up')) { st.mi = (st.mi + ids.length - 1) % ids.length; G.se('cursor'); }
        if (G.repeat('down')) { st.mi = (st.mi + 1) % ids.length; G.se('cursor'); }
        if (G.pressed('cancel')) { G.se('cancel'); close(); return; }
        if (G.pressed('ok')) { G.se('ok'); st.stage = 'slot'; st.full = true; }
        return;
      }
      const uid = ids[st.mi];
      if (st.stage === 'slot') {
        if (G.repeat('up')) { st.si = (st.si + 4) % 5; G.se('cursor'); }
        if (G.repeat('down')) { st.si = (st.si + 1) % 5; G.se('cursor'); }
        if (G.repeat('pgdn') || G.repeat('right')) { st.mi = (st.mi + 1) % ids.length; G.se('cursor'); }
        if (G.repeat('pgup') || G.repeat('left')) { st.mi = (st.mi + ids.length - 1) % ids.length; G.se('cursor'); }
        if (G.pressed('cancel')) { G.se('cancel'); st.stage = 'member'; st.full = false; return; }
        if (G.pressed('ok') && st.si === 4) { const n = G.autoEquip(uid); G.se(n ? 'buy' : 'cursor'); st.msg = n ? `${n}か所を入れかえた` : 'いまの装備がいちばん強い'; st.msgT = 90; return; }
        if (G.pressed('ok')) {
          const slot = slots[st.si];
          const rows = Object.keys(G.party.items).filter(k => D.ITEMS[k] && G.slotOf(D.ITEMS[k]) === slot && G.canEquip(uid, k)).map(k => ({ label: D.ITEMS[k].name, right: G.count(k), icon: D.ITEMS[k].icon, id: k }));
          if (slot !== 'weapon') rows.unshift({ label: '（はずす）', id: null });
          if (!rows.length) { G.se('buzz'); return; }
          G.se('ok'); st.stage = 'item'; st.list = new U.List({ rows, x: 16, y: 284, w: W - 32, vis: 6, cols: 2 });
        }
        return;
      }
      st.list.nav();
      if (G.pressed('cancel')) { G.se('cancel'); st.stage = 'slot'; return; }
      if (G.pressed('ok') && st.list.cur) { G.se('ok'); G.equip(uid, st.list.cur.id, slots[st.si]); st.stage = 'slot'; }
    };
    st.draw = () => {
      if (st.stage === 'member') { U.win(16, H - 170, 170, 46); G.text('だれの装備？', 34, H - 156, C.TEXT); return; }
      const uid = ids[st.mi], m = G.party.members[uid], s = G.stats(uid);
      U.win(16, 16, W - 32, 252, { title: 'そうび' });
      const fr = G.SPR.frames(uid); ctx.drawImage(fr.down[0], 36, 40, 48, 72);
      G.text(G.memberName(uid), 100, 40, C.TEXT); G.text('Lv ' + m.lv, 100, 62, C.GOLD);
      G.text('◀ ▶ で切りかえ', 100, 86, C.DIM, 'left', 12);
      slots.forEach((sl, i) => {
        const y = 120 + i * 28; G.text(SLOT[sl], 40, y, C.DIM);
        const it = m.eq[sl] && D.ITEMS[m.eq[sl]];
        if (it) U.icon(it.icon, 90, y + 1, 2);
        G.text(it ? it.name : '—', 118, y, C.TEXT);
        if (st.stage === 'slot' && i === st.si) U.cursor(18, y + 4);
      });
      G.text('おまかせ装備', 40, 236, st.si === 4 ? C.GOLD : '#c8c0d8', 'left', 14);
      if (st.stage === 'slot' && st.si === 4) U.cursor(18, 240);
      if (st.msgT > 0) { st.msgT--; G.text(st.msg, 200, 238, C.GOOD, 'left', 12); }
      // stat preview
      let prev = null;
      if (st.stage === 'item' && st.list.cur !== undefined) { const eq = Object.assign({}, m.eq); eq[slots[st.si]] = st.list.cur ? st.list.cur.id : null; prev = G.stats(uid, eq); }
      const keys = [['攻撃', 'atk'], ['魔力', 'matk'], ['守り', 'def'], ['魔守', 'mdef'], ['速さ', 'spd']];
      keys.forEach(([lab, k], i) => {
        const y = 40 + i * 28; G.text(lab, 380, y, C.DIM); G.text(String(s[k]), 470, y, C.TEXT, 'right');
        if (prev) { const d = prev[k] - s[k]; G.text('→', 486, y, C.DIM); G.text(String(prev[k]), 560, y, d > 0 ? C.GOOD : d < 0 ? C.BAD : C.TEXT, 'right'); }
      });
      const it = st.stage === 'item' && st.list.cur && st.list.cur.id ? D.ITEMS[st.list.cur.id] : st.stage === 'slot' && m.eq[slots[st.si]] ? D.ITEMS[m.eq[slots[st.si]]] : null;
      if (it) G.text(it.desc, 380, 190, C.TEXT, 'left', 12);
      if (st.stage === 'item') { U.win(16, 276, W - 32, H - 292); st.list.draw(); }
    };
    return st;
  }

  // ---------------- status ----------------
  function statusMenu(close) {
    const ids = allMembers();
    const st = { pickMember: true, mi: 0, stage: 'member' };
    st.update = () => {
      if (G.repeat('up') || (st.stage === 'view' && (G.repeat('left') || G.repeat('pgup')))) { st.mi = (st.mi + ids.length - 1) % ids.length; G.se('cursor'); }
      if (G.repeat('down') || (st.stage === 'view' && (G.repeat('right') || G.repeat('pgdn')))) { st.mi = (st.mi + 1) % ids.length; G.se('cursor'); }
      if (G.pressed('cancel')) { G.se('cancel'); if (st.stage === 'view') { st.stage = 'member'; st.full = false; } else close(); return; }
      if (G.pressed('ok') && st.stage === 'member') { G.se('ok'); st.stage = 'view'; st.full = true; }
    };
    st.draw = () => {
      if (st.stage === 'member') { U.win(16, H - 170, 170, 46); G.text('だれを見る？', 34, H - 156, C.TEXT); return; }
      const uid = ids[st.mi], m = G.party.members[uid], s = G.stats(uid), d = D.PARTY[uid];
      U.win(16, 16, W - 32, H - 32, { title: 'ステータス' });
      const fr = G.SPR.frames(uid); ctx.drawImage(fr.down[Math.floor(G.frame / 20) % 3], 40, 44, 64, 96);
      G.text(d.name, 130, 44, C.TEXT, 'left', 20); G.text('Lv ' + m.lv, 130, 74, C.GOLD);
      G.text(`属性　${D.ELEM[d.elem]}`, 220, 74, D.ELEMCOL[d.elem]);
      G.text(d.desc, 130, 104, C.TEXT, 'left', 14);
      const next = m.lv >= 50 ? 0 : G.expAt(m.lv + 1) - m.exp;
      G.text(`経験値 ${m.exp}　　次のレベルまで ${next}`, 130, 130, C.DIM, 'left', 14);
      const rows = [['HP', `${m.hp} / ${s.maxhp}`], ['MP', `${m.mp} / ${s.maxmp}`], ['力', s.pow], ['魔力', s.mag], ['攻撃', s.atk], ['守り', s.def], ['魔守', s.mdef], ['速さ', s.spd], ['命中', s.hit], ['回避', s.eva]];
      rows.forEach(([k, v], i) => { const x = 40 + (i % 2) * 280, y = 170 + Math.floor(i / 2) * 30; G.text(k, x, y, C.DIM); G.text(String(v), x + 220, y, C.TEXT, 'right'); });
      ['weapon', 'armor', 'helm', 'acc'].forEach((sl, i) => { const it = m.eq[sl] && D.ITEMS[m.eq[sl]]; const y = 330 + i * 26; G.text(SLOT[sl], 40, y, C.DIM, 'left', 14); G.text(it ? it.name : '—', 100, y, C.TEXT, 'left', 14); });
      const techs = G.techsOf(uid).map(t => t.name).join('　');
      G.text('技：' + (techs || 'なし'), 330, 330, C.TEXT, 'left', 12);
      const st2 = Object.keys(m.st || {}); if (st2.length) G.text('状態：' + st2.map(k => G.battle.ST_NAME[k]).join('、'), 330, 360, C.BAD, 'left', 12);
      G.text('◀ ▶ で切りかえ', W - 40, H - 44, C.DIM, 'right', 12);
    };
    return st;
  }

  // ---------------- letters ----------------
  function letterMenu(close) {
    const keys = () => Object.keys(D.LETTERS).filter(k => G.party.letters[k]);
    const list = new U.List({ rows: [], x: 16, y: 74, w: 280, vis: 8, empty: 'まだ手紙を預かっていない' });
    const refresh = () => { list.rows = keys().map(k => ({ label: D.LETTERS[k].name, id: k, color: G.party.delivered[k] ? C.DIM : C.TEXT, icon: 'letter' })); };
    refresh();
    const st = { full: true };
    st.update = () => { list.nav(); if (G.pressed('cancel')) { G.se('cancel'); close(); } };
    st.draw = () => {
      U.win(16, 16, W - 32, 44, { title: '手紙' });
      G.text(`宛先不明の手紙　届けた数 ${G.deliveredCount()} / ${Object.keys(D.LETTERS).length}`, 32, 30, C.TEXT, 'left', 14);
      U.win(16, 66, 290, H - 82); list.draw();
      U.win(318, 66, W - 334, H - 82, { mail: true });
      const cur = list.cur; if (!cur) return;
      const L = D.LETTERS[cur.id];
      G.text('宛先：' + L.to, 336, 84, C.GOLD, 'left', 14);
      // the letter paper
      const px = 336, py = 116, pw = W - 370, ph = H - 210;
      ctx.fillStyle = '#efe6d2'; ctx.fillRect(px, py, pw, ph);
      ctx.fillStyle = '#d8ccb0'; for (let y = py + 30; y < py + ph; y += 26) ctx.fillRect(px + 10, y, pw - 20, 1);
      G.wrap(L.text, pw - 28, 14).forEach((ln, i) => G.text(ln, px + 14, py + 12 + i * 26, '#2a2440', 'left', 14, null));
      if (G.party.delivered[cur.id]) {
        ctx.save(); ctx.translate(px + pw - 60, py + ph - 50); ctx.rotate(-0.25); ctx.strokeStyle = '#c9473d'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 34, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, 28, 0, Math.PI * 2); ctx.stroke(); G.text('配達済み', 0, -8, '#c9473d', 'center', 14, null); ctx.restore();
      } else G.text('話しかけて渡そう', px + pw - 8, py + ph + 10, C.DIM, 'right', 12);
    };
    return st;
  }

  // ---------------- order ----------------
  function orderMenu(close) {
    const st = { pickMember: true, mi: 0, first: null };
    const ids = () => allMembers();
    st.update = () => {
      const n = ids().length;
      if (G.repeat('up')) { st.mi = (st.mi + n - 1) % n; G.se('cursor'); }
      if (G.repeat('down')) { st.mi = (st.mi + 1) % n; G.se('cursor'); }
      if (G.pressed('cancel')) { G.se('cancel'); if (st.first != null) st.first = null; else close(); return; }
      if (G.pressed('ok')) {
        if (st.first == null) { st.first = st.mi; G.se('ok'); return; }
        const list = ids(); const a = list[st.first], b = list[st.mi];
        if (G.flags.lockOrder && (a === 'haru' || b === 'haru')) { G.se('buzz'); st.first = null; return; }
        [list[st.first], list[st.mi]] = [list[st.mi], list[st.first]];
        const n2 = Math.min(3, list.length);
        G.party.active = list.slice(0, n2);
        if (!G.party.active.some(id => G.party.members[id].hp > 0)) { [list[st.first], list[st.mi]] = [list[st.mi], list[st.first]]; G.party.active = list.slice(0, n2); G.se('buzz'); st.first = null; return; }
        G.se('ok'); st.first = null;
        const L = G.field.leader(); const tx = L.tx, ty = L.ty, dir = L.dir;
        G.field.actors = G.field.actors.filter(a2 => !a2.party);
        G.field.placeParty(tx, ty, dir);
      }
    };
    st.draw = () => {
      U.win(16, H - 200, 170, 76);
      G.text(st.first == null ? '入れかえる人' : 'だれと入れかえる？', 30, H - 186, C.TEXT, 'left', 14);
      G.text('上の3人が戦う', 30, H - 158, C.DIM, 'left', 12);
      if (st.first != null) { const y = 34 + st.first * 98; ctx.strokeStyle = C.GOLD; ctx.lineWidth = 2; ctx.strokeRect(214, y - 4, W - 240, 90); }
    };
    return st;
  }

  // ---------------- settings ----------------
  const CFG = [
    { k: 'lang', label: '言語', vals: ['ja', 'en'], show: v => v === 'ja' ? '日本語' : 'English' },
    { k: 'bgm', label: '音楽の音量', vals: [0, 0.2, 0.4, 0.6, 0.7, 0.85, 1], show: v => Math.round(v * 100) + '%' },
    { k: 'se', label: '効果音の音量', vals: [0, 0.2, 0.4, 0.6, 0.8, 1], show: v => Math.round(v * 100) + '%' },
    { k: 'msg', label: '文字の速さ', vals: [0, 1, 2, 3], show: v => ['ゆっくり', 'ふつう', 'はやい', '一瞬'][v] },
    { k: 'battle', label: '戦闘モード', vals: ['wait', 'active'], show: v => v === 'wait' ? 'ウェイト（技や道具を選ぶ間は時間が止まる）' : 'アクティブ（時間は止まらない）' },
    { k: 'bspeed', label: '戦闘の速さ', vals: [1, 2, 3, 4, 5], show: v => '●'.repeat(v) + '○'.repeat(5 - v) },
    { k: 'autorun', label: 'いつも走る', vals: [false, true], show: v => G.QUEST ? (v ? 'オン（「走る」で歩く）' : 'オフ（「走る」で走る）') : (v ? 'オン（シフトで歩く）' : 'オフ（シフトで走る）') },
    { k: 'shake', label: '画面のゆれ', vals: [true, false], show: v => v ? 'オン' : 'オフ' },
    { k: 'fullscreen', label: '全画面', vals: [false, true], show: () => 'F11 または Alt+Enter でも切りかえ' },
  ].filter(c => !(G.QUEST && c.k === 'fullscreen')); // Horizon OS windows have no fullscreen toggle
  function configMenu(close) {
    const st = { full: true, i: 0 };
    st.update = () => {
      if (G.repeat('up')) { st.i = (st.i + CFG.length - 1) % CFG.length; G.se('cursor'); }
      if (G.repeat('down')) { st.i = (st.i + 1) % CFG.length; G.se('cursor'); }
      const c = CFG[st.i];
      const dir = G.repeat('right') || G.pressed('ok') ? 1 : G.repeat('left') ? -1 : 0;
      if (dir) {
        if (c.k === 'fullscreen') { G.toggleFullscreen(); G.se('ok'); return; }
        let idx = c.vals.indexOf(G.cfg[c.k]); if (idx < 0) idx = 0;
        idx = (idx + dir + c.vals.length) % c.vals.length; G.cfg[c.k] = c.vals[idx];
        if (c.k === 'lang') G.i18n.setLang(G.cfg.lang);
        G.audio.applyVolume(); G.se('cursor'); G.store.set('cfg', G.cfg);
      }
      if (G.pressed('cancel')) { G.se('cancel'); G.store.set('cfg', G.cfg); close(); }
    };
    st.draw = () => {
      ctx.fillStyle = 'rgba(5,6,12,0.85)'; ctx.fillRect(0, 0, W, H);
      U.win(16, 16, W - 32, H - 32, { title: 'せってい' });
      CFG.forEach((c, i) => { const y = 46 + i * 40; G.text(c.label, 60, y, i === st.i ? C.TEXT : C.DIM); G.text(c.show(G.cfg[c.k]), 230, y, i === st.i ? C.GOLD : C.TEXT, 'left', c.k === 'battle' ? 13 : 16); if (i === st.i) U.cursor(30, y + 4); });
      G.text('◀ ▶ で変更', 32, H - 70, C.DIM, 'left', 12);
      if (G.QUEST) {
        G.text('Quest：画面の左右のボタンを指してトリガー（手ならつまむ）で操作します', 32, H - 52, C.DIM, 'left', 11);
        G.text('「早送り」を押している間は会話が早送りになります。キーボードやゲームパッドもつなげます', 32, H - 36, C.DIM, 'left', 11);
      } else {
      G.text('キーボード：矢印/WASD 移動　Z/Enter 決定　X/Esc もどる・メニュー　Shift 走る　E 長押し 会話早送り', 32, H - 52, C.DIM, 'left', 11);
      G.text('コントローラー：A 決定　B もどる（長押しで走る）　Y/スタート メニュー　RB 長押し 会話早送り', 32, H - 36, C.DIM, 'left', 11);
      }
    };
    return st;
  }
  function quitMenu(close, closeAll) {
    const st = { i: 1 };
    st.update = () => {
      if (G.repeat('up') || G.repeat('down')) { st.i = 1 - st.i; G.se('cursor'); }
      if (G.pressed('cancel')) { G.se('cancel'); close(); return; }
      if (G.pressed('ok')) { if (st.i === 0) { G.se('ok'); closeAll(); G.toTitle(); } else { G.se('cancel'); close(); } }
    };
    st.draw = () => { U.win(200, 180, 240, 110); G.text('セーブしていない進み具合は', 216, 192, C.TEXT, 'left', 13); G.text('なくなります。タイトルへ戻りますか？', 216, 212, C.TEXT, 'left', 13); G.text('もどる', 260, 238); G.text('つづける', 260, 262); U.cursor(230, 242 + st.i * 24); };
    return st;
  }

  // ---------------- shops ----------------
  G.shop = function (shopId) {
    return new Promise(res => {
      const st = { mode: 'menu', mi: 0, qty: 1 };
      const stock = D.SHOPS[shopId];
      const buyRows = () => stock.map(k => ({ label: D.ITEMS[k].name, right: D.ITEMS[k].price + 'G', icon: D.ITEMS[k].icon, id: k, disabled: D.ITEMS[k].price > G.party.gold }));
      const sellRows = () => Object.entries(G.party.items).filter(([k, n]) => n > 0 && D.ITEMS[k] && D.ITEMS[k].kind !== 'key' && D.ITEMS[k].price > 0).map(([k, n]) => ({ label: D.ITEMS[k].name, right: n, icon: D.ITEMS[k].icon, id: k }));
      let list = null;
      const o = {
        update() {
          if (st.mode === 'menu') {
            if (G.repeat('up')) { st.mi = (st.mi + 2) % 3; G.se('cursor'); }
            if (G.repeat('down')) { st.mi = (st.mi + 1) % 3; G.se('cursor'); }
            if (G.pressed('cancel') || (G.pressed('ok') && st.mi === 2)) { G.se('cancel'); G.consumeAll(); G.pop(o); res(); return; }
            if (G.pressed('ok')) { G.se('ok'); st.mode = st.mi === 0 ? 'buy' : 'sell'; list = new U.List({ rows: st.mode === 'buy' ? buyRows() : sellRows(), x: 16, y: 74, w: 360, vis: 9, empty: '売れるものがない' }); }
            return;
          }
          if (st.mode === 'qty') {
            const it = D.ITEMS[list.cur.id]; const price = st.sell ? Math.floor(it.price / 2) : it.price;
            const max = st.sell ? G.count(list.cur.id) : Math.min(99 - G.count(list.cur.id), Math.floor(G.party.gold / price));
            if (G.repeat('up') || G.repeat('right')) { st.qty = Math.min(max, st.qty + (G.repeat('right') ? 10 : 1)); G.se('cursor'); }
            if (G.repeat('down') || G.repeat('left')) { st.qty = Math.max(1, st.qty - (G.repeat('left') ? 10 : 1)); G.se('cursor'); }
            if (G.pressed('cancel')) { G.se('cancel'); st.mode = st.sell ? 'sell' : 'buy'; return; }
            if (G.pressed('ok')) {
              if (st.sell) { G.removeItem(list.cur.id, st.qty); G.party.gold += price * st.qty; }
              else { G.addItem(list.cur.id, st.qty); G.party.gold -= price * st.qty; }
              G.se('buy'); st.mode = st.sell ? 'sell' : 'buy'; list.rows = st.sell ? sellRows() : buyRows(); if (list.i >= list.rows.length) list.i = Math.max(0, list.rows.length - 1);
            }
            return;
          }
          list.nav();
          if (G.pressed('cancel')) { G.se('cancel'); st.mode = 'menu'; return; }
          if (G.pressed('ok') && list.cur) {
            const it = D.ITEMS[list.cur.id];
            if (st.mode === 'buy' && it.price > G.party.gold) { G.se('buzz'); return; }
            G.se('ok'); st.sell = st.mode === 'sell'; st.qty = 1; st.mode = 'qty';
          }
        },
        draw() {
          ctx.fillStyle = 'rgba(5,6,12,0.5)'; ctx.fillRect(0, 0, W, H);
          U.win(16, 16, W - 32, 44, { title: 'お店' });
          const cur = list && list.cur && D.ITEMS[list.cur.id];
          G.text(cur ? cur.desc : 'いらっしゃい。何にする？', 32, 30, C.TEXT, 'left', 14);
          U.win(W - 180, H - 64, 164, 48); G.text(G.party.gold + ' G', W - 32, H - 50, C.GOLD, 'right');
          if (st.mode === 'menu') { U.win(16, 66, 180, 110); ['買う', '売る', 'やめる'].forEach((s, i) => G.text(s, 60, 80 + i * 30)); U.cursor(30, 84 + st.mi * 30); return; }
          U.win(16, 66, 370, H - 82); list.draw(st.mode !== 'qty');
          // who can equip, with stat change
          if (cur) {
            U.win(398, 66, W - 414, H - 146);
            G.text(`持っている数　${G.count(list.cur.id)}`, 414, 80, C.TEXT, 'left', 14);
            const slot = G.slotOf(cur);
            if (slot) allMembers().forEach((id, k) => {
              const y = 112 + k * 50; const fr = G.SPR.frames(id); ctx.drawImage(fr.down[0], 414, y - 6, 24, 36);
              if (!G.canEquip(id, list.cur.id)) { G.text('装備できない', 450, y + 4, C.DIM, 'left', 13); return; }
              const m = G.party.members[id], s = G.stats(id), eq = Object.assign({}, m.eq); eq[slot] = list.cur.id; const p = G.stats(id, eq);
              const k2 = slot === 'weapon' ? 'atk' : 'def', k3 = slot === 'weapon' ? 'matk' : 'mdef';
              const d1 = p[k2] - s[k2], d2 = p[k3] - s[k3];
              G.text(`${slot === 'weapon' ? '攻' : '守'} ${d1 >= 0 ? '+' : ''}${d1}`, 450, y + 4, d1 > 0 ? C.GOOD : d1 < 0 ? C.BAD : C.TEXT, 'left', 13);
              G.text(`${slot === 'weapon' ? '魔' : '魔守'} ${d2 >= 0 ? '+' : ''}${d2}`, 530, y + 4, d2 > 0 ? C.GOOD : d2 < 0 ? C.BAD : C.TEXT, 'left', 13);
              if (m.eq[slot] === list.cur.id) G.text('装備中', 598, y + 4, C.GOLD, 'left', 11);
            });
          }
          if (st.mode === 'qty') {
            const it = D.ITEMS[list.cur.id]; const price = st.sell ? Math.floor(it.price / 2) : it.price;
            U.win(150, 190, 340, 90, { title: st.sell ? '売る' : '買う' });
            G.text(`${it.name}　×${st.qty}`, 170, 210); G.text(`${price * st.qty} G`, 470, 240, C.GOLD, 'right');
            G.text('▲▼ 1　◀▶ 10', 170, 242, C.DIM, 'left', 12);
          }
        },
      };
      G.push(o);
    });
  };
  G.inn = async function (innId, who = null) {
    const price = D.INN[innId] || 10;
    const r = await G.ask(who, `ひと晩 ${price} G です。泊まっていきますか？`, ['泊まる', 'やめる'], { cancel: 1 });
    if (r !== 0) return;
    if (G.party.gold < price) { await G.say(who, 'お金が足りないようですね。'); return; }
    G.party.gold -= price;
    await G.fadeTo(1, 0.04); G.audio.stop(0.3); G.se('save'); G.healAll(); await G.wait(80);
    G.bgm(G.musicFor(G.field.map.def)); await G.fadeTo(0, 0.04);
    await G.say(who, 'おはようございます。いってらっしゃい。');
  };

  // ---------------- saving ----------------
  G.saveData = () => ({
    v: 1, party: G.party, flags: G.flags, map: G.field.map.id, x: G.field.leader().tx, y: G.field.leader().ty, dir: G.field.leader().dir,
    when: Date.now(), place: G.field.map.def.name, era: G.field.map.def.era,
  });
  G.loadData = async function (d) {
    if (!G.validSave(d)) { await G.toTitle(); return; }
    G.party = JSON.parse(JSON.stringify(d.party)); G.flags = JSON.parse(JSON.stringify(d.flags));
    for (const k of ['items', 'letters', 'delivered']) if (!G.party[k] || typeof G.party[k] !== 'object') G.party[k] = {};
    if (!Number.isFinite(G.party.gold)) G.party.gold = 0; if (!Number.isFinite(G.party.time)) G.party.time = 0;
    for (const m of Object.values(G.party.members)) { if (!m.eq) m.eq = {}; if (!m.st) m.st = {}; }
    G.party.active = G.party.active.filter(id => G.party.members[id]);
    G.mode = 'field'; G.field.actors = [];
    await G.field.warp(d.map, d.x, d.y, d.dir, { nobanner: false });
  };
  // a save is usable only if its core structure is intact
  G.validSave = d => !!(d && typeof d === 'object' && d.party && typeof d.party === 'object' && Array.isArray(d.party.active) && d.party.active.length &&
    d.party.members && typeof d.party.members === 'object' && d.party.active.every(id => d.party.members[id] && G.DATA.PARTY[id]) &&
    d.flags && typeof d.flags === 'object' && G.MAPS[d.map] && Number.isFinite(d.x) && Number.isFinite(d.y));
  function slotSummary(k) {
    let raw = null; try { raw = localStorage.getItem('ashita.save' + k); } catch (e) { }
    if (raw == null) return null;
    const d = G.store.get('save' + k, null);
    if (!G.validSave(d)) return { broken: true, text: '— 読みこめない記録 —', sub: '' };
    const L = G.party && d.party ? d.party : d.party;
    const lead = d.party.active[0]; const m = d.party.members[lead];
    return { d, text: `${G.eraLabel(d.era)}　${d.place}`, sub: `${G.memberName(lead)} Lv${m ? m.lv : '?'}　プレイ時間 ${fmtTime(d.party.time)}　届けた手紙 ${Object.values(d.party.delivered || {}).filter(Boolean).length}` };
  }
  G.slotScreen = function (mode) { // mode: save | load ; resolves slot index or -1
    return new Promise(res => {
      let i = Math.max(0, G.store.get('lastSlot', 0));
      const o = {
        update() {
          if (G.repeat('up')) { i = (i + 2) % 3; G.se('cursor'); }
          if (G.repeat('down')) { i = (i + 1) % 3; G.se('cursor'); }
          if (G.pressed('cancel')) { G.se('cancel'); G.consumeAll(); G.pop(o); res(-1); return; }
          if (G.pressed('ok')) {
            if (mode === 'load' && (!slotSummary(i) || slotSummary(i).broken)) { G.se('buzz'); return; }
            G.consumeAll(); G.pop(o); res(i);
          }
        },
        draw() {
          ctx.fillStyle = 'rgba(5,6,12,0.8)'; ctx.fillRect(0, 0, W, H);
          U.win(40, 40, W - 80, 40); G.text(mode === 'save' ? 'どこに記録しますか？' : 'どの記録から始めますか？', W / 2, 52, C.TEXT, 'center');
          for (let k = 0; k < 3; k++) {
            const y = 110 + k * 108; const sm = slotSummary(k);
            U.win(60, y, W - 120, 88, { mail: k === i });
            G.text(`記録 ${k + 1}`, 84, y + 12, C.GOLD, 'left', 14);
            if (sm && sm.broken) G.text(sm.text, 84, y + 40, C.BAD);
            else if (sm) { G.text(sm.text, 84, y + 34); G.text(sm.sub, 84, y + 58, C.DIM, 'left', 13); }
            else G.text('— まだ記録がない —', 84, y + 40, C.DIM);
            if (k === i) U.cursor(40, y + 38);
          }
        },
      };
      G.push(o);
    });
  };
  G.savePointMenu = async function () {
    G.se('save');
    const opts = ['記録する', '旅の毛布で休む', 'やめる'];
    const r = await G.ask(null, '消印のポストだ。手紙を出すと、ここまでの旅が記録される。', opts, { cancel: 2 });
    if (r === 0) {
      const k = await G.slotScreen('save'); if (k < 0) return;
      const ok = G.store.set('save' + k, G.saveData()); G.store.set('lastSlot', k);
      G.se(ok ? 'stamp' : 'buzz'); await G.say(null, ok ? '旅の記録を投函した。' : '記録できなかった。空き容量を確認してください。');
    } else if (r === 1) {
      if (!G.hasItem('blanket')) { await G.say(null, '旅の毛布を持っていない。'); return; }
      G.removeItem('blanket', 1); await restScene();
    }
  };

  // ---------------- title ----------------
  G.toTitle = async function () {
    G.overlays.length = 0; G.cutscene = 0; G.field.lock = 0; G.field.map = null; G.battle.active = false;
    G.mode = 'title';
    G.bgm('title', { restart: true });
    await G.fadeTo(0, 0.04);
    const hasSave = [0, 1, 2].some(k => G.validSave(G.store.get('save' + k, null)));
    let clear = G.store.get('clear', null);
    if (!(clear && typeof clear === 'object' && clear.members && typeof clear.members === 'object' && Object.values(clear.members).every(m => m && Number.isFinite(m.lv) && m.eq && typeof m.eq === 'object'))) clear = null;
    const items = ['はじめから']; if (hasSave) items.push('つづきから'); if (clear) items.push('強くてはじめから'); items.push('せってい'); if (window.ashitaNative) items.push('ゲーム終了');
    let i = hasSave ? 1 : 0;
    const stars = []; const r = G.rng(3); for (let k = 0; k < 120; k++) stars.push([r() * W, r() * H * 0.7, r()]);
    const o = {
      update() {
        if (G.repeat('up')) { i = (i + items.length - 1) % items.length; G.se('cursor'); }
        if (G.repeat('down')) { i = (i + 1) % items.length; G.se('cursor'); }
        if (G.pressed('ok')) {
          const it = items[i]; G.se('ok'); G.consumeAll();
          if (it === 'はじめから') { G.pop(o); G.newGame(); }
          else if (it === '強くてはじめから') { G.pop(o); G.newGame(clear); }
          else if (it === 'つづきから') { G.slotScreen('load').then(async k => { if (k < 0) return; G.store.set('lastSlot', k); G.pop(o); await G.fadeTo(1, 0.06); await G.loadData(G.store.get('save' + k)); }); }
          else if (it === 'ゲーム終了') { window.ashitaNative.quit(); }
          else if (it === 'せってい') { const sub = configMenu(() => { G.pop(cw); }); const cw = { update: sub.update, draw: sub.draw }; G.push(cw); }
        }
      },
      draw() {
        const gr = ctx.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#0a0e24'); gr.addColorStop(0.6, '#1c2450'); gr.addColorStop(1, '#3a3058');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
        for (const [x, y, b] of stars) { ctx.globalAlpha = 0.4 + Math.sin(G.frame / 30 + b * 9) * 0.3; ctx.fillStyle = '#fff6e0'; ctx.fillRect(Math.round(x), Math.round(y), b > 0.85 ? 2 : 1, b > 0.85 ? 2 : 1); }
        ctx.globalAlpha = 1;
        // sea and lighthouse silhouette
        ctx.fillStyle = '#0d1430'; ctx.fillRect(0, 360, W, 120);
        for (let x = 0; x < W; x += 6) { ctx.fillStyle = 'rgba(160,190,255,0.12)'; ctx.fillRect(x, 370 + Math.round(Math.sin(x / 30 + G.frame / 40) * 2) + (x % 18), 4, 1); }
        ctx.fillStyle = '#05081a'; ctx.beginPath(); ctx.moveTo(430, 362); ctx.lineTo(640, 300); ctx.lineTo(640, 362); ctx.fill();
        ctx.fillRect(540, 230, 22, 80); ctx.fillRect(534, 222, 34, 10);
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; const a = G.frame / 90; ctx.globalAlpha = 0.18; ctx.fillStyle = '#fff4c0';
        ctx.beginPath(); ctx.moveTo(551, 216); ctx.lineTo(551 + Math.cos(a) * 700, 216 + Math.sin(a) * 120 - 40); ctx.lineTo(551 + Math.cos(a) * 700, 216 + Math.sin(a) * 120 + 40); ctx.fill(); ctx.restore();
        ctx.fillStyle = '#fff4c0'; ctx.fillRect(546, 212, 10, 8);
        // the letter
        const lx = 92, ly = 92;
        ctx.save(); ctx.translate(lx + 120, ly + 70); ctx.rotate(-0.05);
        ctx.fillStyle = '#0b0f1e'; ctx.fillRect(-126, -66, 256, 140);
        ctx.fillStyle = '#efe6d2'; ctx.fillRect(-122, -70, 248, 136);
        ctx.fillStyle = '#d8ccb0'; ctx.beginPath(); ctx.moveTo(-122, -70); ctx.lineTo(2, 8); ctx.lineTo(126, -70); ctx.lineTo(126, -64); ctx.lineTo(2, 14); ctx.lineTo(-122, -64); ctx.fill();
        for (let k = -122; k < 126; k += 12) { ctx.fillStyle = (k / 12) % 2 ? '#3765b0' : '#c9473d'; ctx.fillRect(k, 60, 6, 6); }
        ctx.strokeStyle = '#c9473d'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(80, -22, 26, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(80, -22, 20, 0, Math.PI * 2); ctx.stroke();
        G.text('2406', 80, -34, '#c9473d', 'center', 12, null); G.text('ハスネ', 80, -18, '#c9473d', 'center', 10, null);
        ctx.restore();
        // title
        G.text('ときわたりの郵便屋', W / 2 + 2, 258, '#0b0f1e', 'center', 48, null);
        G.text('ときわたりの郵便屋', W / 2, 256, '#f3ead6', 'center', 48, null);
        if (G.lang === 'ja') G.text('Courier of Hours', W / 2, 314, '#e2b04a', 'center', 14, null); else G.rawText('ときわたりの郵便屋', W / 2, 314, '#e2b04a', 'center', 14, null);
        items.forEach((s, k) => G.text(s, W / 2, 352 + k * 26, k === i ? '#f3ead6' : '#8f8aa6', 'center'));
        U.cursor(W / 2 - G.tw(items[i]) / 2 - 30, 356 + i * 26);
        G.text('© 2026 SuedoGaming', W - 12, H - 20, '#5a587a', 'right', 10, null);
      },
    };
    G.push(o);
  };
  G.gameOver = async function () {
    G.overlays.length = 0;
    await G.fadeTo(1, 0.03);
    G.mode = 'gameover';
    let i = 0; const hasSave = [0, 1, 2].some(k => G.validSave(G.store.get('save' + k, null)));
    const items = hasSave ? ['最後の記録から', 'タイトルへ'] : ['タイトルへ'];
    const o = {
      update() {
        if (G.repeat('up') || G.repeat('down')) { i = (i + 1) % items.length; G.se('cursor'); }
        if (G.pressed('ok')) { G.se('ok'); G.consumeAll(); G.pop(o); if (items[i] === 'タイトルへ') G.toTitle(); else { const k = G.store.get('lastSlot', 0); const cand = [k, 0, 1, 2].map(n => G.store.get('save' + n, null)); const d = cand.find(x => G.validSave(x)); if (d) G.loadData(d); else G.toTitle(); } }
      },
      draw() {
        ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H);
        G.text('手紙は、届かなかった。', W / 2, 170, '#c8c0d8', 'center', 24);
        items.forEach((s, k) => G.text(s, W / 2, 260 + k * 30, k === i ? C.TEXT : C.DIM, 'center'));
        U.cursor(W / 2 - 90, 264 + i * 30);
      },
    };
    G.push(o);
    await G.fadeTo(0, 0.03);
  };
})();
