'use strict';
// UI: windows, dialogue, choices
(function () {
  const U = G.ui = {};
  const PAPER = '#efe6d2', INK = '#18203a', RED = '#c9473d', BLUE = '#3765b0', GOLD = '#e2b04a';
  U.COL = { PAPER, INK, RED, BLUE, GOLD, TEXT: '#f3ead6', DIM: '#8f8aa6', GOOD: '#7ee0a0', BAD: '#ff8a8a' };

  // airmail-striped border pattern
  let stripe = null;
  function stripePattern() {
    if (stripe) return stripe;
    const [c, g] = G.art.canvas(16, 16);
    g.fillStyle = PAPER; g.fillRect(0, 0, 16, 16);
    for (let i = -16; i < 32; i += 8) {
      g.fillStyle = (i / 8) % 2 ? BLUE : RED;
      g.beginPath(); g.moveTo(i, 16); g.lineTo(i + 4, 16); g.lineTo(i + 20, 0); g.lineTo(i + 16, 0); g.fill();
    }
    stripe = ctx.createPattern(c, 'repeat'); return stripe;
  }
  // window: deep navy panel, thin paper rule, optional airmail stripes
  U.win = function (x, y, w, h, opt = {}) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    ctx.save();
    ctx.globalAlpha = opt.alpha != null ? opt.alpha : 1;
    if (opt.mail) { ctx.fillStyle = stripePattern(); ctx.fillRect(x - 5, y - 5, w + 10, h + 10); ctx.fillStyle = PAPER; ctx.fillRect(x - 2, y - 2, w + 4, h + 4); }
    else { ctx.fillStyle = '#0b0f1e'; ctx.fillRect(x - 3, y - 3, w + 6, h + 6); ctx.fillStyle = '#c8bfa8'; ctx.fillRect(x - 2, y - 2, w + 4, h + 4); }
    const gr = ctx.createLinearGradient(0, y, 0, y + h);
    gr.addColorStop(0, '#222c52'); gr.addColorStop(1, '#141a33');
    ctx.fillStyle = gr; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.fillRect(x, y, w, 2);
    if (opt.title) {
      const tw = G.tw(opt.title, 12) + 20;
      ctx.fillStyle = PAPER; ctx.fillRect(x + 10, y - 9, tw, 16); ctx.fillStyle = INK; ctx.fillRect(x + 11, y - 8, tw - 2, 14);
      G.text(opt.title, x + 20, y - 7, GOLD, 'left', 12, null);
    }
    ctx.restore();
  };
  // postage-stamp frame (perforated edges) used for banners and the speaker tag
  U.stampFrame = function (x, y, w, h, fill = '#18203a') {
    x = Math.round(x); y = Math.round(y);
    ctx.fillStyle = PAPER; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = '#05060c';
    for (let i = 4; i < w - 2; i += 8) { ctx.beginPath(); ctx.arc(x + i, y, 2.2, 0, Math.PI * 2); ctx.arc(x + i, y + h, 2.2, 0, Math.PI * 2); ctx.fill(); }
    for (let j = 4; j < h - 2; j += 8) { ctx.beginPath(); ctx.arc(x, y + j, 2.2, 0, Math.PI * 2); ctx.arc(x + w, y + j, 2.2, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = fill; ctx.fillRect(x + 4, y + 4, w - 8, h - 8);
  };
  // small envelope cursor
  U.cursor = function (x, y) {
    const b = Math.round(Math.sin(G.frame / 6) * 2);
    x = Math.round(x + b); y = Math.round(y);
    ctx.fillStyle = '#0b0f1e'; ctx.fillRect(x - 1, y - 1, 16, 12);
    ctx.fillStyle = PAPER; ctx.fillRect(x, y, 14, 10);
    ctx.fillStyle = '#a89878'; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 7, y + 6); ctx.lineTo(x + 14, y); ctx.lineTo(x + 14, y + 1); ctx.lineTo(x + 7, y + 7); ctx.lineTo(x, y + 1); ctx.fill();
    ctx.fillStyle = RED; ctx.fillRect(x + 10, y + 2, 3, 3);
  };
  U.bar = function (x, y, w, h, v, max, col, back = '#0b0f1e') {
    ctx.fillStyle = back; ctx.fillRect(x, y, w, h);
    const f = Math.max(0, Math.min(1, max ? v / max : 0));
    ctx.fillStyle = col; ctx.fillRect(x + 1, y + 1, Math.round((w - 2) * f), h - 2);
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.fillRect(x + 1, y + 1, Math.round((w - 2) * f), 1);
  };
  U.icon = function (kind, x, y, s = 2) { const c = G.SPR.icon(kind); ctx.drawImage(c, Math.round(x), Math.round(y), c.width * s, c.height * s); };

  // ---------- overlay stack ----------
  G.push = o => { G.overlays.push(o); return o; };
  G.pop = o => { const i = G.overlays.indexOf(o); if (i >= 0) G.overlays.splice(i, 1); };
  G.updateOverlays = () => { const top = G.overlays[G.overlays.length - 1]; if (top && top.update) top.update(); for (const o of G.overlays) if (o !== top && o.tick) o.tick(); };
  G.drawOverlays = () => { for (const o of G.overlays) if (o.draw) o.draw(); };

  // ---------- dialogue ----------
  const VOICE = { 'リオ': 0, 'ノエ': 5, 'イオリ': 2, 'チック': 9, 'ポッコ': -5, 'ゴロウ': -7, 'カナタ': 4, 'とばり': -12, '母さん': 3 };
  G.say = function (name, text, opt = {}) {
    return new Promise(res => {
      const box = { x: 20, w: W - 40, h: 118 };
      box.y = opt.top ? 16 : H - box.h - 14;
      const pages = [];
      let expr = opt.face || (G.guessExpr ? G.guessExpr(String(text)) : 'normal');
      text = String(text).replace(/^\[(normal|smile|surprise|sad|firm)\]/, '');
      const portrait = name && G.portrait && G.portrait(name, expr);
      const textX = portrait ? 132 : 22;
      for (const chunk of String(text).split('|')) {
        const lines = G.wrap(chunk.trim(), box.w - 22 - textX);
        for (let i = 0; i < lines.length; i += 3) pages.push(lines.slice(i, i + 3));
      }
      let page = 0, shown = 0, wait = 0, ci = opt.start || 0;
      const speed = [0.5, 1, 2, 99][G.cfg.msg] || 1;
      const voice = VOICE[name] != null ? VOICE[name] : (opt.voice != null ? opt.voice : -2);
      if (opt.se) G.se(opt.se);
      const o = {
        kind: opt.choices ? 'ask' : 'say',
        update() {
          const total = pages[page].join('').length;
          if (shown < total) {
            const before = Math.floor(shown);
            shown = Math.min(total, shown + speed);
            if (Math.floor(shown) !== before && Math.floor(shown) % 2 === 0 && name) G.se('blip', voice);
            if (G.pressed('ok') || G.pressed('cancel') || (G.held('pgdn') && !opt.choices)) shown = total;
            return;
          }
          if (G.held('pgdn') && !opt.choices && !opt.auto) { if (++wait > 6) next(); return; }
          if (opt.auto) { if (++wait > opt.auto) next(); return; }
          if (opt.choices && page === pages.length - 1) {
            const n = opt.choices.length;
            if (G.repeat('up')) { ci = (ci + n - 1) % n; G.se('cursor'); }
            if (G.repeat('down')) { ci = (ci + 1) % n; G.se('cursor'); }
            if (G.pressed('ok')) { G.se('ok'); G.consume('ok'); G.pop(o); res(ci); }
            else if (G.pressed('cancel') && opt.cancel != null) { G.se('cancel'); G.consume('cancel'); G.pop(o); res(opt.cancel); }
            return;
          }
          if (G.pressed('ok') || G.pressed('cancel')) next();
        },
        draw() {
          U.win(box.x, box.y, box.w, box.h, { mail: true });
          if (name) {
            const tw = G.tw(name, 16) + 28, tx = box.x + 18, ty = box.y - 20;
            U.stampFrame(tx, ty, tw, 28, INK);
            G.text(name, tx + tw / 2, ty + 6, GOLD, 'center');
          }
          if (portrait) {
            const typing = shown < pages[page].join('').length;
            const img = G.portrait(name, expr, typing && Math.floor(G.frame / 5) % 2 === 0);
            ctx.fillStyle = '#0b0f1e'; ctx.fillRect(box.x + 12, box.y + 10, 100, 100);
            ctx.fillStyle = '#2a3460'; ctx.fillRect(box.x + 14, box.y + 12, 96, 96);
            ctx.drawImage(img, box.x + 14, box.y + 12, 96, 96);
          }
          let n = Math.floor(shown);
          pages[page].forEach((ln, i) => { const s = ln.slice(0, Math.max(0, n)); n -= ln.length; G.text(s, box.x + textX, box.y + 20 + i * 28); });
          const done = shown >= pages[page].join('').length;
          if (done && opt.choices && page === pages.length - 1) {
            const cw = Math.max(...opt.choices.map(t => G.tw(t))) + 60, chh = opt.choices.length * 28 + 20, cx = W - cw - 30, cy = box.y - chh - 14;
            U.win(cx, cy, cw, chh);
            opt.choices.forEach((t, k) => G.text(t, cx + 40, cy + 12 + k * 28, k === ci ? U.COL.TEXT : '#b8b0c8'));
            U.cursor(cx + 14, cy + 16 + ci * 28);
          } else if (done && !opt.auto) U.cursor(box.x + box.w - 34, box.y + box.h - 22 + (G.frame % 40 < 20 ? 0 : 2));
        },
      };
      function next() {
        G.consume('ok'); G.consume('cancel');
        if (page < pages.length - 1) { page++; shown = 0; wait = 0; return; }
        G.pop(o); res();
      }
      G.push(o);
    });
  };
  G.narrate = (text, opt) => G.say(null, text, opt);

  // ---------- choice ----------
  G.choose = function (options, opt = {}) {
    return new Promise(res => {
      let i = opt.start || 0;
      const w = Math.max(...options.map(s => G.tw(s))) + 60, h = options.length * 28 + 20;
      const x = opt.x != null ? opt.x : W - w - 30, y = opt.y != null ? opt.y : H - 140 - h - 10;
      const o = {
        update() {
          if (G.repeat('up')) { i = (i + options.length - 1) % options.length; G.se('cursor'); }
          if (G.repeat('down')) { i = (i + 1) % options.length; G.se('cursor'); }
          if (G.pressed('ok')) { G.se('ok'); G.consume('ok'); G.pop(o); res(i); }
          else if (G.pressed('cancel') && opt.cancel !== false) { G.se('cancel'); G.consume('cancel'); G.pop(o); res(opt.cancelValue != null ? opt.cancelValue : -1); }
        },
        draw() {
          U.win(x, y, w, h);
          options.forEach((s, k) => { G.text(s, x + 40, y + 12 + k * 28, k === i ? U.COL.TEXT : '#b8b0c8'); });
          U.cursor(x + 14, y + 16 + i * 28);
        },
      };
      G.push(o);
    });
  };
  G.ask = (name, text, choices, opt = {}) => G.say(name, text, Object.assign({ choices }, opt));

  // ---------- notice (centered one-liner) ----------
  G.notice = function (text, opt = {}) {
    return new Promise(res => {
      const w = G.tw(text) + 60, h = 46, x = (W - w) / 2, y = opt.y || 140;
      let t = 0;
      if (opt.se) G.se(opt.se);
      const o = {
        kind: 'notice',
        update() { t++; if ((t > 12 && (G.pressed('ok') || G.pressed('cancel'))) || (opt.auto && t > opt.auto)) { G.consume('ok'); G.consume('cancel'); G.pop(o); res(); } },
        draw() { U.win(x, y, w, h); if (opt.icon) U.icon(opt.icon, x + 12, y + 11); G.text(text, x + w / 2 + (opt.icon ? 10 : 0), y + 15, U.COL.TEXT, 'center'); },
      };
      G.push(o);
    });
  };

  // ---------- reusable vertical list ----------
  // rows: [{label, right, disabled, icon, data}]
  U.List = class {
    constructor(opt) { Object.assign(this, { i: 0, top: 0, rows: [], x: 0, y: 0, w: 200, rowH: 28, vis: 8, cols: 1 }, opt); }
    get cur() { return this.rows[this.i]; }
    clampTop() { if (this.i < this.top * this.cols) this.top = Math.floor(this.i / this.cols); if (this.i >= (this.top + this.vis) * this.cols) this.top = Math.floor(this.i / this.cols) - this.vis + 1; }
    nav() {
      const n = this.rows.length; if (!n) return false; let moved = false;
      if (G.repeat('down')) { this.i = Math.min(n - 1, this.i + this.cols); moved = true; if (this.i === n - 1 && G.rep && false) { } }
      if (G.repeat('up')) { this.i = Math.max(0, this.i - this.cols); moved = true; }
      if (this.cols > 1) { if (G.repeat('right')) { this.i = Math.min(n - 1, this.i + 1); moved = true; } if (G.repeat('left')) { this.i = Math.max(0, this.i - 1); moved = true; } }
      if (G.repeat('pgdn')) { this.i = Math.min(n - 1, this.i + this.vis * this.cols); moved = true; }
      if (G.repeat('pgup')) { this.i = Math.max(0, this.i - this.vis * this.cols); moved = true; }
      if (moved) { G.se('cursor'); this.clampTop(); }
      return moved;
    }
    draw(active = true) {
      const colW = (this.w - 20) / this.cols;
      for (let r = 0; r < this.vis; r++) for (let c = 0; c < this.cols; c++) {
        const k = (this.top + r) * this.cols + c; const row = this.rows[k]; if (!row) continue;
        const x = this.x + 36 + c * colW, y = this.y + r * this.rowH;
        let col = row.disabled ? '#6f6a86' : (row.color || U.COL.TEXT);
        let tx = x;
        if (row.icon) { U.icon(row.icon, x, y + 2, 2); tx += 30; }
        G.text(row.label, tx, y + 4, col);
        if (row.right != null) G.text(row.right, x + colW - 46, y + 4, row.disabled ? '#6f6a86' : '#d8d0e8', 'right');
        if (k === this.i && active) U.cursor(x - 26, y + 8);
      }
      const rowsTotal = Math.ceil(this.rows.length / this.cols);
      if (rowsTotal > this.vis) {
        const h = this.vis * this.rowH, x = this.x + this.w - 8;
        ctx.fillStyle = '#2a3460'; ctx.fillRect(x, this.y, 3, h);
        ctx.fillStyle = GOLD; ctx.fillRect(x, this.y + h * this.top / rowsTotal, 3, Math.max(8, h * this.vis / rowsTotal));
      }
      if (!this.rows.length && this.empty) G.text(this.empty, this.x + 36, this.y + 4, U.COL.DIM);
    }
  };
})();
