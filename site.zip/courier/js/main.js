'use strict';
// Boot
(function () {
  const F = G.field, B = G.battle;
  Object.assign(G.cfg, G.store.get('cfg', {}));
  if (!G.cfg.lang) G.cfg.lang = /^ja/i.test(navigator.language || '') ? 'ja' : 'en';
  G.i18n.setLang(G.cfg.lang);
  G.update = function () {
    if (G.party && (G.mode === 'field' || G.mode === 'battle') && !document.hidden) G.party.time++;
    G.updateOverlays();
    if (G.mode === 'field' || G.mode === 'story') { if (F.map) F.update(); if (G.updateRace) G.updateRace(); }
    else if (G.mode === 'battle') { F.updateParticles(); for (const a of F.actors) if (a.foe) a.anim++; B.update(); }
  };
  G.render = function () {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if ((G.mode === 'field' || G.mode === 'battle' || G.mode === 'story') && F.map) F.render();
    else { ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H); }
    if (G.mode === 'battle') B.drawUI();
    G.drawOverlays();
    G.drawFade();
  };
  async function boot() {
    try {
      const ff = new FontFace('DotGothic16', 'url(fonts/DotGothic16-Regular.ttf)');
      document.fonts.add(await ff.load());
    } catch (e) { console.warn('font', e); }
    G.start();
    G.mode = 'title';
    // first screen: wait for a key so audio can start
    let t = 0;
    const press = {
      update() { t++; if (t > 20 && G.input.anyKey) { G.input.anyKey = false; G.consumeAll(); G.pop(press); G.audio.unlock(); G.fade.a = 1; G.toTitle(); } },
      draw() { ctx.fillStyle = '#05060c'; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 0.5 + Math.sin(G.frame / 20) * 0.4; G.text(G.QUEST ? (G.lang === 'ja' ? 'トリガーを引くと始まります' : 'Pull the trigger to begin') : (G.lang === 'ja' ? 'キーを押してください' : 'Press any key'), W / 2, H / 2 - 8, '#c8c0d8', 'center'); ctx.globalAlpha = 1; G.text('© 2026 SuedoGaming', W / 2, H - 40, '#5a587a', 'center', 10, null); },
    };
    G.fade.a = 0;
    G.input.anyKey = false;
    G.push(press);
    cv.focus();
  }
  if (window.__TEST__) { G.boot = boot; } else boot();
})();
