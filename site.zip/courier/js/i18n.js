'use strict';
// Localization. Game logic keeps using the Japanese strings; they are translated at the moment they are
// measured, wrapped or drawn. Templates (strings built with ${...}) are matched as patterns.
(function () {
  const L = G.i18n = { dict: new Map(), pats: [], cache: new Map() };
  G.lang = 'ja';
  L.setLang = l => { G.lang = l; L.cache.clear(); G.cfg.lang = l; };
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // register translations. keys containing {} are templates: {} matches any text, {n} matches a number
  L.add = function (obj) {
    for (let [jp, en] of Object.entries(obj)) {
      if (jp.includes('|') && en.split('|').length === jp.split('|').length) {
        const a = jp.split('|'), b = en.split('|'); const sub = {}; a.forEach((x, i) => sub[x.trim()] = b[i].trim()); L.add(sub);
      }
      if (jp.includes('{}') || jp.includes('{n}')) {
        let i = 0; const order = [];
        const re = '^' + esc(jp).replace(/\\\{\\\}|\\\{n\\\}|\{\}|\{n\}/g, m => { order.push(i++); return m.includes('n') ? '(-?[0-9][0-9.,:%]*)' : '([\\s\\S]+?)'; }) + '$';
        L.pats.push({ re: new RegExp(re), en, score: jp.replace(/\{\}|\{n\}/g, '').length });
        L.pats.sort((a, b) => b.score - a.score); // most specific pattern first
      } else L.dict.set(jp, en);
    }
  };
  const JP = /[\u3040-\u30ff\u3400-\u9fff\uff01-\uff60\u3000-\u303f]/;
  G.tr = function (s) {
    if (G.lang === 'ja' || s == null) return s;
    s = String(s);
    if (!JP.test(s)) return s;
    let v = L.cache.get(s); if (v !== undefined) return v;
    v = L.dict.get(s);
    if (v === undefined) {
      for (const p of L.pats) {
        const m = p.re.exec(s);
        if (m) { let k = 1; v = p.en.replace(/\{\}|\{n\}/g, () => G.tr(m[k++])); break; }
      }
    }
    if (v === undefined) {
      // multi-page dialogue (|) and multi-line text: translate the parts
      if (s.includes('|')) v = s.split('|').map(x => G.tr(x.trim())).join('|');
      else if (s.includes('\n')) v = s.split('\n').map(x => G.tr(x)).join('\n');
      else { v = s; if (L.report) L.report(s); }
    }
    L.cache.set(s, v);
    return v;
  };
  // patch text helpers so everything drawn on screen is translated
  const _text = G.text, _tw = G.tw, _wrap = G.wrap;
  G.rawText = _text;
  G.text = (s, ...a) => _text(G.tr(s), ...a);
  G.tw = (s, size) => _tw(G.tr(String(s)), size);
  G.wrap = function (s, maxW, size = 16) {
    s = G.tr(s);
    if (G.lang === 'ja' || JP.test(s)) return _wrap(s, maxW, size);
    // word wrap for languages that use spaces
    const out = [];
    for (const para of String(s).split('\n')) {
      let line = '';
      for (const word of para.split(' ')) {
        const t = line ? line + ' ' + word : word;
        if (_tw(t, size) > maxW && line) { out.push(line); line = word; } else line = t;
      }
      out.push(line);
    }
    return out;
  };
})();
