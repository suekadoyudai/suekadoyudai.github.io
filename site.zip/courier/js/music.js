'use strict';
// Original soundtrack for ときわたりの郵便屋. Songs are written as chord charts + melodies and compiled to note events.
(function () {
  const PC = { c: 0, d: 2, e: 4, f: 5, g: 7, a: 9, b: 11 };
  function noteMidi(tok) {
    const m = /^([a-gA-G])([#b]?)(-?\d)$/.exec(tok);
    if (!m) throw new Error('bad note ' + tok);
    let pc = PC[m[1].toLowerCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
    return 12 * (parseInt(m[3], 10) + 1) + pc;
  }
  const QUAL = {
    '': [0, 4, 7], 'm': [0, 3, 7], '7': [0, 4, 7, 10], 'm7': [0, 3, 7, 10], 'maj7': [0, 4, 7, 11], 'sus4': [0, 5, 7], 'sus2': [0, 2, 7],
    'dim': [0, 3, 6], 'm7b5': [0, 3, 6, 10], 'aug': [0, 4, 8], 'add9': [0, 4, 7, 14], 'madd9': [0, 3, 7, 14], '7sus4': [0, 5, 7, 10], '6': [0, 4, 7, 9], 'dim7': [0, 3, 6, 9],
  };
  function parseChord(sym) {
    const m = /^([A-G])([#b]?)([^/]*)(?:\/([A-G][#b]?))?$/.exec(sym);
    if (!m) throw new Error('bad chord ' + sym);
    const root = (PC[m[1].toLowerCase()] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + 12) % 12;
    const iv = QUAL[m[3]]; if (!iv) throw new Error('bad quality ' + sym);
    let bass = root;
    if (m[4]) bass = (PC[m[4][0].toLowerCase()] + (m[4][1] === '#' ? 1 : m[4][1] === 'b' ? -1 : 0) + 12) % 12;
    return { root, iv, bass };
  }
  // chords: 'G | D/F# | Em C:8 ...' -> [{t, d, ch}]
  function parseChords(str, meter) {
    const out = []; let t = 0;
    str.split('|').map(s => s.trim()).filter(Boolean).forEach(bar => {
      const items = bar.split(/\s+/).map(x => { const [sym, d] = x.split(':'); return { sym, d: d ? +d : 0 }; });
      const fixed = items.reduce((a, b) => a + b.d, 0), free = items.filter(i => !i.d).length;
      items.forEach(i => { const d = i.d || (meter - fixed) / free; out.push({ t, d, ch: parseChord(i.sym) }); t += d; });
    });
    return out;
  }
  function parseMel(str, inst, vol, out, shift = 0) {
    let t = 0, d = 4; const warn = [];
    for (const tok of str.split(/\s+/).filter(Boolean)) {
      if (tok === '|') continue;
      const [n, dd] = tok.split(':'); if (dd) d = +dd;
      if (n === 'r') { t += d; continue; }
      if (n === '-') { const last = out[out.length - 1]; if (last) last.d += d; t += d; continue; }
      out.push({ t, d, m: noteMidi(n) + shift, inst, v: vol });
      t += d;
    }
    return t;
  }
  function chordTones(ch, oct, n = 4) {
    const base = 12 * (oct + 1) + ch.root;
    const tones = ch.iv.map(i => base + i);
    while (tones.length < n) tones.push(tones[tones.length - (ch.iv.length)] + 12);
    return tones;
  }
  function genBass(chords, style, oct, inst, vol, out, meter) {
    for (const c of chords) {
      const r = 12 * (oct + 1) + c.ch.bass, f = 12 * (oct + 1) + c.ch.root + 7, o = r + 12;
      const third = 12 * (oct + 1) + c.ch.root + c.ch.iv[1];
      const push = (dt, d, m, v = 1) => { if (dt < c.d) out.push({ t: c.t + dt, d: Math.min(d, c.d - dt), m, inst, v: vol * v }); };
      if (style === 'whole') push(0, c.d, r);
      else if (style === 'half') for (let k = 0; k < c.d; k += 8) push(k, 8, (k / 8) % 2 ? f - 12 : r);
      else if (style === 'root4') for (let k = 0; k < c.d; k += 4) push(k, 3, r);
      else if (style === 'root8') for (let k = 0; k < c.d; k += 2) push(k, 2, r, k % 4 ? 0.8 : 1);
      else if (style === 'oct8') for (let k = 0; k < c.d; k += 2) push(k, 2, (k / 2) % 2 ? o : r);
      else if (style === 'rf4') for (let k = 0; k < c.d; k += 4) push(k, 3, (k / 4) % 2 ? f - 12 : r);
      else if (style === 'gallop') for (let k = 0; k < c.d; k += 4) { push(k, 2, r); push(k + 2, 1, r); push(k + 3, 1, k % 8 ? o : r); }
      else if (style === 'walk') { const seq = [r, third, f - 12, r + 10]; for (let k = 0; k < c.d; k += 4) push(k, 4, seq[(k / 4) % 4]); }
      else if (style === 'waltz') for (let k = 0; k < c.d; k += meter) { push(k, 4, r); }
      else if (style === 'drive') for (let k = 0; k < c.d; k += 1) push(k, 1, k % 4 === 2 ? o : r, k % 2 ? 0.7 : 1);
    }
  }
  function genArp(chords, style, oct, inst, vol, out, meter) {
    for (const c of chords) {
      const tn = chordTones(c.ch, oct, 4);
      const push = (dt, d, m, v = 1) => { if (dt < c.d) out.push({ t: c.t + dt, d: Math.min(d, c.d - dt), m, inst, v: vol * v }); };
      if (style === 'up16') { const seq = [tn[0], tn[1], tn[2], tn[3] || tn[0] + 12]; for (let k = 0; k < c.d; k++) push(k, 1, seq[k % 4], k % 4 ? 0.75 : 1); }
      else if (style === 'updown16') { const seq = [tn[0], tn[1], tn[2], tn[0] + 12, tn[2], tn[1]]; for (let k = 0; k < c.d; k++) push(k, 1, seq[k % 6], 0.8); }
      else if (style === 'up8') { const seq = [tn[0], tn[1], tn[2], tn[1]]; for (let k = 0; k < c.d; k += 2) push(k, 2, seq[(k / 2) % 4]); }
      else if (style === 'broken8') { const seq = [tn[0], tn[2], tn[1], tn[2]]; for (let k = 0; k < c.d; k += 2) push(k, 2, seq[(k / 2) % 4]); }
      else if (style === 'bell8') { const seq = [tn[0], tn[2], tn[0] + 12, tn[1] + 12]; for (let k = 0; k < c.d; k += 2) push(k, 2, seq[(k / 2) % 4]); }
      else if (style === 'stab') for (let k = 2; k < c.d; k += 4) for (let i = 0; i < 3; i++) push(k, 1, tn[i], 0.9);
      else if (style === 'pad') for (let i = 0; i < 3; i++) push(0, c.d, tn[i]);
      else if (style === 'waltz') for (let k = 0; k < c.d; k += meter) for (const b of [4, 8]) for (let i = 1; i < 3; i++) push(k + b, 3, tn[i], 0.8);
    }
  }
  function genDrums(pat, bars, meter, out, vol = 1) {
    const pats = Array.isArray(pat) ? pat : [pat];
    for (let b = 0; b < bars; b++) {
      const p = pats[b % pats.length]; if (!p) continue;
      for (let i = 0; i < p.length && i < meter; i++) {
        const ch = p[i]; if (ch === '.' || ch === ' ') continue;
        const accent = i % 4 === 0 ? 1 : 0.75;
        out.push({ t: b * meter + i, k: ch, v: vol * accent });
      }
    }
  }
  G.compileSong = function (def) {
    const meter = def.meter || 16;
    const chords = def.chords ? parseChords(def.chords, meter) : [];
    const bars = def.bars || Math.round(chords.reduce((a, c) => Math.max(a, c.t + c.d), 0) / meter);
    const evs = [];
    for (const p of def.parts) {
      if (p.mel) {
        const len = parseMel(p.mel, p.inst, p.v || 1, evs, p.shift || 0);
        if (Math.abs(len - bars * meter) > 0.01) console.warn('song', def.id, 'part', p.inst, 'length', len / meter, 'bars, expected', bars);
      } else if (p.bass) genBass(chords, p.bass, p.oct || 2, p.inst || 'bass', p.v || 1, evs, meter);
      else if (p.arp) genArp(chords, p.arp, p.oct || 4, p.inst || 'arp', p.v || 1, evs, meter);
      else if (p.drums) genDrums(p.drums, bars, meter, evs, p.v || 1);
    }
    evs.sort((a, b) => a.t - b.t);
    return { bpm: def.bpm, evs, len: bars * meter, loopFrom: (def.loopBar || 0) * meter, meter };
  };
  G._music = { noteMidi, parseChord, parseChords, parseMel };

  const S = G.songs = {};
  const song = (id, def) => { def.id = id; S[id] = def; };

  // ---------------- Title: 「ときわたりの郵便屋」 ----------------
  const TITLE_CH = 'D | A/C# | Bm | G | Em | A | D | A | G | A | F#m | Bm | Em | G | Asus4 | A';
  const TITLE_MEL = `f#5:6 e5:2 d5:4 a4:4 | e5:6 f#5:2 e5:8 | d5:6 c#5:2 b4:4 d5:4 | a4:12 r:4 |
    g4:4 b4:4 e5:4 g5:4 | f#5:6 e5:2 e5:8 | d5:4 f#5:4 a5:6 g5:2 | e5:12 r:4 |
    b5:6 a5:2 g5:4 d5:4 | c#6:6 b5:2 a5:8 | a5:4 f#5:4 c#5:4 f#5:4 | d6:12 c#6:2 b5:2 |
    b5:6 a5:2 g5:4 e5:4 | d5:4 g5:4 b5:4 a5:4 | a5:8 g5:4 e5:4 | a5:12 r:4`;
  song('title', {
    bpm: 92, chords: TITLE_CH, parts: [
      { inst: 'lead2', mel: TITLE_MEL, v: 1 },
      { bass: 'half', oct: 2 },
      { arp: 'up16', oct: 4, inst: 'arp', v: 0.9 },
      { arp: 'pad', oct: 3, inst: 'pad' },
      { drums: [null, null, null, null, null, null, null, null, 'k.......s.......', 'k.......s.....h.', 'k.......s.......', 'k.....k.s...h.h.', 'k.......s.......', 'k.......s.......', 'k.......s.......', 'k...s...s.s.ssss'], v: 0.7 },
    ],
  });
  song('ending', {
    bpm: 84, chords: TITLE_CH, parts: [
      { inst: 'flute', mel: TITLE_MEL, v: 1.1 },
      { inst: 'bell', mel: TITLE_MEL, v: 0.35, shift: 12 },
      { bass: 'half', oct: 2 },
      { arp: 'updown16', oct: 4, inst: 'arp', v: 0.7 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.2 },
      { drums: 'k...h...s...h...', v: 0.55 },
    ],
  });

  // ---------------- Hasune town (festival) ----------------
  song('town', {
    bpm: 126, chords: 'G | C | D | G | Em | C | A7 | D | G | B7 | Em | C | G | D | C:8 D:8 | G', parts: [
      { inst: 'lead', mel: `d5:2 g5:2 b5:2 g5:2 a5:3 g5:1 f#5:2 g5:2 | e5:4 c5:2 e5:2 g5:6 e5:2 | f#5:2 a5:2 d6:2 c6:2 b5:2 a5:2 f#5:2 d5:2 | g5:6 a5:2 b5:8 |
        b5:2 a5:2 g5:2 e5:2 g5:4 b5:4 | c6:3 b5:1 a5:2 g5:2 e5:8 | c#5:2 e5:2 a5:2 c#6:2 b5:2 a5:2 g5:2 e5:2 | f#5:4 a5:4 d5:8 |
        d5:2 g5:2 b5:2 d6:2 c6:2 b5:2 a5:2 g5:2 | f#5:2 d#5:2 f#5:2 a5:2 b5:6 a5:2 | g5:2 e5:2 b4:2 e5:2 g5:4 b5:4 | c6:4 b5:2 a5:2 g5:4 e5:4 |
        d5:4 g5:2 a5:2 b5:4 d6:4 | c6:3 b5:1 a5:4 f#5:4 d5:4 | e5:2 g5:2 c6:4 f#5:2 a5:2 d6:4 | g5:8 d5:4 g4:4` },
      { bass: 'rf4', oct: 2 },
      { arp: 'stab', oct: 4, inst: 'harm', v: 0.9 },
      { drums: ['k.h.s.h.k.h.s.hh', 'k.h.s.h.k.k.s.h.'], v: 0.6 },
    ],
  });

  // ---------------- Field ----------------
  song('field', {
    bpm: 138, chords: 'Am | F | G | Em | Am | F | Dm | E | F | G | Em | Am | F | G | E | E7', parts: [
      { inst: 'lead', mel: `a4:2 c5:2 e5:2 a5:6 g5:2 e5:2 | f5:4 e5:2 c5:2 a4:8 | b4:2 d5:2 g5:2 b5:6 a5:2 g5:2 | e5:8 g5:4 b5:4 |
        c6:6 b5:2 a5:4 e5:4 | f5:2 a5:2 c6:2 a5:2 g5:4 f5:4 | a5:3 g5:1 f5:2 e5:2 d5:4 f5:4 | e5:4 g#5:4 b5:4 e6:4 |
        c6:6 a5:2 f5:4 a5:4 | d6:6 b5:2 g5:4 b5:4 | b5:4 a5:2 g5:2 e5:4 g5:4 | a5:12 e5:2 a5:2 |
        c6:4 a5:4 f5:2 a5:2 c6:2 f6:2 | e6:4 d6:4 b5:2 g5:2 d6:4 | b5:6 g#5:2 e5:8 | d6:4 b5:4 g#5:4 e5:4` },
      { bass: 'oct8', oct: 2 },
      { arp: 'up16', oct: 4, inst: 'arp', v: 0.8 },
      { drums: ['k..hs.h.k.khs.h.', 'k..hs.h.k..hs.hh'], v: 0.6 },
    ],
  });

  // ---------------- Battle ----------------
  song('battle', {
    bpm: 164, loopBar: 2, chords: 'Em | B7 | Em | Em | C | D | Em | Em | C | B | Am | B | C | D | Em | C | Am | B', parts: [
      { inst: 'lead', mel: `r:16 | r:8 b4:2 d#5:2 f#5:2 a5:2 |
        e5:2 r:2 e5:2 g5:2 b5:4 a5:2 g5:2 | f#5:2 g5:2 a5:2 b5:2 e5:8 | e5:2 r:2 e5:2 g5:2 c6:4 b5:2 a5:2 | b5:2 a5:2 g5:2 f#5:2 d5:8 |
        e5:2 r:2 e5:2 g5:2 b5:4 e6:4 | d6:2 b5:2 g5:2 b5:2 d6:4 e6:4 | g6:4 e6:4 c6:4 e6:4 | f#6:8 d#6:8 |
        c6:6 b5:2 a5:4 e5:4 | d#5:4 f#5:4 b5:8 | e6:6 d6:2 c6:4 g5:4 | a5:4 d6:4 f#6:8 |
        g6:6 f#6:2 e6:4 b5:4 | c6:4 e6:4 g6:8 | a6:6 g6:2 e6:4 c6:4 | b5:4 d#6:4 f#6:4 a6:4` },
      { bass: 'gallop', oct: 2 },
      { arp: 'up16', oct: 4, inst: 'arp', v: 0.85 },
      { drums: ['k.h.s.h.k.h.s.h.', 'k.k.s.s.k.s.ssss', 'k.h.s.hkk.h.s.hs', 'k.h.s.hkk.hks.hs'], v: 0.7 },
    ],
  });

  // ---------------- Boss ----------------
  song('boss', {
    bpm: 170, loopBar: 2, chords: 'Dm | A7 | Dm | Dm | Bb | A | Dm | Dm | Gm | A | Bb | C | A | Dm | Gm | Bb | Eb | A7', parts: [
      { inst: 'lead', mel: `d4:2 d4:2 d4:2 d4:2 f4:2 f4:2 e4:2 e4:2 | c#4:4 e4:4 g4:4 a4:4 |
        d5:2 d5:2 f5:2 d5:2 a5:4 g#5:2 a5:2 | c6:4 a5:4 f5:4 e5:4 | d5:2 d5:2 f5:2 d5:2 bb5:4 a5:2 bb5:2 | c#6:6 e6:2 a5:8 |
        d6:2 r:2 d6:2 c6:2 a5:4 f5:4 | g5:2 a5:2 f5:2 d5:2 e5:4 c#5:4 | d5:4 g5:4 bb5:4 d6:4 | c#6:8 e6:8 |
        f6:6 d6:2 bb5:8 | g6:6 e6:2 c6:8 | e6:4 c#6:4 a5:4 e6:4 | f6:12 e6:2 d6:2 |
        d6:4 bb5:4 g5:4 bb5:4 | f6:4 d6:4 bb5:4 d6:4 | g6:6 f6:2 eb6:4 bb5:4 | c#6:4 e6:4 g6:4 a6:4` },
      { bass: 'oct8', oct: 2 },
      { arp: 'stab', oct: 4, inst: 'harm' },
      { arp: 'up16', oct: 5, inst: 'arp', v: 0.5 },
      { drums: ['k.hsk.hsk.hsk.ss', 'k.hsk.hsk.hskkss'], v: 0.7 },
    ],
  });

  // ---------------- Dungeon ----------------
  song('dungeon', {
    bpm: 96, chords: 'Dm | Dm | Bb | Bb | Gm | Gm | A | A | Dm | Dm | F | C | Bb | Gm | Asus4 | A', vol: 0.95, parts: [
      { inst: 'soft', mel: `r:4 a4:4 d5:4 e5:4 | f5:12 e5:4 | d5:8 f5:4 bb5:4 | a5:16 |
        g5:6 f5:2 d5:8 | bb4:4 d5:4 g5:8 | e5:6 c#5:2 a4:8 | r:16 |
        d6:6 c6:2 a5:8 | f5:4 a5:4 d6:8 | c6:6 a5:2 f5:8 | e5:4 g5:4 c6:8 |
        d6:6 bb5:2 f5:8 | g5:4 bb5:4 d6:8 | e6:8 d6:8 | c#6:16` },
      { bass: 'whole', oct: 2 },
      { arp: 'broken8', oct: 4, inst: 'pluck', v: 0.55 },
      { drums: 'k.......t.......', v: 0.5 },
    ],
  });

  // ---------------- Dead Letter Office (hub) — music-box waltz ----------------
  song('hub', {
    bpm: 84, meter: 12, chords: 'F | Am | Bb | F | Dm | Gm | C | C7 | F | A7 | Dm | Bb | Gm | C | F | F', parts: [
      { inst: 'bell', mel: `c6:4 a5:2 c6:2 f6:4 | e6:6 c6:2 a5:4 | d6:4 bb5:2 d6:2 f6:4 | c6:12 |
        a5:4 d6:4 f6:4 | g6:6 f6:2 d6:4 | e6:4 c6:4 g5:4 | bb5:8 a5:2 g5:2 |
        a5:4 c6:4 f6:4 | e6:6 c#6:2 a5:4 | d6:4 f6:4 a6:4 | g6:6 f6:2 d6:4 |
        bb5:4 d6:4 g6:4 | e6:6 g6:2 bb6:4 | a6:4 f6:4 c6:4 | f6:12`, v: 1 },
      { bass: 'waltz', oct: 3, inst: 'pluck', v: 0.9 },
      { arp: 'waltz', oct: 4, inst: 'bell', v: 0.35 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 0.6 },
    ],
  });

  // ---------------- 2406: the stopped town ----------------
  song('frozen', {
    bpm: 72, chords: 'Emadd9 | Cmaj7 | Am7 | B7sus4 | Em | Cmaj7 | F#m7b5 | B7', parts: [
      { inst: 'bell', mel: `b5:4 r:4 f#5:4 r:4 | g5:8 e5:8 | c6:4 r:4 b5:4 a5:4 | e5:16 |
        b5:4 r:4 e6:4 r:4 | d6:8 b5:8 | c6:4 a5:4 f#5:8 | d#5:16` },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.3 },
      { bass: 'whole', oct: 2, v: 0.7 },
      { drums: 'h.......h.......', v: 0.5 },
    ],
  });

  // ---------------- 806: Kingdom of Varn ----------------
  song('varn', {
    bpm: 112, chords: 'Dm | C | Dm | Am | Dm | C | G | Am | F | C | Dm | Am | F | G | Am | Dm', parts: [
      { inst: 'flute', mel: `d5:2 f5:2 a5:4 g5:2 f5:2 e5:4 | c5:2 e5:2 g5:4 f5:2 e5:2 d5:4 | a5:4 b5:2 c6:2 d6:4 a5:4 | c6:2 b5:2 a5:2 g5:2 e5:8 |
        d5:2 f5:2 a5:4 g5:2 f5:2 e5:4 | g5:2 a5:2 c6:4 b5:2 a5:2 g5:4 | b5:4 a5:2 g5:2 d5:4 b5:4 | a5:16 |
        c6:4 a5:2 c6:2 f6:4 e6:2 d6:2 | e6:4 c6:2 e6:2 g6:4 f6:2 e6:2 | d6:4 a5:4 f5:4 a5:4 | e6:8 c6:4 a5:4 |
        f5:2 a5:2 c6:4 a5:2 c6:2 f6:4 | g6:4 f6:2 e6:2 d6:4 b5:4 | c6:6 b5:2 a5:4 e5:4 | d5:16`, v: 1 },
      { bass: 'rf4', oct: 2 },
      { arp: 'broken8', oct: 4, inst: 'pluck', v: 0.8 },
      { drums: ['k..ht.h.k..ht.h.', 'k..ht.h.k.tht.hh'], v: 0.55 },
    ],
  });

  // ---------------- 前800: Sky islands ----------------
  song('sky', {
    bpm: 110, chords: 'F | G/F | Em7 | Am | F | G/F | Am | Am | Dm | C | Bb | F | Gm | Am | Bb | C', parts: [
      { inst: 'flute', mel: `c5:4 f5:4 a5:4 c6:4 | b5:6 a5:2 g5:4 d5:4 | e5:4 g5:4 b5:4 d6:4 | c6:8 a5:8 |
        a5:4 c6:4 f6:8 | e6:4 d6:4 b5:8 | c6:6 b5:2 a5:4 e5:4 | a5:16 |
        f5:4 a5:4 d6:4 f6:4 | e6:6 d6:2 c6:4 g5:4 | d6:4 f6:4 bb5:8 | a5:12 c6:4 |
        bb5:6 a5:2 g5:4 d6:4 | c6:6 b5:2 a5:4 e6:4 | d6:8 f6:8 | e6:8 g6:4 c6:4` },
      { bass: 'half', oct: 2 },
      { arp: 'updown16', oct: 5, inst: 'arp', v: 0.55 },
      { arp: 'pad', oct: 4, inst: 'pad', v: 0.8 },
      { drums: 'k.....h...s.....', v: 0.45 },
    ],
  });

  // ---------------- Emotional ----------------
  song('sad', {
    bpm: 70, chords: 'Am | F | C | G | Am | F | Dm | E', parts: [
      { inst: 'soft', mel: `e5:4 a5:4 b5:4 c6:4 | a5:12 g5:4 | e5:4 g5:4 c6:6 b5:2 | d6:16 |
        c6:4 b5:4 a5:4 e5:4 | f5:8 a5:6 g5:2 | f5:4 e5:4 d5:4 f5:4 | e5:16`, v: 1.2 },
      { bass: 'whole', oct: 2, v: 0.8 },
      { arp: 'up8', oct: 4, inst: 'pluck', v: 0.7 },
    ],
  });

  // ---------------- Stillness (とばり) ----------------
  song('stillness', {
    bpm: 60, chords: 'Cm | Ab/C | Fm/C | G/B | Cm | Db | Fm | G', parts: [
      { inst: 'bell', mel: `c6:8 b5:8 | ab5:8 g5:8 | f5:8 g5:8 | b4:16 | c6:8 eb6:8 | db6:8 c6:8 | ab5:8 f5:8 | g5:16`, v: 0.9 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.4 },
      { bass: 'whole', oct: 1, inst: 'bass', v: 0.6 },
    ],
  });

  // ---------------- Final battle ----------------
  song('final', {
    bpm: 176, loopBar: 2, chords: 'Cm | G | Cm | Ab | Bb | G | Cm | Ab | Fm | G | Eb | Bb | Cm | Ab | Fm | Db | G | G7', parts: [
      { inst: 'lead', mel: `c5:2 r:2 c5:2 r:2 c5:2 eb5:2 g5:2 c6:2 | b5:4 d6:4 f6:4 g6:4 |
        c5:2 eb5:2 g5:2 c6:2 b5:4 c6:2 d6:2 | eb6:6 c6:2 ab5:8 | bb5:2 d6:2 f6:2 bb5:2 d6:4 f6:4 | g6:6 f6:2 d6:4 b5:4 |
        c6:2 eb6:2 g6:2 c6:2 eb6:4 g6:4 | ab6:6 g6:2 eb6:4 c6:4 | f6:4 eb6:2 d6:2 c6:4 ab5:4 | b5:8 d6:8 |
        eb6:6 f6:2 g6:4 bb6:4 | f6:6 d6:2 bb5:8 | g6:4 eb6:4 c6:4 g6:4 | ab6:12 g6:2 f6:2 |
        f6:4 c6:4 ab5:4 c6:4 | db6:4 f6:4 ab6:8 | g6:6 f6:2 d6:4 b5:4 | g5:4 b5:4 d6:4 f6:4` },
      { bass: 'drive', oct: 2, v: 0.85 },
      { arp: 'up16', oct: 4, inst: 'arp', v: 0.8 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 0.9 },
      { drums: ['kkhsk.hskkhsk.ss', 'kkhsk.hskkhskkss'], v: 0.75 },
    ],
  });


  // ---------------- Area themes ----------------
  song('ember', {
    bpm: 132, chords: 'F#m | D | E | C#m | F#m | D | Bm | C#7', parts: [
      { inst: 'lead', mel: `f#5:2 r:2 f#5:2 a5:2 c#6:4 b5:2 a5:2 | d6:6 c#6:2 a5:8 | b5:2 r:2 b5:2 g#5:2 e5:4 g#5:4 | c#6:8 e6:8 |
        f#6:6 e6:2 c#6:4 a5:4 | d6:4 f#6:4 a6:8 | b5:4 d6:4 f#6:4 e6:4 | f6:8 c#6:8` },
      { bass: 'oct8', oct: 2 },
      { arp: 'up16', oct: 4, inst: 'arp', v: 0.7 },
      { drums: ['k..hs..hk..hs.hh', 'k..hs..hk.khs.ss'], v: 0.6 },
    ],
  });
  song('canal', {
    bpm: 88, chords: 'Am | Fmaj7 | Dm7 | E7 | Am | Fmaj7 | Bm7b5 | E7', vol: 0.95, parts: [
      { inst: 'pluck', mel: `e6:2 r:6 c6:2 r:6 | a5:4 r:4 e5:4 r:4 | f5:2 a5:2 c6:2 r:2 d6:8 | b5:16 |
        e6:2 r:2 e6:2 r:2 a6:4 g6:4 | e6:8 c6:8 | d6:4 f6:4 a5:8 | g#5:16`, v: 1.2 },
      { inst: 'bell', mel: `r:8 e6:2 r:6 | r:16 | r:8 a6:2 r:6 | r:16 | r:8 e7:2 r:6 | r:16 | r:8 f6:2 r:6 | r:16`, v: 0.35 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.2 },
      { bass: 'whole', oct: 2, v: 0.8 },
      { drums: 'h.......t.......', v: 0.4 },
    ],
  });
  song('garden', {
    bpm: 120, chords: 'G | F | C | G | Em | F | D | D7', parts: [
      { inst: 'lead2', mel: `g5:2 b5:2 d6:2 g6:2 f6:2 d6:2 b5:2 d6:2 | c6:2 f6:2 a6:2 f6:2 c6:4 a5:4 | e6:4 g6:4 e6:2 d6:2 c6:4 | d6:8 b5:4 g5:4 |
        e6:2 g6:2 b6:2 g6:2 e6:4 b5:4 | c6:4 a5:4 f5:4 a5:4 | f#5:2 a5:2 d6:2 f#6:2 a6:4 f#6:4 | c6:8 a5:8` },
      { inst: 'bell', mel: `g6:4 r:12 | f6:4 r:12 | e6:4 r:12 | d6:4 r:12 | e6:4 r:12 | c6:4 r:12 | d6:4 r:12 | c6:4 r:12`, v: 0.4 },
      { bass: 'rf4', oct: 2 },
      { arp: 'up16', oct: 4, inst: 'pluck', v: 0.45 },
      { drums: 'k.h.h.h.t.h.h.h.', v: 0.5 },
    ],
  });
  song('depths', {
    bpm: 76, chords: 'Cm | Ab | Eb | Bb | Cm | Fm | G | G', parts: [
      { inst: 'soft', mel: `g5:8 eb6:8 | c6:12 bb5:4 | g5:8 bb5:8 | f5:16 | g5:4 c6:4 eb6:4 d6:4 | c6:8 ab5:8 | b5:8 d6:8 | g5:16`, v: 1.1 },
      { inst: 'bell', mel: `c6:16 | ab5:16 | eb6:16 | d6:16 | c6:16 | f6:16 | d6:16 | b5:16`, v: 0.3 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.4 },
      { bass: 'whole', oct: 1, v: 0.8 },
      { drums: 'k...............', v: 0.35 },
    ],
  });

  // ---------------- Jingles ----------------
  song('victory', {
    bpm: 132, loop: false, chords: 'C | F:8 G:8 | C', parts: [
      { inst: 'lead', mel: 'c5:2 e5:2 g5:2 c6:8 r:2 | a5:2 c6:2 f6:4 d6:2 b5:2 g6:4 | c6:2 e6:2 g6:12' },
      { inst: 'lead2', mel: 'e4:2 g4:2 c5:2 e5:8 r:2 | f5:2 a5:2 c6:4 b5:2 g5:2 d6:4 | e5:2 g5:2 e6:12', v: 0.6 },
      { bass: 'root4', oct: 2 },
      { drums: ['k.s.k.s.k...c...', 'k.s.k.s.k.s.ssss', 'c...............'], v: 0.7 },
    ],
  });
  song('gameover', {
    bpm: 66, loop: false, chords: 'Am | F | Dm | E', parts: [
      { inst: 'soft', mel: 'e5:8 c5:8 | a4:8 c5:4 f5:4 | d5:8 f5:4 a5:4 | g#5:16' },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.2 },
      { bass: 'whole', oct: 2 },
    ],
  });
  song('rift', {
    bpm: 80, chords: 'Cdim7 | Ebdim7 | Cdim7 | B7', parts: [
      { inst: 'arp', mel: 'c5:1 eb5:1 gb5:1 a5:1 c6:1 a5:1 gb5:1 eb5:1 c5:1 eb5:1 gb5:1 a5:1 c6:1 eb6:1 gb6:1 a6:1 | eb5:16 | c5:16 | b4:16', v: 0.8 },
      { arp: 'pad', oct: 3, inst: 'pad', v: 1.5 },
      { drums: 'k...............', v: 0.6 },
    ],
  });
})();
