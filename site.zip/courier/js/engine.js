'use strict';
// ときわたりの郵便屋 — core engine
const W = 640, H = 480, TS = 16, SC = 2, TW = TS * SC;
// Meta Quest (Horizon OS) build: the Store package opens with ?quest=1; Quest Browser is detected too.
// There, controllers and hands are pointers, so on-screen buttons are shown (js/touchpad.js).
const QUEST = /OculusBrowser|Quest|Horizon ?OS/i.test(navigator.userAgent || '') || /[?&]quest=1\b/.test(location.search);
const G = window.G = {
  QUEST,
  frame: 0, mode: 'boot', overlays: [], waiters: [], flags: {}, vars: {},
  cutscene: 0, shake: 0, flash: null, fade: { a: 1, target: 1, speed: 0.05, color: '#000', res: null },
  cfg: { bgm: 0.7, se: 0.8, msg: 1, battle: 'wait', bspeed: 3, autorun: false, shake: true },
};

const cv = document.getElementById('screen');
cv.width = W; cv.height = H;
const ctx = cv.getContext('2d');
ctx.imageSmoothingEnabled = false;
G.ctx = ctx; G.cv = cv;

function fitCanvas() {
  const s = Math.min(innerWidth / W, innerHeight / H);
  const f = Math.floor(s);
  const use = (f >= 1 && s / f < 1.12) ? f : s; // prefer crisp integer scaling when it costs little space
  cv.style.width = Math.floor(W * use) + 'px';
  cv.style.height = Math.floor(H * use) + 'px';
}
addEventListener('resize', fitCanvas); fitCanvas();
G.fitCanvas = fitCanvas;

// ---------- random ----------
G.rng = function (seed) {
  let s = (seed >>> 0) || 0x9e3779b9;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
};
G.rand = Math.random;
G.ri = (a, b) => a + Math.floor(G.rand() * (b - a + 1));
G.clamp = (v, a, b) => v < a ? a : v > b ? b : v;
G.lerp = (a, b, t) => a + (b - a) * t;
G.ease = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

// ---------- input ----------
const KEYMAP = {
  ArrowUp: 'up', KeyW: 'up', ArrowDown: 'down', KeyS: 'down', ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
  KeyZ: ['ok'], Enter: ['ok'], Space: ['ok'], NumpadEnter: ['ok'],
  KeyX: ['cancel', 'menu'], Escape: ['cancel', 'menu'], Backspace: ['cancel'], KeyC: ['menu'], Tab: ['menu'],
  ShiftLeft: 'run', ShiftRight: 'run', KeyQ: 'pgup', KeyE: 'pgdn', PageUp: 'pgup', PageDown: 'pgdn',
};
const I = G.input = { held: {}, prev: {}, rep: {}, kb: {}, pad: {}, tap: {}, any: false, lastDevice: 'kb' };
const ACTIONS = ['up', 'down', 'left', 'right', 'ok', 'cancel', 'menu', 'run', 'pgup', 'pgdn'];
addEventListener('keydown', e => {
  const m = KEYMAP[e.code];
  if (m) { e.preventDefault(); (Array.isArray(m) ? m : [m]).forEach(a => { I.kb[a] = true; I.tap[a] = true; }); }
  if (e.code === 'F11' || (e.altKey && e.code === 'Enter')) { e.preventDefault(); toggleFullscreen(); }
  I.anyKey = true; I.lastDevice = 'kb'; document.body.classList.add('nocursor');
  G.audio && G.audio.unlock();
});
addEventListener('keyup', e => { const m = KEYMAP[e.code]; if (m) (Array.isArray(m) ? m : [m]).forEach(a => I.kb[a] = false); });
addEventListener('blur', () => { I.kb = {}; });
addEventListener('mousedown', () => { I.anyKey = true; G.audio && G.audio.unlock(); cv.focus(); });
addEventListener('mousemove', () => document.body.classList.remove('nocursor'));
function toggleFullscreen() {
  if (window.ashitaNative) { window.ashitaNative.toggleFullscreen(); return; }
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else document.documentElement.requestFullscreen().catch(() => {});
}
G.toggleFullscreen = toggleFullscreen;

function pollPad() {
  I.pad = {};
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const p of pads) {
    if (!p) continue;
    if (QUEST && (p.mapping !== 'standard' || /oculus|meta|quest|touch/i.test(p.id || ''))) continue;
    const b = i => p.buttons[i] && p.buttons[i].pressed;
    const ax = p.axes[0] || 0, ay = p.axes[1] || 0;
    const st = {
      up: b(12) || ay < -0.5, down: b(13) || ay > 0.5, left: b(14) || ax < -0.5, right: b(15) || ax > 0.5,
      ok: b(0), cancel: b(1), run: b(1), menu: b(3) || b(9) || b(2), pgup: b(4), pgdn: b(5),
    };
    let any = false;
    for (const k in st) if (st[k]) { I.pad[k] = true; any = true; }
    if (any) { I.lastDevice = 'pad'; I.anyKey = true; }
  }
}
function updateInput() {
  pollPad();
  for (const a of ACTIONS) {
    I.prev[a] = I.held[a];
    I.held[a] = !!(I.kb[a] || I.pad[a] || I.tap[a]);
    if (I.held[a]) I.rep[a] = (I.rep[a] || 0) + 1; else I.rep[a] = 0;
  }
  I.tap = {}; // a key pressed and released between two frames still counts as one press
}
G.pressed = a => I.held[a] && !I.prev[a];
G.held = a => !!I.held[a];
G.repeat = a => { const r = I.rep[a]; return r === 1 || (r > 16 && (r - 16) % 4 === 0); };
G.consume = a => { I.prev[a] = true; };
G.consumeAll = () => { for (const a of ACTIONS) I.prev[a] = I.held[a]; };

// ---------- timing ----------
G.wait = (n = 1) => new Promise(res => G.waiters.push({ n: Math.max(1, n | 0), res }));
G.until = fn => new Promise(res => G.waiters.push({ fn, res }));
function tickWaiters() {
  const ws = G.waiters; G.waiters = [];
  for (const w of ws) {
    if (w.fn) { if (w.fn()) w.res(); else G.waiters.push(w); }
    else if (--w.n <= 0) w.res(); else G.waiters.push(w);
  }
}
G.fadeTo = (a, speed = 0.06, color) => new Promise(res => {
  const f = G.fade; f.target = a; f.speed = speed; if (color) f.color = color;
  if (f.res) { const r = f.res; f.res = null; r(); }
  if (f.a === a) { res(); return; }
  f.res = res;
});

// ---------- text ----------
G.FONT = '"DotGothic16", "Noto Sans CJK JP", "Yu Gothic", sans-serif';
ctx.font = '16px ' + G.FONT;
const widthCache = new Map();
G.tw = (s, size = 16) => {
  const k = size + '|' + s; let v = widthCache.get(k);
  if (v === undefined) { ctx.save(); ctx.font = size + 'px ' + G.FONT; v = ctx.measureText(s).width; ctx.restore(); widthCache.set(k, v); }
  return v;
};
G.text = (s, x, y, col = '#f3ead6', align = 'left', size = 16, shadow = '#0b0f1e') => {
  s = String(s);
  ctx.font = size + 'px ' + G.FONT; ctx.textBaseline = 'top'; ctx.textAlign = align;
  x = Math.round(x); y = Math.round(y);
  if (shadow) { ctx.fillStyle = shadow; ctx.fillText(s, x + 1, y + 1); }
  ctx.fillStyle = col; ctx.fillText(s, x, y);
  ctx.textAlign = 'left';
};
const NOSTART = '、。，．・：；？！ー」』）】〉》ぁぃぅぇぉっゃゅょァィゥェォッャュョ…～!?,.)';
G.wrap = (s, maxW, size = 16) => {
  const out = [];
  for (const para of String(s).split('\n')) {
    let line = '';
    for (const ch of para) {
      const t = line + ch;
      if (G.tw(t, size) > maxW && line) {
        if (NOSTART.includes(ch)) { // kinsoku: pull punctuation onto the current line
          out.push(t); line = ''; continue;
        }
        out.push(line); line = ch;
      } else line = t;
    }
    out.push(line);
  }
  return out;
};

// ---------- loop ----------
G.update = () => {};
G.render = () => {};
let acc = 0, last = performance.now();
const STEP = 1000 / 60;
function loop(now) {
  acc += Math.min(100, now - last); last = now;
  let steps = 0;
  if (G.turbo) acc = STEP * G.turbo;
  while (acc >= STEP && steps < (G.turbo || 4)) {
    updateInput();
    G.frame++;
    try { G.update(); } catch (e) { console.error(e); }
    tickWaiters();
    const f = G.fade;
    if (f.a !== f.target) {
      f.a += Math.sign(f.target - f.a) * Math.min(Math.abs(f.target - f.a), f.speed);
      if (f.a === f.target && f.res) { const r = f.res; f.res = null; r(); }
    }
    if (G.shake > 0) G.shake--;
    acc -= STEP; steps++;
  }
  if (steps >= 4) acc = 0;
  try { G.render(); } catch (e) { console.error(e); }
  requestAnimationFrame(loop);
}
G.start = () => requestAnimationFrame(loop);

G.drawFade = () => {
  const f = G.fade;
  if (f.a > 0) { ctx.globalAlpha = f.a; ctx.fillStyle = f.color; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  if (G.flash) {
    ctx.globalAlpha = G.flash.a; ctx.fillStyle = G.flash.c; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1;
    G.flash.a -= G.flash.d; if (G.flash.a <= 0) G.flash = null;
  }
};
G.doFlash = (c = '#fff', a = 0.8, d = 0.08) => { G.flash = { c, a, d }; };
G.doShake = n => { if (G.cfg.shake) G.shake = Math.max(G.shake, n); };

// ---------- storage ----------
G.store = {
  get(k, def) { try { const v = localStorage.getItem('ashita.' + k); return v == null ? def : JSON.parse(v); } catch (e) { return def; } },
  set(k, v) { try { localStorage.setItem('ashita.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem('ashita.' + k); } catch (e) { } },
};
