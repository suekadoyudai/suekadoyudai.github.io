/* ときわたりの郵便屋 Courier of Hours: offline cache. build.py fills in the version and the file list. */
const CACHE = 'courier-1.1.0';
const ASSETS = ["./", "./fonts/DotGothic16-Regular.ttf", "./fonts/OFL.txt", "./icons/apple-touch-icon.png", "./icons/favicon-32.png", "./icons/icon-192.png", "./icons/icon-512.png", "./icons/maskable-512.png", "./index.html", "./js/art.js", "./js/audio.js", "./js/battle.js", "./js/data.js", "./js/en_data.js", "./js/en_story.js", "./js/en_ui.js", "./js/engine.js", "./js/field.js", "./js/i18n.js", "./js/main.js", "./js/maps.js", "./js/menu.js", "./js/music.js", "./js/party.js", "./js/portraits.js", "./js/pwa.js", "./js/sprites.js", "./js/story.js", "./js/tiles.js", "./js/touchpad.js", "./js/ui.js", "./manifest.webmanifest", "./privacy.html"];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  // only this game's old caches: other games may live on the same site
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('courier-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  if (e.request.mode === 'navigate') {
    // launching: use the network when it answers within 3 seconds, otherwise the saved copy
    e.respondWith((async () => {
      const cached = await caches.match('./index.html');
      const fresh = fetch(e.request, { cache: 'no-cache' }).then((r) => { if (!r.ok) throw new Error(r.status); const c = r.clone(); caches.open(CACHE).then((x) => x.put('./index.html', c)); return r; });
      if (!cached) return fresh;
      fresh.catch(() => {});
      const late = new Promise((res) => setTimeout(() => res(null), 3000));
      try { return (await Promise.race([fresh, late])) || cached; } catch (err) { return cached; }
    })());
    return;
  }
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request)));
});
