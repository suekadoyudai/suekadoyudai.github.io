/*! SG backend: null (canonical/test build). No SDK. Simulates ads so pause wiring can be tested. */
(function () {
  'use strict';
  var CFG = window.SG_CONFIG || {};
  var SIM = CFG.simulateAds !== false;
  var LS = (function () {
    var mem = {};
    function ok() { try { var k = '__sg_t'; window.localStorage.setItem(k, '1'); window.localStorage.removeItem(k); return true; } catch (e) { return false; } }
    var has = ok();
    return {
      get: function (k) { try { return has ? window.localStorage.getItem(k) : (k in mem ? mem[k] : null); } catch (e) { return null; } },
      set: function (k, v) { try { if (has) window.localStorage.setItem(k, v); else mem[k] = v; } catch (e) { mem[k] = v; } },
      del: function (k) { try { if (has) window.localStorage.removeItem(k); else delete mem[k]; } catch (e) { delete mem[k]; } }
    };
  })();
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  window.SG.__setBackend({
    name: 'null',
    init: function () { return { features: { interstitial: SIM, rewarded: SIM } }; },
    interstitial: function (placement, ctl) { ctl.pause(); return wait(CFG.simulateAdMs || 300).then(function () { ctl.resume(); return true; }); },
    rewarded: function (name, ctl) { ctl.pause(); return wait(CFG.simulateAdMs || 300).then(function () { ctl.resume(); return true; }); },
    storageLoad: function (keys) { var o = {}; keys.forEach(function (k) { o[k] = LS.get(k); }); return o; },
    storageSet: function (k, v) { LS.set(k, v); },
    storageRemove: function (k) { LS.del(k); }
  });
})();
