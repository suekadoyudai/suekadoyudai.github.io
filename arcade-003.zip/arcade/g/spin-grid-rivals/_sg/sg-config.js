window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": true,
 "debug": true,
 "platform": "null",
 "title": "Sonar Sweep",
 "names": {
  "title": null
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.title="Spin Grid Rivals";})(window.SG_CONFIG);
