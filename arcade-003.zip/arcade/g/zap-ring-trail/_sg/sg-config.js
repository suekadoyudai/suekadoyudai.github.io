window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": false,
 "debug": false,
 "hubConfig": "../../config.json",
 "platform": "arcade",
 "title": "Zap Ring Trail",
 "names": {
  "title": "ZAP RING TRAIL"
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.hubConfig="../../config.json";c.title="Zap Ring Trail";})(window.SG_CONFIG);
