window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": false,
 "debug": false,
 "hubConfig": "../../config.json",
 "platform": "arcade",
 "title": "Squiggle Spell Kitty",
 "names": {
  "title": "Squiggle Spell Kitty"
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.hubConfig="../../config.json";c.title="Squiggle Spell Kitty";})(window.SG_CONFIG);
