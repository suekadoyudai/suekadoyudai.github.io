window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": false,
 "debug": false,
 "hubConfig": "../../config.json",
 "platform": "arcade",
 "title": "Scribble Leg Racer",
 "names": {
  "title": "Scribble Leg Racer"
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.hubConfig="../../config.json";c.title="Scribble Leg Racer";})(window.SG_CONFIG);
