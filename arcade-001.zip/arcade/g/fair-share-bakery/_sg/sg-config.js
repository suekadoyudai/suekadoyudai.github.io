window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": true,
 "debug": true,
 "platform": "null",
 "title": "Bolt Pop: Screw Puzzle",
 "names": {
  "title": null
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.title="Fair Share Bakery";})(window.SG_CONFIG);
