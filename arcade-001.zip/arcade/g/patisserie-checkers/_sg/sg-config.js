window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": true,
 "debug": true,
 "platform": "null",
 "title": "Fathom",
 "names": {
  "title": null
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.title="Patisserie Checkers";})(window.SG_CONFIG);
