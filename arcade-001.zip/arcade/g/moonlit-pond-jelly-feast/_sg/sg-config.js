window.SG_CONFIG = {
 "pauseOnBlur": false,
 "simulateAds": false,
 "debug": false,
 "hubConfig": "../../config.json",
 "platform": "arcade",
 "title": "Moonlit Pond Jelly Feast",
 "names": {
  "title": "MOONLIT POND JELLY FEAST"
 },
 "ids": {},
 "brand": "SuedoGaming"
};

;(function(c){c.simulateAds=false;c.debug=false;c.platform="arcade";c.hubConfig="../../config.json";c.title="Moonlit Pond Jelly Feast";})(window.SG_CONFIG);
